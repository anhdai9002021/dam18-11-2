# -*- coding: utf-8 -*-
"""Mo hinh du lieu: doc/ghi file Excel dam (sheet Nhip, Thep, CaiDat)."""
import glob
import os
from collections import OrderedDict
import bm_xlsxr as xlsxr
import bm_xlsxw as xlsxw
import bm_bars as B
import bm_backup

H_STIR, H_STIR2, H_NOTE = u'Đai (Ø-a gối/a nhịp)', u'Đai trong', u'Ghi chú thép'
STIR_COLS = [H_STIR, H_STIR2, H_NOTE]
OBSOLETE = set([u'Thép trên (suốt)', u'Thép dưới (suốt)', u'TC trên - gối trái', u'TC trên - nhịp',
                u'TC trên - gối phải', u'TC dưới - gối trái', u'TC dưới - nhịp', u'TC dưới - gối phải',
                u'Thép giá', u'Uốn lên gối trái', u'Uốn lên gối phải'])
OPT_KEYS = [('cover', u'Lớp bảo vệ (mm)'), ('straight', u'Lệch ≤ x mm: thép chạy thẳng liền (0 = tắt)'), ('short', u'Nhịp < x mm: đai 1 khoảng cách'),
            ('zone_top', u'Bút: vùng tăng cường lớp trên'), ('zone_bot', u'Bút: tăng cường dưới tiêu chuẩn'), ('neo', u'Chiều dài neo mặc định'), ('gap', u'Chiều dài gập mặc định'),
            ('ext', u'Kéo dài ra nhịp mặc định'), ('thr', u'Ngưỡng lệch tiết diện: neo/uốn (mm)'),
            ('slope', u'Độ dốc uốn khi đổi tiết diện (1:x)'),
            ('merge_on', u'Nối 2 đoạn tăng cường (1 = bật)'), ('merge_gap', u'Nối 2 đoạn tăng cường khi hở ≤ x mm'),
            ('near', u'Cột cấy / dầm phụ cách đầu tăng cường ≤ x mm: lao ra'),
            ('tct1_on', u'TC lớp 1 trên: bật'), ('tct1_n', u'TC lớp 1 trên: số thanh'), ('tct1_d', u'TC lớp 1 trên: Ø (0 = như thép chủ)'),
            ('tcb1_on', u'TC lớp 1 dưới: bật'), ('tcb1_n', u'TC lớp 1 dưới: số thanh'), ('tcb1_d', u'TC lớp 1 dưới: Ø (0 = như thép chủ)'),
            ('skin_on', u'TCVN: thép thân (chống phình) bật'), ('skin_h', u'TCVN: thép thân khi h > (mm)'),
            ('skin_s', u'TCVN: thép thân khoảng cách tối đa (mm)'), ('skin_d', u'TCVN: thép thân Ø tối thiểu'),
            ('skin_ratio', u'TCVN: thép thân As tối thiểu (% s·max(b/2;200))'),
            ('tcvn_stir', u'TCVN: kẹp khoảng cách đai 10.3.4.3 (1 = bật)'), ('stir_a0', u'TCVN: a0 để tính h0 = h - a0 (mm)'),
            ('stir_dmin', u'TCVN: đai Ø tối thiểu (mm)'), ('stir_a1', u'TCVN: trần a gần gối (mm)'), ('stir_a2', u'TCVN: trần a giữa nhịp (mm)'),
            ('hang_on', u'TCVN: đai bổ sung dầm phụ 10.4.12 (1 = bật)'), ('hang_a', u'TCVN: bước đai bổ sung (mm)'),
            ('leg_b', u'TCVN: đai 4 nhánh khi b ≥ (mm)'), ('leg_n', u'TCVN: đai 4 nhánh khi số thanh / lớp >'),
            ('hook_clr', u'Khoảng hở chân bẻ lên / bẻ xuống (mm)'), ('pitch', u'Khoảng hở giữa các lớp thép (mm)'),
            ('tct2_on', u'TC lớp 2 trên: bật'), ('tct2_n', u'TC lớp 2 trên: số thanh'), ('tct2_d', u'TC lớp 2 trên: Ø (0 = như thép chủ)'),
            ('tcb2_on', u'TC lớp 2 dưới: bật'), ('tcb2_n', u'TC lớp 2 dưới: số thanh'), ('tcb2_d', u'TC lớp 2 dưới: Ø (0 = như thép chủ)')]


SAMPLE = u'★ MẪU HƯỚNG DẪN'


DEP_T, DEP_P = u'Cột T cạnh vuông góc dầm (mm)', u'Cột P cạnh vuông góc dầm (mm)'
DH_T, DH_P = u'h dầm đỡ T (mm)', u'h dầm đỡ P (mm)'
TEXT_KINDS = ('plname', 'sec', 'colsec', 'gname', 'stir', 'stir2')      # kich thuoc nhap dang chu


def _dep(v):
    try:
        x = float(v)
        return x if x > 0 else None
    except Exception:
        return None


def _num(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d


class Model(object):
    def __init__(self, path):
        self.path = path
        self.wb = xlsxr.read_xlsx(path)
        if 'Nhip' not in self.wb:
            raise ValueError(u'File không có sheet "Nhip" - hãy dùng file do nút "Quét dầm" xuất ra.')
        rows = self.wb['Nhip']
        hdr = [h or '' for h in rows[0]]
        drop = [i for i, h in enumerate(hdr) if h in OBSOLETE]
        for r in rows:
            for i in reversed(drop):
                if i < len(r):
                    del r[i]
        hdr = [h or '' for h in rows[0]]
        for h in STIR_COLS:
            if h not in hdr:
                rows[0].append(h)
                hdr.append(h)
        for r in rows:
            while len(r) < len(hdr):
                r.append(None)
        self.hdr = hdr
        self.col = dict((h, i) for i, h in enumerate(hdr))
        self.beams = OrderedDict()
        for ri in range(1, len(rows)):
            if rows[ri][0] not in (None, ''):
                self.beams.setdefault(rows[ri][0], []).append(ri)
        self.opt = dict(B.DEFAULT_OPT)
        self.opt.update({'neo': u'30d', 'gap': u'xuống', 'ext': u'L/3'})
        for r in self.wb.get('CaiDat', [])[1:]:
            for k, lab in OPT_KEYS:
                if r and r[0] == lab and len(r) > 1 and r[1] not in (None, ''):
                    self.opt[k] = r[1] if isinstance(self.opt[k], str) or k in ('neo', 'gap', 'ext') else _num(r[1], self.opt[k])
        new_fmt = any(x and x[0] == u'Bút: vùng tăng cường lớp trên' for x in self.wb.get('CaiDat', []))
        if not new_fmt and str(self.opt.get('gap', '')).strip().lower() == '15d':   # file cu: mac dinh cu -> gap xuong sat lop duoi
            self.opt['gap'] = u'xuống'
        self.groups = OrderedDict((n, []) for n in self.beams)
        self.zones = OrderedDict((n, []) for n in self.beams)
        for r in self.wb.get('Dai', [])[1:]:
            if r and r[0] in self.zones and len(r) >= 6:
                self.zones[r[0]].append(dict(x0=_num(r[2]), x1=_num(r[3]), d=int(_num(r[4], 8)), a=int(_num(r[5], 100))))
        self.dirs = {}
        nd = self.wb.get('NhomDam') or []
        if nd and nd[0] and u'Hướng' in nd[0]:
            ci = list(nd[0]).index(u'Hướng')
            for r in nd[1:]:
                if r and r[0] and len(r) > ci:
                    self.dirs[r[0]] = r[ci] or ''
        self.level_z = 0.0
        for x in self.wb.get('Info', []):
            if x and len(x) > 1 and x[0] == u'Cao độ tầng theo Project Base Point (mm)':
                self.level_z = _num(x[1])
        self.ids = {}
        if nd and nd[0] and u'ElementId Revit (tất cả dầm con)' in nd[0]:
            cj = list(nd[0]).index(u'ElementId Revit (tất cả dầm con)')
            for r in nd[1:]:
                if r and r[0] and len(r) > cj and r[cj]:
                    self.ids[r[0]] = [int(x) for x in str(r[cj]).split(';') if x.strip().isdigit()]
        self.samples = {}
        self.ticked = set(x[0] for x in self.wb.get('Chon', [])[1:] if x and x[0] in self.beams)
        for r in self.wb.get('Thep', [])[1:]:
            if not r or r[0] not in self.groups or len(r) < len(B.HEADER) - 1:
                continue
            r = list(r) + [None] * (len(B.HEADER) - len(r))
            s = lambda i: '' if r[i] is None else str(r[i])
            self.groups[r[0]].append(B.new_group(
                pos=s(2) or B.POS[1], layer=int(_num(r[3], 1)), n=int(_num(r[4], 2)), d=int(_num(r[5], 16)),
                a=int(_num(r[6], 0)), lk=s(7) or B.K_NEO, lv=s(8), b=int(_num(r[9], 1)), rk=s(10) or B.K_NEO,
                rv=s(11), cross=s(12) or B.X_AUTO, note=s(13)))

    # ---- cac tiet dien da quet
    def sections(self):
        """Cac tiet dien b x h co trong du lieu quet (khong tinh dam mau): [dict(b,h,count,lmin,lmax)]."""
        d = {}
        for nm in self.beams:
            if nm in self.samples:
                continue
            for sp in self._beam_raw(nm)['spans']:
                d.setdefault((int(round(sp['b'])), int(round(sp['h']))), []).append(sp['clear'])
        out = [dict(b=b, h=h, count=len(v), lmin=int(round(min(v))), lmax=int(round(max(v))))
               for (b, h), v in d.items()]
        out.sort(key=lambda x: (x['h'], x['b']))
        return out

    # ---- dam
    def add_sample(self):
        """Dam mau (chi nam trong bo nho): doi tiet dien + lech cote, kem ghi chu cach dien."""
        import bm_sample
        beam, groups = bm_sample.make(SAMPLE)
        self.samples[SAMPLE] = beam
        self.dirs[SAMPLE] = u'Ngang (trái → phải)'
        self.beams = OrderedDict([(SAMPLE, [-1] * len(beam['spans']))] + list(self.beams.items()))
        self.groups = OrderedDict([(SAMPLE, groups)] + list(self.groups.items()))
        self.zones = OrderedDict([(SAMPLE, [])] + list(self.zones.items()))

    def sl(self, name):
        if name in self.samples:
            return self.samples[name]['sl']
        return self.wb['Nhip'][self.beams[name][0]][self.col.get('SL', 1)]

    def beam_data(self, name):
        bd = dict(self._beam_raw(name))
        bd['groups'] = self.groups.get(name, [])        # cac nhom thep cua dam: build() dung de tranh 2 neo tren/duoi de len nhau
        bd['zones'] = B.final_zones(bd, self.zones.get(name, []), self.opt)
        bd['dir'] = self.dirs.get(name, '')
        bd['level_z'] = 3600.0 if name in self.samples else self.level_z
        return bd

    def add_zone(self, name, x0, x1, d, a):
        self.zones.setdefault(name, []).append(dict(x0=float(x0), x1=float(x1), d=int(d), a=int(a)))

    def undo_zone(self, name):
        if self.zones.get(name):
            self.zones[name].pop()
            return True
        return False

    def clear_zones(self, name):
        self.zones[name] = []

    def _beam_raw(self, name):
        if name in self.samples:
            return self.samples[name]
        rows, c = self.wb['Nhip'], self.col
        spans, sup = [], []

        def g(r, h):
            return r[c[h]] if h in c else None
        for k, ri in enumerate(self.beams[name]):
            r = rows[ri]
            if k == 0:
                sup.append(dict(w=_num(g(r, u'Gối trái (mm)')), kind=g(r, u'Loại gối T') or '', grid=str(g(r, u'Trục T') or ''),
                                off=_num(g(r, u'Lệch trục T (mm)')), dep=_dep(g(r, DEP_T)), dh=_dep(g(r, DH_T)),
                                ref=str(g(r, u'Cột đỡ T') or ''), role=str(g(r, u'Vai trò gối T') or '')))
            sup.append(dict(w=_num(g(r, u'Gối phải (mm)')), kind=g(r, u'Loại gối P') or '', grid=str(g(r, u'Trục P') or ''),
                            off=_num(g(r, u'Lệch trục P (mm)')), dep=_dep(g(r, DEP_P)), dh=_dep(g(r, DH_P)),
                            ref=str(g(r, u'Cột đỡ P') or ''), role=str(g(r, u'Vai trò gối P') or '')))
            top = _num(g(r, u'Cao đỉnh (mm)'))
            hs = _num(g(r, u'h sàn (mm)'))

            def slab(th_h, top_h):
                if th_h in c:           # file moi: day + dinh san tung ben
                    th = _num(g(r, th_h))
                    return (th, _num(g(r, top_h), top)) if th > 0 else None
                return (hs, top) if hs > 0 else None      # file cu: h san chung, san bang dinh dam
            pl = []
            for tok in str(g(r, u'Cột cấy (tên@vị trí@rộng)') or '').split(';'):      # cot cay len dam: ten@vi tri tu mep goi trai@be rong
                q = tok.strip().split('@')
                if len(q) in (3, 4) and q[0]:
                    pl.append(dict(name=q[0], pos=_num(q[1]), w=_num(q[2], 300.0), dep=_dep(q[3]) if len(q) == 4 else None))
            spans.append(dict(idx=g(r, u'Nhịp'), planted=pl, clear=_num(g(r, u'L thông thủy (mm)')), b=_num(g(r, 'b (mm)')),
                              h=_num(g(r, 'h (mm)')) or 500.0, top=top,
                              stir=str(g(r, H_STIR) or ''), stir2=str(g(r, H_STIR2) or ''),
                              slabL=slab(u'Sàn T dày (mm)', u'Sàn T đỉnh (mm)'),
                              slabR=slab(u'Sàn P dày (mm)', u'Sàn P đỉnh (mm)')))
        return dict(name=name, sl=self.sl(name), supports=sup, spans=spans)

    # ---- SUA KICH THUOC TRUC TIEP (khong can quet lai Revit) ------------------------------------------
    geo_ver = 0

    def _r(self, x):
        return int(round(x)) if abs(x - round(x)) < 1e-9 else round(x, 1)

    def _pl_tokens(self, name, i):
        rows, c = self.wb['Nhip'], self.col
        h = u'Cột cấy (tên@vị trí@rộng)'
        out = []
        for tok in str((rows[self.beams[name][i]][c[h]] if h in c else '') or '').split(';'):
            q = tok.strip().split('@')
            if len(q) in (3, 4) and q[0]:
                out.append([q[0], _num(q[1]), _num(q[2], 300.0), _dep(q[3]) if len(q) == 4 else None])
        return out

    def _pl_store(self, name, i, toks):
        rows, c = self.wb['Nhip'], self.col
        ri = self.beams[name][i]
        toks = [t for t in toks if t[2] > 0.5]                       # be rong 0 = xoa cot cay
        toks.sort(key=lambda t: t[1])
        if u'Cột cấy (tên@vị trí@rộng)' in c:
            rows[ri][c[u'Cột cấy (tên@vị trí@rộng)']] = u';'.join(
                (u'%s@%d@%d@%d' % (t[0], round(t[1]), round(t[2]), round(t[3]))) if t[3] else (u'%s@%d@%d' % (t[0], round(t[1]), round(t[2])))
                for t in toks) or None
        if u'Cột cấy trên nhịp (không đỡ dầm)' in c:
            rows[ri][c[u'Cột cấy trên nhịp (không đỡ dầm)']] = u', '.join(t[0] for t in toks) or None

    def _snapshot(self, name):
        rows = self.wb['Nhip']
        return (name, [list(rows[ri]) for ri in self.beams[name]], [dict(z) for z in self.zones.get(name, [])],
                [dict(g) for g in self.groups.get(name, [])])

    def _ensure_col(self, h):
        """Them cot h vao sheet Nhip (file quet cu chua co cot canh vuong goc dam)."""
        if h in self.col:
            return self.col[h]
        rows = self.wb['Nhip']
        rows[0].append(h)
        for r in rows[1:]:
            r.append(None)
        self.hdr.append(h)
        self.col[h] = len(self.hdr) - 1
        return self.col[h]

    @staticmethod
    def parse_sec(text, named=False):
        """'300x600' / '300 x 600*' / 'C9 400x600' -> (ten, rong1, rong2, tat_ca_nhip) hoac None."""
        import re
        m = re.match(u'^\\s*(?:(.*?)\\s+)?(\\d+(?:[.,]\\d+)?)\\s*[xX\u00d7]\\s*(\\d+(?:[.,]\\d+)?)\\s*(\\*?)\\s*$', text or u'')
        if not m or (m.group(1) and not named):
            return None
        a, b = float(m.group(2).replace(',', '.')), float(m.group(3).replace(',', '.'))
        return ((m.group(1) or u'').strip(), a, b, bool(m.group(4)))

    def _restore(self, snap):
        nm, rws, zs, gs = snap
        self.groups[nm] = [dict(g) for g in gs]          # hoan tac ca nhom thep (thep than / dai TCVN tu ap khi doi h)
        for ri, r in zip(self.beams[nm], rws):
            row = self.wb['Nhip'][ri]
            row[:] = r
            while len(row) < len(self.hdr):                 # cot moi them sau khi chup (vd cot san) -> bu o trong, tranh IndexError
                row.append(None)
        self.zones[nm] = [dict(z) for z in zs]
        self.geo_ver += 1
        return nm

    def undo_dim(self, name=None):
        """Hoan tac lan sua kich thuoc gan nhat (cua dam bat ky hoac dam chi dinh)."""
        hist = getattr(self, '_dim_hist', [])
        for k in range(len(hist) - 1, -1, -1):
            if name is None or hist[k][0] == name:
                snap = hist.pop(k)
                self._dim_redo = (getattr(self, '_dim_redo', []) + [self._snapshot(snap[0])])[-60:]
                return self._restore(snap)
        return None

    def redo_dim(self, name=None):
        """Lam lai lan hoan tac gan nhat."""
        redo = getattr(self, '_dim_redo', [])
        for k in range(len(redo) - 1, -1, -1):
            if name is None or redo[k][0] == name:
                snap = redo.pop(k)
                self._dim_hist = (getattr(self, '_dim_hist', []) + [self._snapshot(snap[0])])[-60:]
                return self._restore(snap)
        return None

    SLAB_COLS = [u'Sàn T dày (mm)', u'Sàn T đỉnh (mm)', u'Sàn P dày (mm)', u'Sàn P đỉnh (mm)']

    def _ensure_slab_cols(self):
        """File quet cu chi co 'h san' chung: tao 4 cot san T/P va dien san gia tri cu (san = dinh dam) de sua duoc tung ben."""
        missing = [h for h in self.SLAB_COLS if h not in self.col]
        if not missing:
            return
        for h in missing:
            self._ensure_col(h)
        if len(missing) == 4:
            c = self.col
            for r in self.wb['Nhip'][1:]:
                hs = _num(r[c[u'h sàn (mm)']]) if u'h sàn (mm)' in c else 0.0
                top = _num(r[c[u'Cao đỉnh (mm)']]) if u'Cao đỉnh (mm)' in c else 0.0
                if hs > 0:
                    for hth, htop in ((self.SLAB_COLS[0], self.SLAB_COLS[1]), (self.SLAB_COLS[2], self.SLAB_COLS[3])):
                        r[c[hth]], r[c[htop]] = hs, top

    def _remap_zones(self, name, old_lay, new_lay):
        """Vung dai ve tay (toa do tuyet doi) dich theo kich thuoc moi: noi suy tung doan goi / nhip."""
        zl = self.zones.get(name) or []
        if not zl:
            return
        segs = []
        for k in range(old_lay['n'] + 1):
            w0 = old_lay['sx0'][k]
            segs.append((w0, w0 + (old_lay['fl'][k] - old_lay['sx0'][k] if k < old_lay['n'] else old_lay['L'] - w0),
                         new_lay['sx0'][k], new_lay['sx0'][k] + (new_lay['fl'][k] - new_lay['sx0'][k] if k < new_lay['n'] else new_lay['L'] - new_lay['sx0'][k])))
            if k < old_lay['n']:
                segs.append((old_lay['fl'][k], old_lay['fr'][k], new_lay['fl'][k], new_lay['fr'][k]))

        def mp(x):
            for a0, a1, b0, b1 in segs:
                if a0 - 1e-6 <= x <= a1 + 1e-6:
                    return b0 + (x - a0) * ((b1 - b0) / (a1 - a0)) if a1 - a0 > 1e-6 else b0
            return x + (new_lay['L'] - old_lay['L'])
        for z in zl:
            z['x0'], z['x1'] = mp(z['x0']), mp(z['x1'])

    def set_dim(self, name, key, value, _snap=True):
        """Sua 1 kich thuoc cua dam ngay trong tool. key:
        ('w', k)            be rong goi k (tim goi giu nguyen -> thong thuy 2 nhip ke ben thay doi 1/2 chenh lech)
        ('clear', i) ('cc', i) ('grid', i)   chieu dai nhip i: thong thuy / tim-tim / truc-truc (chenh lech cong vao thong thuy)
        ('off', k)          lech truc luoi - tim goi k
        ('plgap', i, j, 'left'|'between'|'right')  khoang ho cot cay (mep goi - mep cot / giua 2 cot / mep cot - mep goi)
        ('plw', i, j)       be rong cot cay (0 = xoa)        ('plgrid', i, j, 'L'|'R')  truc luoi -> tim cot cay
        ('plname', i, j)    ten cot cay
        Tra ve (ok, thong bao)."""
        if name in self.samples:
            return False, u'Dầm mẫu không sửa kích thước được.'
        rows, c = self.wb['Nhip'], self.col
        idx = self.beams[name]
        n = len(idx)
        old_raw = self._beam_raw(name)
        old_lay = B.layout(old_raw)
        snap = self._snapshot(name) if _snap else None

        def cell(i, h):
            return rows[idx[i]][c[h]] if (h in c and 0 <= i < n) else None

        def setc(i, h, v):
            if h in c and 0 <= i < n:
                rows[idx[i]][c[h]] = v

        def addc(i, h, d):
            v = cell(i, h)
            if v not in (None, ''):
                setc(i, h, self._r(_num(v) + d))

        def width(k):
            return _num(cell(0, u'Gối trái (mm)')) if k == 0 else _num(cell(k - 1, u'Gối phải (mm)'))

        def off(k):
            return _num(cell(0, u'Lệch trục T (mm)')) if k == 0 else _num(cell(k - 1, u'Lệch trục P (mm)'))

        def grid(k):
            return str((cell(0, u'Trục T') if k == 0 else cell(k - 1, u'Trục P')) or '').strip()
        all_flag = len(key) > 1 and key[-1] == 'all'        # hau to 'all' = ap dung cho TAT CA nhip
        if all_flag:
            key = tuple(key[:-1])

        def idxs():
            if all_flag:
                return list(range(n))
            k1 = key[1] if len(key) > 1 else 0
            ks = k1 if isinstance(k1, (tuple, list)) else [k1]
            return [int(q) for q in ks if 0 <= int(q) < n]

        def fix_cc(i):
            """Cap nhat cot 'L tim' / 'L truc-truc' cua nhip i sau khi doi ten truc (co / khong co truc o 2 dau)."""
            if not (0 <= i < n):
                return
            cen = _num(cell(i, u'L thông thủy (mm)')) + (width(i) + width(i + 1)) / 2.0
            gg = cen + off(i + 1) - off(i)
            both = bool(grid(i) and grid(i + 1))
            setc(i, u'L tim = trục-trục (mm)', self._r(gg if both else cen))
            setc(i, u'L trục-trục (mm)', self._r(gg) if both else None)
        kind = key[0]
        msg = u''
        try:
            value = float(value) if kind not in TEXT_KINDS else value
        except Exception:
            return False, u'Giá trị không hợp lệ.'
        if kind == 'w':
            k = key[1]
            if value < 0:
                return False, u'Bề rộng gối không âm.'
            dw = value - width(k)
            for i in (k - 1, k):
                if 0 <= i < n and _num(cell(i, u'L thông thủy (mm)')) - dw / 2.0 < 1:
                    return False, u'Gối rộng quá: nhịp %s thành ≤ 0.' % cell(i, u'Nhịp')
            if k >= 1:
                setc(k - 1, u'Gối phải (mm)', self._r(value))
            if k < n:
                setc(k, u'Gối trái (mm)', self._r(value))
            for i in (k - 1, k):
                if 0 <= i < n:
                    setc(i, u'L thông thủy (mm)', self._r(_num(cell(i, u'L thông thủy (mm)')) - dw / 2.0))
            msg = u'Bề rộng gối G%d = %d' % (k, round(value))
        elif kind in ('clear', 'cc', 'grid'):
            i = key[1]
            clear = _num(cell(i, u'L thông thủy (mm)'))
            cen = clear + (width(i) + width(i + 1)) / 2.0
            cur = {'clear': clear, 'cc': cen, 'grid': cen + off(i + 1) - off(i)}[kind]
            dd = value - cur
            if clear + dd < 1:
                return False, u'Nhịp thành ≤ 0.'
            setc(i, u'L thông thủy (mm)', self._r(clear + dd))
            addc(i, u'L tim = trục-trục (mm)', dd)
            addc(i, u'L trục-trục (mm)', dd)
            msg = u'Nhịp N%s (%s) = %d' % (cell(i, u'Nhịp'), {'clear': u'thông thủy', 'cc': u'tim-tim', 'grid': u'trục-trục'}[kind], round(value))
        elif kind == 'off':
            k = key[1]
            dd = value - off(k)
            if k >= 1:
                setc(k - 1, u'Lệch trục P (mm)', self._r(value))
                addc(k - 1, u'L trục-trục (mm)', dd)
                if grid(k - 1) and grid(k):
                    addc(k - 1, u'L tim = trục-trục (mm)', dd)
            if k < n:
                setc(k, u'Lệch trục T (mm)', self._r(value))
                addc(k, u'L trục-trục (mm)', -dd)
                if grid(k) and grid(k + 1):
                    addc(k, u'L tim = trục-trục (mm)', -dd)
            msg = u'Lệch trục lưới - tim gối G%d = %+d' % (k, round(value))
        elif kind == 'sec':
            r = self.parse_sec(value)
            if not r or r[1] <= 0 or r[2] <= 0:
                return False, u'Nhập tiết diện dạng 300x600 (b x h, mm).'
            _, nb, nh, allsp = r
            for i in (range(n) if allsp else [key[1]]):
                setc(i, u'b (mm)', self._r(nb))
                setc(i, u'h (mm)', self._r(nh))
            msg = u'Tiết diện dầm %s = %dx%d (cao đỉnh giữ nguyên, đáy đổi theo h)' % (
                u'tất cả nhịp' if allsp else u'nhịp N%s' % cell(key[1], u'Nhịp'), round(nb), round(nh))
        elif kind == 'colsec':
            r = self.parse_sec(value, named=True)
            if not r or r[1] <= 0 or r[2] <= 0:
                return False, u'Nhập tiết diện cột dạng "C9 300x600" (rộng dọc dầm x cạnh vuông góc dầm, mm).'
            nm_, w_, d_, _ = r
            if key[1] == 's':
                k = key[2]
                if abs(w_ - width(k)) > 0.05:
                    ok_, m_ = self.set_dim(name, ('w', k), w_, _snap=False)
                    if not ok_:
                        return False, m_
                    old_lay = B.layout(self._beam_raw(name))        # vung dai da dich trong lan goi 'w' -> khong dich lai
                col_t, col_p = self._ensure_col(DEP_T), self._ensure_col(DEP_P)
                if k >= 1:
                    rows[idx[k - 1]][col_p] = self._r(d_)
                if k < n:
                    rows[idx[k]][col_t] = self._r(d_)
                if nm_:
                    if k >= 1:
                        setc(k - 1, u'Cột đỡ P', nm_)
                    if k < n:
                        setc(k, u'Cột đỡ T', nm_)
                msg = u'Cột G%d%s: %dx%d (dọc dầm x vuông góc dầm)' % (k, (u' ' + nm_) if nm_ else u'', round(w_), round(d_))
            else:
                i, j = key[2], key[3]
                toks = self._pl_tokens(name, i)
                if not (0 <= j < len(toks)):
                    return False, u'Không tìm thấy cột cấy.'
                toks[j][0] = nm_ or toks[j][0]
                toks[j][2], toks[j][3] = w_, d_
                self._pl_store(name, i, toks)
                msg = u'Cột cấy %s: %dx%d (dọc dầm x vuông góc dầm), tim cột giữ nguyên' % (toks[j][0], round(w_), round(d_))
        elif kind in ('plgap', 'plw', 'plgrid', 'plname'):
            i, j = key[1], key[2]
            toks = self._pl_tokens(name, i)
            if not (0 <= j < len(toks)):
                return False, u'Không tìm thấy cột cấy.'
            t = toks[j]
            clear = _num(cell(i, u'L thông thủy (mm)'))
            if kind == 'plname':
                t[0] = (value or u'').strip() or t[0]
                msg = u'Đổi tên cột cấy thành %s' % t[0]
            elif kind == 'plw':
                if value < 0:
                    return False, u'Bề rộng không âm.'
                t[2] = value
                msg = u'Cột cấy %s: bề rộng %d' % (t[0], round(value)) if value > 0.5 else u'Đã xóa cột cấy %s' % t[0]
            elif kind == 'plgap':
                part = key[3]
                if part == 'left':
                    t[1] = value + t[2] / 2.0
                elif part == 'right':
                    t[1] = clear - value - t[2] / 2.0
                else:
                    p = toks[j - 1]
                    t[1] = p[1] + p[2] / 2.0 + value + t[2] / 2.0
                msg = u'Cột cấy %s: tim cách mép gối trái %d' % (t[0], round(t[1]))
            else:
                if key[3] == 'L':
                    t[1] = (off(i) - width(i) / 2.0) + value
                else:
                    t[1] = (clear + width(i + 1) / 2.0 + off(i + 1)) - value
                msg = u'Cột cấy %s: tim cách mép gối trái %d' % (t[0], round(t[1]))
            self._pl_store(name, i, toks)
        elif kind in ('top', 'bot'):
            ii = idxs()
            if not ii:
                return False, u'Không tìm thấy nhịp.'
            self._ensure_slab_cols()                                  # dong bang cote san (file cu: san = dinh dam)
            if kind == 'top':
                for i in ii:
                    setc(i, u'Cao đỉnh (mm)', self._r(value))
                msg = u'Cote đỉnh dầm %s = %+.3f m so với Level (đáy đổi theo h)' % (
                    u'tất cả nhịp' if all_flag else u'nhịp N%s' % u', N'.join(str(cell(i, u'Nhịp')) for i in ii), value / 1000.0)
            else:
                for i in ii:
                    if _num(cell(i, u'Cao đỉnh (mm)')) - value < 50:
                        return False, u'Đáy dầm phải thấp hơn đỉnh dầm ít nhất 50 mm (nhịp N%s).' % cell(i, u'Nhịp')
                for i in ii:
                    setc(i, u'h (mm)', self._r(_num(cell(i, u'Cao đỉnh (mm)')) - value))
                msg = u'Cote đáy dầm = %+.3f m so với Level (đỉnh giữ nguyên, h đổi)' % (value / 1000.0)
        elif kind == 'slab':
            ii = idxs()
            side, field = key[2], key[3]
            self._ensure_slab_cols()
            sd = u'T' if side == 'L' else u'P'
            hth, htop = u'Sàn %s dày (mm)' % sd, u'Sàn %s đỉnh (mm)' % sd
            done = 0
            for i in ii:
                if field == 'th':
                    if value < 0:
                        return False, u'Chiều dày sàn không âm.'
                    setc(i, hth, self._r(value) if value > 0.5 else None)
                    if value > 0.5 and cell(i, htop) in (None, ''):
                        setc(i, htop, self._r(_num(cell(i, u'Cao đỉnh (mm)'))))      # san moi: dinh san = dinh dam
                    if value <= 0.5:
                        setc(i, htop, None)
                    done += 1
                elif _num(cell(i, hth)) > 0.5:
                    setc(i, htop, self._r(value))
                    done += 1
                setc(i, u'h sàn (mm)', self._r(max(_num(cell(i, u'Sàn T dày (mm)')), _num(cell(i, u'Sàn P dày (mm)')))))
            if not done:
                return False, u'Bên này chưa có sàn - nhập chiều dày sàn trước.'
            msg = (u'Sàn %s dày %d mm' % (sd, round(value))) if field == 'th' else (u'Cote đỉnh sàn %s = %+.3f m' % (sd, value / 1000.0))
        elif kind == 'gname':
            k = key[1]
            nm_ = (value or u'').strip()
            if k >= 1:
                setc(k - 1, u'Trục P', nm_ or None)
            if k < n:
                setc(k, u'Trục T', nm_ or None)
            for i in (k - 1, k):
                fix_cc(i)
            msg = (u'Trục lưới tại gối G%d = %s' % (k, nm_)) if nm_ else (u'Đã xóa trục lưới tại gối G%d' % k)
        elif kind in ('stir', 'stir2'):
            v = (value or u'').strip()
            every = v.endswith(u'*')                                   # 8-100/200* = ap dung moi nhip
            v = v.rstrip(u'*').strip()
            if v and not B.parse_stir(v):
                return False, u'Đai nhập dạng Ø-a gối/a nhịp, ví dụ 8-100/200 (hoặc 8-150). Thêm * để áp dụng mọi nhịp.'
            hcol = H_STIR if kind == 'stir' else H_STIR2
            for i in (range(n) if every else [key[1]]):
                setc(i, hcol, v or None)
            msg = u'%s %s%s' % (u'Đai' if kind == 'stir' else u'Đai trong', v or u'(xóa)', u' - tất cả nhịp' if every else u'')
        else:
            return False, u'Kích thước không sửa được.'
        if _snap:
            self._dim_hist = (getattr(self, '_dim_hist', []) + [snap])[-60:]
            self._dim_redo = []
        if kind in ('sec', 'top', 'bot'):             # doi h / cote: doan be neo dang so ~ bang dam cu -> 'xuong' de theo chieu cao moi
            nh = B.normalize_hooks(self.groups.get(name, []), old_raw, self.opt)
            if nh:
                msg += u' · %d đoạn bẻ neo chạy theo chiều cao dầm' % nh
            msg += self._retcvn(name)
        self._remap_zones(name, old_lay, B.layout(self._beam_raw(name)))
        self.geo_ver += 1
        return True, msg

    def _retcvn(self, name):
        """Doi h / cote: tu ap lai thep than (h > skin_h) va kep dai theo TCVN neu cac o do dang bat (truoc day phai bam 'Ap dung TCVN')."""
        o, out = self.opt, []
        if name in self.samples:
            return u''
        if o.get('skin_on'):
            old = len([g for g in self.groups[name] if B.is_skin(g)])
            self.groups[name] = B.apply_skin(self.beam_data(name), self.groups[name], o)
            new = len([g for g in self.groups[name] if B.is_skin(g)])
            if new != old:
                out.append(u'thép thân TCVN %+d nhóm' % (new - old))
        if o.get('tcvn_stir'):
            bd = self.beam_data(name)
            nv = B.tcvn_stirrups(bd, self.groups[name], o)
            if any(tuple(x) != (q.get('stir') or u'', q.get('stir2') or u'') for x, q in zip(nv, bd['spans'])):
                self.set_stir(name, nv)
                out.append(u'đai kẹp lại theo TCVN')
        return (u' · ' + u', '.join(out)) if out else u''

    def set_stir(self, name, vals):
        if name in self.samples:
            for sp, (a, b) in zip(self.samples[name]['spans'], vals):
                sp['stir'], sp['stir2'] = a or '', b or ''
            return
        rows = self.wb['Nhip']
        for ri, (s1, s2) in zip(self.beams[name], vals):
            rows[ri][self.col[H_STIR]] = (s1 or '').strip() or None
            rows[ri][self.col[H_STIR2]] = (s2 or '').strip() or None

    def problems(self):
        bad = []
        for nm, gl in self.groups.items():
            if nm in self.samples:
                continue
            ns = len(self.beams[nm])
            for i, g in enumerate(gl, 1):
                if not (0 <= g['a'] <= g['b'] <= ns):
                    bad.append((nm, i, u'Từ/Đến gối ngoài phạm vi 0..%d' % ns))
                elif not B.build(g, self.beam_data(nm), self.opt):
                    bad.append((nm, i, u'Nhóm thép không có chiều dài'))
                if not (B.len_valid(g['lv']) and B.len_valid(g['rv'])):
                    bad.append((nm, i, u'Giá trị đầu thép sai cú pháp'))
        return bad

    # ---- luu
    def save(self, path=None):
        path = path or self.path
        if not getattr(self, '_bak_done', None) == path:        # sao luu 1 lan / phien truoc lan ghi de dau tien
            bm_backup.backup(path, 'truoc-luu')
            self._bak_done = path
        thep = [list(B.HEADER)]
        for nm, gl in self.groups.items():
            if nm in self.samples:
                continue
            for i, g in enumerate(gl, 1):
                thep.append([nm, i, g['pos'], g['layer'], g['n'], g['d'], g['a'], g['lk'], g['lv'] or None,
                             g['b'], g['rk'], g['rv'] or None, g['cross'], g['note'] or None])
        dai = [[u'Dầm', u'STT', u'Từ (mm)', u'Đến (mm)', u'Ø', u'a (mm)']]
        for nm, zl in self.zones.items():
            if nm in self.samples:
                continue
            for i, z in enumerate(zl, 1):
                dai.append([nm, i, round(z['x0']), round(z['x1']), z['d'], z['a']])
        chon = [[u'Dầm đã tick']] + [[n] for n in self.beams if n in self.ticked and n not in self.samples]
        cai = [[u'Mục', u'Giá trị']] + [[lab, self.opt[k]] for k, lab in OPT_KEYS]
        sheets = []
        names = list(self.wb.keys())
        for extra in ('Thep', 'Dai', 'CaiDat', 'Chon'):
            if extra not in names:
                names.insert(names.index('Nhip') + 1 if extra == 'Thep' else names.index({'Dai': 'Thep', 'CaiDat': 'Dai', 'Chon': 'CaiDat'}[extra]) + 1, extra)
        for nm in names:
            rows = {'Thep': thep, 'Dai': dai, 'CaiDat': cai, 'Chon': chon}.get(nm, self.wb.get(nm))
            ncol = max([len(r) for r in rows] + [1])
            norm = [list(r) + [None] * (ncol - len(r)) for r in rows]
            widths = [min(60, max([len(str(r[c])) for r in norm[:300] if r[c] is not None] + [6]) + 2) for c in range(ncol)]
            sh = dict(name=nm, rows=norm, widths=widths)
            if nm == 'Nhip':
                sh['input_cols'] = set(self.col[h] for h in STIR_COLS)
            elif nm == 'Thep':
                sh['input_cols'] = set(range(2, ncol))
            elif nm == 'Dai':
                sh['input_cols'] = set(range(2, ncol))
            sheets.append(sh)
        tmp = path + '.tmp'
        xlsxw.write_xlsx(tmp, sheets)
        os.replace(tmp, path)


def sibling_files(path):
    """Cac file Dam_*.xlsx cung thu muc (moi file = 1 tang)."""
    d = os.path.dirname(os.path.abspath(path))
    return sorted(glob.glob(os.path.join(d, 'Dam_*.xlsx')))
