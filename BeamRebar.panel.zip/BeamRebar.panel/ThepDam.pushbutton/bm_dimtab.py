# -*- coding: utf-8 -*-
"""Sua kich thuoc TRUC TIEP tren ban ve dam, kieu Excel:
  bam vao so dim -> hien o nhap ngay tai cho -> go so (hoac phep tinh =4000+250) -> Enter / Tab sang dim ke tiep.
  Enter, Tab, mui ten xuong = dim ke tiep · Shift+Enter, Shift+Tab, mui ten len = dim truoc · Esc = huy · bam cho khac = chot.
Moi lan chot goi Model.set_dim() co san -> dung chung nut ↶ (hoan tac) va co che ve lai cua tool.
Phan WinForms import khi tao InlineEdit nen module nay import duoc ngoai Revit de kiem thu parse_num / fmt."""
import re

_EXPR = re.compile(r'^[0-9.+\-*/() ]+$')


def fmt(v):
    if v is None or v == '':
        return u''
    try:
        f = float(v)
    except (TypeError, ValueError):
        return u'%s' % v
    return u'%d' % round(f) if abs(f - round(f)) < 1e-6 else u'%.1f' % f


def parse_num(text):
    """'4000' | '4000,5' | '=4000+250' | '3*1200' -> float, hoac None neu khong hop le."""
    t = (text or u'').strip().replace(u',', u'.')
    if t.startswith(u'='):
        t = t[1:].strip()
    if not t or not _EXPR.match(t) or '**' in t:
        return None
    try:
        v = float(eval(t, {'__builtins__': {}}, {}))
    except Exception:
        return None
    return v if v == v and abs(v) < 1e9 else None


def to_value(d, text):
    """Doc chuoi nguoi dung go cho 1 dim d (dict cua bm_drawing) -> (key, gia_tri, loi).
      - dim chu (ten truc, tiet dien, dai): tra nguyen chuoi.
      - dim so: 4000 | =4000+250 | 3*1200.
      - cote (unit 'm'): go met (3.6, -0.25) hoac mm (3600); doi ve mm SO VOI LEVEL (tru cote goc d['base'] dang hien thi).
      - cote dinh / day: them dau * o cuoi (3.6*) = ap dung cho TAT CA nhip."""
    key = d['key']
    txt = (text or u'').strip()
    if d.get('text'):
        return key, txt, None
    if key[0] in ('top', 'bot') and txt.endswith(u'*'):
        txt = txt[:-1].strip()
        key = tuple(key) + ('all',)
    val = parse_num(txt)
    if val is None:
        return key, None, u'Giá trị không hợp lệ: "%s" (nhập số hoặc phép tính như =4000+250).' % text
    if d.get('unit') == 'm':
        mm = val if abs(val) >= 1000 else val * 1000.0            # go 3.6 = 3,6 m ; go 3600 = 3600 mm
        val = round(mm - float(d.get('base') or 0.0), 1)
    return key, val, None


class InlineEdit(object):
    def __init__(self, editor):
        import System
        from System.Windows.Forms import TextBox, BorderStyle, HorizontalAlignment
        from System.Drawing import Font, FontStyle
        self.ed = editor
        self.d = None                 # dim dang sua (dict cua bm_drawing: key, x0..y1, cur, text, title)
        self.orig = u''
        self.busy = False
        tb = self.tb = TextBox()
        tb.Visible = False
        tb.BorderStyle = BorderStyle.FixedSingle
        tb.TextAlign = HorizontalAlignment.Center
        tb.Font = Font("Segoe UI", System.Single(9.0), FontStyle.Bold)
        tb.PreviewKeyDown += self.on_pre          # de nhan phim Tab trong KeyDown
        tb.KeyDown += self.on_key
        tb.Leave += self.on_leave
        editor.pb.Controls.Add(tb)

    # ---- danh sach dim theo thu tu doc (tung hang tren xuong, trai sang phai)
    def ordered(self):
        ds = list((self.ed.ctx or {}).get('dims') or [])
        ds.sort(key=lambda d: (round(d['y0'] / 18.0), d['x0']))
        seen, out = set(), []
        for d in ds:
            if d['key'] not in seen:
                seen.add(d['key'])
                out.append(d)
        return out

    def find(self, key):
        for d in self.ordered():
            if d['key'] == key:
                return d
        return None

    # ---- mo / dong
    @property
    def active(self):
        return self.d is not None

    def open(self, d):
        from System.Drawing import Color
        ed = self.ed
        if ed.cur is None:
            return
        if ed.cur in ed.m.samples:
            ed.status.Text = u'Dầm mẫu hướng dẫn không sửa kích thước được.'
            return
        tb = self.tb
        self.d = d
        if d.get('text'):
            self.orig = u'%s' % d.get('cur')
        elif d.get('unit') == 'm':                                    # cote: hien thi met (cote tuyet doi neu dang bat)
            self.orig = u'%.3f' % ((float(d.get('cur') or 0.0) + float(d.get('base') or 0.0)) / 1000.0)
        else:
            self.orig = fmt(d.get('cur'))
        tb.Text = self.orig
        w = int(max(d['x1'] - d['x0'], 70, 8 * len(self.orig) + 20))
        h = 22
        cx, cy = (d['x0'] + d['x1']) / 2.0, (d['y0'] + d['y1']) / 2.0
        x = int(max(0, min(cx - w / 2.0, ed.pb.Width - w)))
        y = int(max(0, cy - h / 2.0))
        tb.SetBounds(x, y, w, h)
        tb.BackColor = Color.FromArgb(255, 250, 205)
        tb.ForeColor = Color.FromArgb(20, 20, 20)
        tb.Visible = True
        tb.BringToFront()
        tb.Focus()
        tb.SelectAll()
        ed.status.Text = (d.get('title') or u'') + u'   [Enter/Tab: sang dim kế · Esc: hủy]'

    def hide(self):
        if self.d is not None:
            self.d = None
            self.tb.Visible = False

    def commit(self):
        """True = da ap dung hoac khong doi; False = gia tri sai (giu o nhap de sua)."""
        d, ed = self.d, self.ed
        txt = (self.tb.Text or u'').strip()
        if txt == self.orig.strip():
            return True
        key, val, err = to_value(d, txt)
        if err:
            ed.status.Text = err
            return False
        self.busy = True
        try:
            ed.flush()
            ok, msg = ed.m.set_dim(ed.cur, key, val)
            if not ok:
                ed.status.Text = msg
                return False
            ed.after_dim(msg)
            try:
                ed.redraw()                 # ve lai ngay de lay vi tri dim moi (Tab sang dim ke tiep)
            except Exception:
                pass
            return True
        finally:
            self.busy = False

    def close(self, commit=True):
        if self.d is None:
            return True
        if commit and not self.commit():
            return False
        self.hide()
        return True

    def click(self, x, y, sel_tool):
        """Goi tu on_md. Tra ve True neu su kien chuot da duoc xu ly (mo o nhap / giu o dang sai)."""
        d = self.ed.hit_dim(x, y) if sel_tool else None
        key = d['key'] if d is not None else None
        if self.d is not None and not self.close(True):
            return True
        if d is None:
            return False
        self.open(self.find(key) or d)
        return True

    # ---- phim
    def on_pre(self, s, e):
        from System.Windows.Forms import Keys
        if e.KeyCode == Keys.Tab:
            e.IsInputKey = True

    def on_key(self, s, e):
        from System.Windows.Forms import Keys
        k = e.KeyCode
        if k == Keys.Escape:
            e.Handled = e.SuppressKeyPress = True
            self.hide()
            self.ed.status.Text = u'Đã hủy sửa.'
            return
        if k in (Keys.Enter, Keys.Tab, Keys.Down):
            step = -1 if e.Shift else 1
        elif k == Keys.Up:
            step = -1
        else:
            return
        e.Handled = e.SuppressKeyPress = True
        keys = [x['key'] for x in self.ordered()]
        nxt = None
        try:
            i = keys.index(self.d['key']) + step
            if 0 <= i < len(keys):
                nxt = keys[i]
        except ValueError:
            pass
        if not self.close(True):
            return
        if nxt is not None:
            dd = self.find(nxt)
            if dd is not None:
                self.open(dd)

    def on_leave(self, s, e):
        if self.d is not None and not self.busy:
            if not self.close(True):
                self.hide()
