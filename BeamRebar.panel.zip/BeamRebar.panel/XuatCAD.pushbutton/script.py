#! python3
# -*- coding: utf-8 -*-
"""
XuatCAD.pushbutton/script.py — Nút bấm pyRevit trong BeamRebar.panel\XuatCAD.pushbutton\ (Revit 2025 + pyRevit 7)
Giao diện WinForms độc lập (không dùng hộp thoại mặc định pyRevit):
  - Nguồn 1: Quét trực tiếp dầm từ Mô hình Revit đang mở (hiển thị ngay danh sách chọn dầm).
  - Nguồn 2: Đọc file Excel Dam_*.xlsx từ BeamRebar (đầy đủ thép chi tiết).
  - Nguồn 3: Quét lại file .DXF đã sửa trong CAD (tính lại KL & cắt bảng).
  - Hỗ trợ 2 đầu ra: [Vẽ thẳng vào AutoCAD đang mở (Pick điểm)] hoặc [Xuất ra file .DXF...].
"""
from __future__ import print_function, unicode_literals
import shutil
import tempfile
import time
import traceback

__title__ = 'Xuất\nCAD DXF'
__doc__ = 'Chọn dầm từ Revit/Excel, thả thẳng vào AutoCAD đang mở (Pick điểm) hoặc xuất DXF chuẩn beam.dxf.'

try:
    import Autodesk.Revit.DB as DB
except Exception:
    DB = None

try:
    import clr
    clr.AddReference('System')
    clr.AddReference('System.Drawing')
    clr.AddReference('System.Windows.Forms')
    import System
    import System.Drawing as Drawing
    import System.Windows.Forms as WinForms
    from System.Runtime.InteropServices import Marshal
except Exception:
    clr = None
    System = None
    Drawing = None
    WinForms = None
    Marshal = None

import io
import math
import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile


def _col_idx(ref):
    c = 0
    for ch in ref:
        if ch.isalpha():
            c = c * 26 + (ord(ch.upper()) - ord('A') + 1)
        else:
            break
    return c - 1


def read_xlsx_rows(path):
    sheets = {}
    with zipfile.ZipFile(path, 'r') as z:
        sst = []
        if 'xl/sharedStrings.xml' in z.namelist():
            root = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.iter():
                if si.tag.endswith('}si'):
                    sst.append(u''.join((t.text or u'') for t in si.iter() if t.tag.endswith('}t')))

        wb_root = ET.fromstring(z.read('xl/workbook.xml'))
        rels_root = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rel_map = {}
        for rel in rels_root:
            rel_map[rel.attrib.get('Id', '')] = rel.attrib.get('Target', '')

        for sh in wb_root.iter():
            if sh.tag.endswith('}sheet'):
                name = sh.attrib.get('name', '')
                rid = ''
                for k, v in sh.attrib.items():
                    if k.endswith('}id') or k == 'r:id':
                        rid = v
                target = rel_map.get(rid, '').lstrip('/')
                if not target.startswith('xl/'):
                    target = 'xl/' + target
                if target not in z.namelist():
                    continue
                sroot = ET.fromstring(z.read(target))
                rows = []
                for row_el in sroot.iter():
                    if row_el.tag.endswith('}row'):
                        row_vals = []
                        for c_el in row_el:
                            if not c_el.tag.endswith('}c'):
                                continue
                            ci = _col_idx(c_el.attrib.get('r', 'A1'))
                            while len(row_vals) <= ci:
                                row_vals.append('')
                            tp = c_el.attrib.get('t', '')
                            val_text = u''
                            for ch in c_el:
                                if ch.tag.endswith('}v'):
                                    val_text = ch.text or u''
                                elif ch.tag.endswith('}is'):
                                    val_text = u''.join((t.text or u'') for t in ch.iter() if t.tag.endswith('}t'))
                            if tp == 's' and val_text.isdigit():
                                idx = int(val_text)
                                val_text = sst[idx] if idx < len(sst) else u''
                            row_vals[ci] = val_text
                        rows.append(row_vals)
                sheets[name] = rows
    return sheets


def num(v, d=0.0):
    if v is None or v == '':
        return d
    try:
        return float(str(v).replace(',', '.').strip())
    except Exception:
        return d


def sstr(v, d=u''):
    if v is None:
        return d
    try:
        return unicode(v).strip()
    except NameError:
        return str(v).strip()


def unit_w(d):
    return (math.pi * d * d / 4.0) * 0.00785


def parse_len(txt, d, L, default='30d'):
    t = sstr(txt or default).replace(',', '.').replace(' ', '')
    if not t:
        return 0.0
    m = re.match(r'^(\d+(?:\.\d+)?)[dD]$', t)
    if m:
        return float(m.group(1)) * d
    m = re.match(r'^[Ll]/(\d+(?:\.\d+)?)$', t)
    if m:
        den = float(m.group(1))
        return L / den if den else 0.0
    m = re.match(r'^(\d+(?:\.\d+)?)[Ll]$', t)
    if m:
        return L * float(m.group(1))
    try:
        return float(t)
    except Exception:
        return 0.0


def is_down(txt):
    t = sstr(txt).lower()
    return t in (u'xuống', 'xuong', 'h', u'sát', 'sat', 'down')


def norm_pos(txt):
    s = sstr(txt).lower()
    if u'trên' in s or 'tren' in s:
        return 'Trên'
    if u'giữa' in s or 'giua' in s:
        return 'Giữa'
    return 'Dưới'


def norm_end(txt):
    s = sstr(txt).lower()
    if u'gập' in s or 'gap' in s:
        return 'Gập vào cột'
    if u'hết' in s or 'het' in s:
        return 'Hết cột / đầu dầm'
    if u'kéo' in s or 'keo' in s:
        return 'Kéo dài ra nhịp'
    if u'cắt' in s or 'cat' in s:
        return 'Cắt trong nhịp'
    if u'giữa' in s or 'giua' in s:
        return 'Giữa gối'
    if u'uốn' in s or 'uon' in s:
        return 'Uốn xiên'
    return 'Neo vào gối'


def norm_cross(txt):
    s = sstr(txt).lower()
    if u'luôn neo' in s or u'cắt' in s:
        return 'Luôn neo (cắt)'
    if u'luôn uốn' in s:
        return 'Luôn uốn'
    if u'thẳng' in s:
        return 'Luôn thẳng (nối liền)'
    return 'Tự động'


def parse_stir_spec(spec):
    nums = re.findall(r'\d+', sstr(spec))
    if len(nums) >= 2:
        d = int(nums[0])
        a1 = int(nums[1])
        a2 = int(nums[2]) if len(nums) >= 3 else a1
        return d, a1, a2
    return 6, 100, 200


def _eid_int(id_obj):
    if id_obj is None:
        return -1
    try:
        return int(id_obj.Value)
    except Exception:
        try:
            return int(id_obj.IntegerValue)
        except Exception:
            return -1


_BULGE_90 = 0.3926990816987241


class DxfOut(object):
    def __init__(self):
        self.buf = []
        self.blocks_buf = []
        self.dim_blocks_buf = []
        self.entities_buf = []
        self.block_records = []
        self.h = 0x300
        self.dim_idx = 20
        self.br_table_h = '1'
        self.ms_br_h = '2'
        self.ps_br_h = '1C'
        self.style_std_h = '27'
        self.style_dce_h = '38'
        self.style_dce2_h = '3A'
        self.arch_tick_br_h = '39'
        self.dot_blank_br_h = '45'
        self._cur_buf = self.buf
        self._cur_owner = self.ms_br_h

    def next_h(self):
        s = '%X' % self.h
        self.h += 1
        return s

    def p(self, c, v, buf=None):
        b = self._cur_buf if buf is None else buf
        b.append(str(c))
        b.append(sstr(v) if not isinstance(v, (int, float)) else str(v))

    def _emit_to(self, target_buf, owner_h):
        self._cur_buf = target_buf
        self._cur_owner = owner_h

    def set_target(self, target):
        if target == 'blocks':
            self._emit_to(self.blocks_buf, self.ms_br_h)
        elif target == 'entities':
            self._emit_to(self.entities_buf, self.ms_br_h)
        elif target == 'dim_blocks':
            self._emit_to(self.dim_blocks_buf, self.ms_br_h)
        else:
            self._emit_to(self.buf, self.ms_br_h)

    def register_block_record(self, bname, br_h):
        self.block_records.append((bname, br_h))

    def emit_block_records_table(self):
        self.set_target('buf')
        self.p(0, 'TABLE'); self.p(2, 'BLOCK_RECORD'); self.p(5, self.br_table_h); self.p(330, '0')
        self.p(100, 'AcDbSymbolTable'); self.p(70, len(self.block_records))
        for bname, br_h in self.block_records:
            self.p(0, 'BLOCK_RECORD'); self.p(5, br_h); self.p(330, self.br_table_h)
            self.p(100, 'AcDbSymbolTableRecord'); self.p(100, 'AcDbBlockTableRecord')
            self.p(2, bname); self.p(70, 0); self.p(280, 1); self.p(281, 0)
        self.p(0, 'ENDTAB')

    def text(self, x, y, h, txt, layer='Dce_text', color=256, ha=0, va=0,
             xdata_app=None, style='Dce_Text', width_factor=0.80, rot=0.0, wf=None):
        if wf is not None:
            width_factor = wf
        self.p(0, 'TEXT'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbText')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(40, '%.4f' % h); self.p(1, txt)
        if rot:
            self.p(50, '%.4f' % rot)
        if abs(width_factor - 1.0) > 1e-4:
            self.p(41, '%.4f' % width_factor)
        self.p(7, style)
        if ha or va:
            self.p(72, ha)
            self.p(11, '%.4f' % x); self.p(21, '%.4f' % y); self.p(31, '0.0')
        self.p(100, 'AcDbText')
        if va:
            self.p(73, va)
        if xdata_app:
            self.p(1001, xdata_app); self.p(1000, '1')

    def mtext(self, x, y, h, txt, layer='DCE_Dim', color=3, attach=5, style='Dce_Text', rot=0.0):
        self.p(0, 'MTEXT'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbMText')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(40, '%.4f' % h); self.p(41, '0.0'); self.p(46, '0.0')
        self.p(71, attach); self.p(72, 1)
        self.p(1, txt); self.p(7, style)
        if abs(rot - 90.0) < 1e-3:
            self.p(11, '0.0'); self.p(21, '1.0'); self.p(31, '0.0')
        elif abs(rot) > 1e-3:
            rad = math.radians(rot)
            self.p(11, '%.6f' % math.cos(rad)); self.p(21, '%.6f' % math.sin(rad)); self.p(31, '0.0')
        self.p(73, 1); self.p(44, '1.0')

    def point(self, x, y, layer='Defpoints', color=0):
        self.p(0, 'POINT'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer); self.p(62, color)
        self.p(100, 'AcDbPoint')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')

    def line(self, x1, y1, x2, y2, layer='DCE_BaoBeTong', color=256, xdata_app=None):
        self.p(0, 'LINE'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbLine')
        self.p(10, '%.4f' % x1); self.p(20, '%.4f' % y1); self.p(30, '0.0')
        self.p(11, '%.4f' % x2); self.p(21, '%.4f' % y2); self.p(31, '0.0')
        if xdata_app:
            self.p(1001, xdata_app); self.p(1000, '1')

    def circle(self, x, y, r, layer='DCE_ThepChu', color=256):
        self.p(0, 'CIRCLE'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbCircle')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0'); self.p(40, '%.4f' % r)

    def pline(self, pts, layer='DCE_ThepChu', closed=False, color=256, xdata_app=None, cw=0.0):
        if len(pts) < 2:
            return
        self.p(0, 'LWPOLYLINE'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbPolyline')
        self.p(90, len(pts)); self.p(70, 1 if closed else 0)
        if cw > 0.0:
            self.p(43, '%.6f' % cw)
        for pt in pts:
            px, py = pt[0], pt[1]
            blg = pt[2] if len(pt) > 2 else 0.0
            self.p(10, '%.4f' % px); self.p(20, '%.4f' % py)
            if abs(blg) > 1e-6:
                self.p(42, '%.8f' % blg)
        if xdata_app:
            self.p(1001, xdata_app); self.p(1000, '1')

    def hatch_poly(self, pts, layer='0', color=256, pattern='SOLID', solid=1, scale=1.0, angle=0.0, visible=True):
        if len(pts) < 3:
            return
        self.p(0, 'HATCH'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        if not visible:
            self.p(60, 1)
        self.p(100, 'AcDbHatch')
        self.p(10, '0.0'); self.p(20, '0.0'); self.p(30, '0.0')
        self.p(210, '0.0'); self.p(220, '0.0'); self.p(230, '1.0')
        self.p(2, pattern); self.p(70, 1 if solid else 0); self.p(71, 0)
        self.p(91, 1); self.p(92, 7); self.p(72, 0); self.p(73, 1); self.p(93, len(pts))
        for px, py in pts:
            self.p(10, '%.4f' % px); self.p(20, '%.4f' % py)
        self.p(97, 0); self.p(75, 0); self.p(76, 1)
        if not solid:
            self.p(52, '%.4f' % angle); self.p(41, '%.6f' % scale); self.p(77, 0)
            self.p(78, 1); self.p(53, '45.0'); self.p(43, '0.0'); self.p(44, '0.0')
            self.p(45, '-3.1571'); self.p(46, '3.1571'); self.p(79, 0)
        self.p(47, '0.05'); self.p(98, 1)
        cx = sum(p[0] for p in pts) / float(len(pts))
        cy = sum(p[1] for p in pts) / float(len(pts))
        self.p(10, '%.4f' % cx); self.p(20, '%.4f' % cy)

    def leader(self, pts, layer='DCE_Dim', dimstyle='Dce_50MV', arrow=0, color=256):
        if len(pts) < 2:
            return
        self.p(0, 'LEADER'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbLeader')
        self.p(3, dimstyle)
        self.p(71, 1 if arrow else 0); self.p(72, 0); self.p(73, 3); self.p(74, 1); self.p(75, 0)
        self.p(76, len(pts))
        for px, py in pts:
            self.p(10, '%.4f' % px); self.p(20, '%.4f' % py); self.p(30, '0.0')

    def dim(self, x1, y1, x2, y2, dx_line, dy_line, layer='DCE_Dim', dim_scale=50.0,
            dimstyle=None, text_override='', suppress_lines=False, rot_deg=None):
        val_f = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        val = int(round(val_f))
        if val < 1 and not text_override:
            return
        if dimstyle is None:
            if abs(dim_scale - 25.0) < 0.5:
                dimstyle = 'Dce_25MV'
            elif abs(dim_scale - 20.0) < 0.5:
                dimstyle = 'Dce_20MV'
            else:
                dimstyle = 'Dce_50MV'
        if rot_deg is None:
            ang_deg = 0.0 if abs(y1 - y2) < 0.5 else 90.0
        else:
            ang_deg = float(rot_deg) % 360.0
        rad = math.radians(ang_deg)
        ux, uy = math.cos(rad), math.sin(rad)
        nx, ny = -uy, ux

        if abs(ang_deg) < 0.5 or abs(ang_deg - 180.0) < 0.5:
            p10 = (x2, dy_line)
            dl1 = (x1, dy_line)
            dl2 = (x2, dy_line)
            tick_ang = 0.0
            txt_pt = ((x1 + x2) / 2.0, dy_line + (2.0 if not suppress_lines else 0.0) * dim_scale)
            meas = abs(x2 - x1)
        elif abs(ang_deg - 90.0) < 0.5 or abs(ang_deg - 270.0) < 0.5:
            p10 = (dx_line, y2)
            dl1 = (dx_line, y1)
            dl2 = (dx_line, y2)
            tick_ang = 90.0
            off_dir = -1.0 if dx_line <= min(x1, x2) + 1.0 else 1.0
            if suppress_lines:
                txt_pt = (dx_line, (y1 + y2) / 2.0)
            else:
                txt_pt = (dx_line + off_dir * 2.0 * dim_scale, (y1 + y2) / 2.0)
            meas = abs(y2 - y1)
        else:
            # Arbitrary rotated dim (e.g. sloped bar segment in TKTUnknown)
            d_off = (dx_line - x2) * nx + (dy_line - y2) * ny
            p10 = (x2 + d_off * nx, y2 + d_off * ny)
            dl1 = (x1 + d_off * nx, y1 + d_off * ny)
            dl2 = p10
            tick_ang = ang_deg
            txt_pt = ((dl1[0] + dl2[0]) / 2.0, (dl1[1] + dl2[1]) / 2.0)
            meas = abs((x2 - x1) * ux + (y2 - y1) * uy)

        self.dim_idx += 1
        bname = '*D%d' % self.dim_idx
        br_h = self.next_h()
        self.block_records.append((bname, br_h))

        # Populate anonymous *D block for CAD/viewer compatibility
        prev_buf, prev_own = self._cur_buf, self._cur_owner
        self._emit_to(self.dim_blocks_buf, br_h)
        self.p(0, 'BLOCK'); self.p(5, self.next_h()); self.p(330, br_h)
        self.p(100, 'AcDbEntity'); self.p(8, '0'); self.p(100, 'AcDbBlockBegin')
        self.p(2, bname); self.p(70, 1); self.p(10, '0.0'); self.p(20, '0.0'); self.p(30, '0.0')
        self.p(3, bname); self.p(1, '')
        if not suppress_lines:
            exe = 1.0 * dim_scale
            exo = 2.0 * dim_scale
            for sx, sy, ex, ey in ((x1, y1, dl1[0], dl1[1]), (x2, y2, dl2[0], dl2[1])):
                vx, vy = ex - sx, ey - sy
                vl = math.hypot(vx, vy)
                if vl > 1e-3:
                    uxv, uyv = vx / vl, vy / vl
                    s_off = min(exo, max(0.0, vl - 1.0))
                    self.line(sx + uxv * s_off, sy + uyv * s_off, ex + uxv * exe, ey + uyv * exe, layer, 8)
            self.line(dl1[0], dl1[1], dl2[0], dl2[1], layer, 8)
            tick_sc = 1.5 * dim_scale
            self.insert('_ArchTick', dl1[0], dl1[1], tick_sc, tick_sc, layer, [], rot=tick_ang, color=8)
            self.insert('_ArchTick', dl2[0], dl2[1], tick_sc, tick_sc, layer, [], rot=(tick_ang + 180.0) % 360.0, color=8)
        disp_txt = text_override if text_override else str(int(round(meas)))
        mrot = 90.0 if abs((ang_deg % 180.0) - 90.0) < 0.5 else (ang_deg if ang_deg not in (0.0, 180.0) else 0.0)
        self.mtext(txt_pt[0], txt_pt[1], 2.0 * dim_scale, disp_txt, layer, 3, 5, 'Dce_Text', rot=mrot)
        self.point(x1, y1, 'Defpoints', 0)
        self.point(x2, y2, 'Defpoints', 0)
        self.point(p10[0], p10[1], 'Defpoints', 0)
        self.p(0, 'ENDBLK'); self.p(5, self.next_h()); self.p(330, br_h)
        self.p(100, 'AcDbEntity'); self.p(8, '0'); self.p(100, 'AcDbBlockEnd')
        self._emit_to(prev_buf, prev_own)

        # Emit real DIMENSION entity in ENTITIES
        self.p(0, 'DIMENSION'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        self.p(100, 'AcDbDimension'); self.p(2, bname)
        self.p(10, '%.4f' % p10[0]); self.p(20, '%.4f' % p10[1]); self.p(30, '0.0')
        self.p(11, '%.4f' % txt_pt[0]); self.p(21, '%.4f' % txt_pt[1]); self.p(31, '0.0')
        self.p(70, 32)
        if text_override:
            self.p(1, text_override)
        self.p(71, 5); self.p(42, '%.4f' % meas); self.p(73, 0); self.p(74, 0); self.p(75, 0)
        self.p(3, dimstyle)
        self.p(100, 'AcDbAlignedDimension')
        self.p(13, '%.4f' % x1); self.p(23, '%.4f' % y1); self.p(33, '0.0')
        self.p(14, '%.4f' % x2); self.p(24, '%.4f' % y2); self.p(34, '0.0')
        if abs(ang_deg) > 1e-3:
            self.p(50, '%.4f' % ang_deg)
        self.p(100, 'AcDbRotatedDimension')
        if suppress_lines:
            self.p(1001, 'ACAD'); self.p(1000, 'DSTYLE'); self.p(1002, '{')
            self.p(1070, 140); self.p(1040, '2.0')
            self.p(1070, 76); self.p(1070, 1)
            self.p(1070, 75); self.p(1070, 1)
            self.p(1070, 282); self.p(1070, 1)
            self.p(1070, 281); self.p(1070, 1)
            self.p(1070, 77); self.p(1070, 0)
            self.p(1002, '}')

    def zigzag_h(self, x0, x1, y):
        xm = (x0 + x1) / 2.0
        self.pline([(x0 - 35.0, y), (xm - 35.0, y), (xm - 35.0, y - 35.0),
                    (xm + 35.0, y + 35.0), (xm + 35.0, y), (x1 + 35.0, y)], 'DCE_MCZiCZac', False)

    def zigzag_v(self, x, y0, y1):
        ym = (y0 + y1) / 2.0
        self.pline([(x, y0 + 26.7), (x, ym + 26.7), (x - 26.7, ym + 26.7),
                    (x + 26.7, ym - 26.7), (x, ym - 26.7), (x, y1 - 26.7)], 'DCE_MCZiCZac', False)

    def attdef(self, tag, prompt, val, x, y, h, color=2, ha=1, va=2, layer='Dce_text', rot=0.0, flg=0):
        self.p(0, 'ATTDEF'); self.p(5, self.next_h()); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbText')
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(40, '%.4f' % h); self.p(1, val)
        if rot:
            self.p(50, '%.4f' % rot)
        self.p(41, '0.80'); self.p(7, 'Dce_Text')
        if ha or va:
            self.p(72, ha); self.p(11, '%.4f' % x); self.p(21, '%.4f' % y); self.p(31, '0.0')
        self.p(100, 'AcDbAttributeDefinition')
        self.p(3, prompt); self.p(2, tag); self.p(70, flg)
        if va:
            self.p(74, va)

    def insert(self, bname, x, y, sx, sy, layer, atts, xdata=None, rot=0.0, color=256):
        ins_h = self.next_h()
        self.p(0, 'INSERT'); self.p(5, ins_h); self.p(330, self._cur_owner)
        self.p(100, 'AcDbEntity'); self.p(8, layer)
        if color != 256:
            self.p(62, color)
        self.p(100, 'AcDbBlockReference')
        if atts:
            self.p(66, 1)
        self.p(2, bname)
        self.p(10, '%.4f' % x); self.p(20, '%.4f' % y); self.p(30, '0.0')
        self.p(41, '%.4f' % sx); self.p(42, '%.4f' % sy); self.p(43, '%.4f' % sx)
        if rot:
            self.p(50, '%.4f' % rot)
        if xdata:
            self.p(1001, xdata[0])
            for xv in xdata[1]:
                self.p(1000, xv)
        if atts:
            rad = math.radians(rot)
            cr, sr = math.cos(rad), math.sin(rad)
            for item in atts:
                if len(item) >= 9:
                    tag, val, dx, dy, h, col, ha, va, alay = item[:9]
                    arot = item[9] if len(item) > 9 else rot
                else:
                    tag, val, dx, dy, h, col, ha = item[:7]
                    va = item[7] if len(item) > 7 else 2
                    alay = 'Dce_text'
                    arot = rot
                lx, ly = dx * sx, dy * sy
                ax = x + lx * cr - ly * sr
                ay = y + lx * sr + ly * cr
                ah = h * abs(sy)
                self.p(0, 'ATTRIB'); self.p(5, self.next_h()); self.p(330, ins_h)
                self.p(100, 'AcDbEntity'); self.p(8, alay)
                if col != 256:
                    self.p(62, col)
                self.p(100, 'AcDbText')
                self.p(10, '%.4f' % ax); self.p(20, '%.4f' % ay); self.p(30, '0.0')
                self.p(40, '%.4f' % ah); self.p(1, val)
                if arot:
                    self.p(50, '%.4f' % arot)
                self.p(41, '0.80'); self.p(7, 'Dce_Text')
                if ha or va:
                    self.p(72, ha); self.p(11, '%.4f' % ax); self.p(21, '%.4f' % ay); self.p(31, '0.0')
                self.p(100, 'AcDbAttribute')
                self.p(2, tag); self.p(70, 0)
                if va:
                    self.p(74, va)
            self.p(0, 'SEQEND'); self.p(5, self.next_h()); self.p(330, ins_h)
            self.p(100, 'AcDbEntity'); self.p(8, layer)



def build_group_polylines(g, spans, sups, lay, opt):
    n = lay['n']
    if n == 0 or g['a'] < 0 or g['b'] > n or g['a'] > g['b']:
        return []
    pos, d, layer, a, b = g['pos'], g['d'], g['layer'], g['a'], g['b']
    s0 = a - 1 if (g['lk'] == 'Kéo dài ra nhịp' and a > 0) else a
    s1 = b if (g['rk'] == 'Kéo dài ra nhịp' and b < n) else (b - 1)
    s0 = min(max(s0, 0), n - 1)
    s1 = min(max(s1, 0), n - 1)
    if s0 > s1:
        return []

    cov, stir, pitch = opt['cover'], opt['stir'], opt['pitch']

    def span_y(sp):
        t = lay['maxtop'] - sp['top']
        return t, t + sp['h']

    def y_line(sp):
        t, bt = span_y(sp)
        if pos == 'Giữa':
            frac = 1.0 / 3.0 if layer == 2 else (2.0 / 3.0 if layer == 3 else 0.5)
            return t + (bt - t) * frac
        off = cov + stir + d / 2.0 + (layer - 1) * (d + pitch)
        return t + off if pos == 'Trên' else bt - off

    ys = {s: y_line(spans[s]) for s in range(s0, s1 + 1)}
    modes = {}
    cmode = g['cross']
    for j in range(s0, s1):
        dy = abs(ys[j + 1] - ys[j])
        if cmode == 'Luôn neo (cắt)':
            modes[j] = 'split'
        elif cmode == 'Luôn thẳng (nối liền)':
            modes[j] = 'straight'
        elif cmode == 'Luôn uốn':
            modes[j] = 'jog' if dy >= 0.5 else 'straight'
        else:
            modes[j] = 'straight' if dy <= opt['straight'] + 1e-6 else ('jog' if dy <= opt['thr'] + 1e-6 else 'split')

    j = s0
    while j <= s1:
        k = j
        while k < s1 and modes[k] == 'straight':
            k += 1
        if k > j:
            vals = [ys[q] for q in range(j, k + 1)]
            yc = max(vals) if pos == 'Trên' else (min(vals) if pos == 'Dưới' else sum(vals) / len(vals))
            for q in range(j, k + 1):
                ys[q] = yc
        j = k + 1

    sign = -1.0 if pos == 'Dưới' else 1.0
    xL = lambda k: lay['sx0'][k]
    xR = lambda k: lay['sx0'][k] + sups[k]['w']
    cl = lambda i: spans[i]['clear'] if 0 <= i < n else 0.0
    cap = lambda k: max(sups[k]['w'] - cov, 0.0)

    def gap_leg(txt, sp_i, y0):
        t, bt = span_y(sp_i)
        full = (y0 - (t + cov + stir + d + 25.0)) if pos == 'Dưới' else (bt - cov - stir - d - 25.0 - y0)
        full = max(full, 15.0 * d)
        if is_down(txt or opt['gap']):
            return full
        v = parse_len(txt, d, 0.0, opt['gap'])
        return min(v if v > 0 else 15.0 * d, full)

    off_h = cov + d / 2.0 + (layer - 1) * (d + pitch)
    y0 = ys[s0]
    lk = 'Hết cột / đầu dầm' if (g['lk'] == 'Kéo dài ra nhịp' and a == 0) else g['lk']
    if lk == 'Neo vào gối':
        need = parse_len(g['lv'], d, cl(a), opt['neo'])
        if a == 0 and pos != 'Giữa' and sups[a]['w'] > 0.5 and need > cap(a) + 1.0:
            xh = xL(a) + off_h
            leg = min(max(need - cap(a), 15.0 * d), gap_leg('xuống', spans[s0], y0))
            pts = [(xh, y0 + sign * leg), (xh, y0)]
        else:
            pts = [(xR(a) - min(need, cap(a)), y0)]
    elif lk == 'Hết cột / đầu dầm':
        pts = [(xL(a) + cov, y0)]
    elif lk == 'Giữa gối':
        pts = [(xL(a) + sups[a]['w'] / 2.0, y0)]
    elif lk == 'Kéo dài ra nhịp':
        pts = [(xL(a) - parse_len(g['lv'], d, cl(a - 1), opt['ext']), y0)]
    elif lk == 'Cắt trong nhịp':
        pts = [(xR(a) + parse_len(g['lv'], d, cl(a), 'L/4'), y0)]
    elif lk == 'Gập vào cột':
        xh = xL(a) + off_h
        pts = [(xh, y0 + sign * gap_leg(g['lv'], spans[s0], y0)), (xh, y0)]
    else:
        pts = [(xL(a) + cov, y0)]

    y1 = ys[s1]
    rk = 'Hết cột / đầu dầm' if (g['rk'] == 'Kéo dài ra nhịp' and b == n) else g['rk']
    if rk == 'Neo vào gối':
        need = parse_len(g['rv'], d, cl(b - 1), opt['neo'])
        if b == n and pos != 'Giữa' and sups[b]['w'] > 0.5 and need > cap(b) + 1.0:
            xh = xR(b) - off_h
            leg = min(max(need - cap(b), 15.0 * d), gap_leg('xuống', spans[s1], y1))
            rp = [(xh, y1), (xh, y1 + sign * leg)]
        else:
            rp = [(xL(b) + min(need, cap(b)), y1)]
    elif rk == 'Hết cột / đầu dầm':
        rp = [(xR(b) - cov, y1)]
    elif rk == 'Giữa gối':
        rp = [(xL(b) + sups[b]['w'] / 2.0, y1)]
    elif rk == 'Kéo dài ra nhịp':
        rp = [(xR(b) + parse_len(g['rv'], d, cl(b), opt['ext']), y1)]
    elif rk == 'Cắt trong nhịp':
        rp = [(xL(b) - parse_len(g['rv'], d, cl(b - 1), 'L/4'), y1)]
    elif rk == 'Gập vào cột':
        xh = xR(b) - off_h
        rp = [(xh, y1), (xh, y1 + sign * gap_leg(g['rv'], spans[s1], y1))]
    else:
        rp = [(xR(b) - cov, y1)]

    lines = []
    cur = list(pts)
    lan = max(parse_len(opt['neo'], d, 0.0, '30d'), 200.0)
    for idx in range(s0, s1):
        k = idx + 1
        yl, yr = ys[idx], ys[idx + 1]
        dy = abs(yr - yl)
        m = modes[idx]
        if m == 'split':
            av = cap(k)
            if dy >= 0.5 and pos != 'Giữa':
                cur.append((min(xL(k) + av, xR(k)), yl))
                lines.append(cur)
                cur = [(max(xR(k) - av, xL(k)), yr)]
            else:
                cur.append((xL(k) + min(lan, av), yl))
                lines.append(cur)
                cur = [(xR(k) - min(lan, av), yr)]
        elif m == 'jog' and dy >= 0.5:
            xc = (xL(k) + xR(k)) / 2.0
            run = opt['slope'] * dy
            cur.append((xc - run / 2.0, yl))
            cur.append((xc + run / 2.0, yr))
    cur.extend(rp)
    lines.append(cur)

    clean = []
    for ln in lines:
        q = [ln[0]]
        for p in ln[1:]:
            if abs(p[0] - q[-1][0]) > 0.01 or abs(p[1] - q[-1][1]) > 0.01:
                q.append(p)
        if len(q) > 1:
            clean.append(q)
    return clean


def classify_poly(pts):
    segs = []
    for i in range(len(pts) - 1):
        dx = pts[i + 1][0] - pts[i][0]
        dy = pts[i + 1][1] - pts[i][1]
        ln = int(round(math.hypot(dx, dy)))
        if ln >= 5:
            segs.append((dx, dy, ln))
    sumL = sum(s[2] for s in segs)
    if len(segs) <= 1:
        return 'TK1', sumL, 0, 0, 0, 0, sumL
    if len(segs) == 2:
        shp = 'TK2' if abs(segs[0][1]) > abs(segs[0][0]) else 'TK3'
        return shp, segs[0][2], segs[1][2], 0, 0, 0, sumL
    if len(segs) == 3:
        shp = 'TK7' if segs[0][1] < 0 else 'TK4'
        return shp, segs[0][2], segs[1][2], segs[2][2], 0, 0, sumL
    if len(segs) == 5:
        return 'TK7R1', segs[0][2], segs[1][2], segs[2][2], segs[3][2], segs[4][2], sumL
    return 'TKTUnknown', sumL, 0, 0, 0, 0, sumL


def _bend_cad_polyline(cad_pts, pos='Trên', fillet_r=30.0, hook_ret=70.0):
    """Add 20-deg 70mm inward hook ticks and 90-deg rounded corner bulges matching beam.dxf."""
    if not cad_pts or len(cad_pts) < 2:
        return [(p[0], p[1], 0.0) for p in (cad_pts or [])]

    def _seg_dir(p0, p1):
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        ln = math.hypot(dx, dy)
        return (dx / ln, dy / ln, ln) if ln > 1e-6 else (1.0, 0.0, 0.0)

    def _inward_normal(ux, uy, default_ny):
        if abs(ux) >= abs(uy):
            # Horizontal bar: top points down (-1), bottom points up (+1)
            ny = -1.0 if pos == 'Trên' else (1.0 if pos == 'Dưới' else default_ny)
            return (0.0, ny)
        # Vertical leg: normal points toward interior (determined by default_nx passed in)
        return (default_ny, 0.0)

    mid_x = sum(p[0] for p in cad_pts) / float(len(cad_pts))
    pts = list(cad_pts)
    out = []

    # Start hook return tick (20 deg inward, length hook_ret)
    ux0, uy0, _ = _seg_dir(pts[0], pts[1])
    if abs(ux0) >= abs(uy0):
        nx0, ny0 = _inward_normal(ux0, uy0, -1.0)
    else:
        nx0 = 1.0 if pts[0][0] <= mid_x else -1.0
        ny0 = 0.0
    ang20_c = math.cos(math.radians(20.0))
    ang20_s = math.sin(math.radians(20.0))
    tick_s = (
        pts[0][0] + hook_ret * (ux0 * ang20_c + nx0 * ang20_s),
        pts[0][1] + hook_ret * (uy0 * ang20_c + ny0 * ang20_s),
        0.0
    )
    out.append(tick_s)

    n = len(pts)
    for i, p in enumerate(pts):
        if 0 < i < n - 1:
            u1x, u1y, l1 = _seg_dir(pts[i - 1], p)
            u2x, u2y, l2 = _seg_dir(p, pts[i + 1])
            dot = u1x * u2x + u1y * u2y
            cross = u1x * u2y - u1y * u2x
            # Fillet 90-degree corners (dot near 0)
            if abs(dot) < 0.25 and l1 > 40.0 and l2 > 40.0:
                r = min(fillet_r, l1 * 0.4, l2 * 0.4)
                p_in = (p[0] - u1x * r, p[1] - u1y * r)
                p_out = (p[0] + u2x * r, p[1] + u2y * r)
                bulge = _BULGE_90 if cross > 0.0 else -_BULGE_90
                out.append((p_in[0], p_in[1], bulge))
                out.append((p_out[0], p_out[1], 0.0))
                continue
        out.append((p[0], p[1], 0.0))

    # End hook return tick
    ux1, uy1, _ = _seg_dir(pts[-2], pts[-1])
    bx, by = -ux1, -uy1
    if abs(bx) >= abs(by):
        nx1, ny1 = _inward_normal(bx, by, -1.0)
    else:
        nx1 = 1.0 if pts[-1][0] <= mid_x else -1.0
        ny1 = 0.0
    tick_e = (
        pts[-1][0] + hook_ret * (bx * ang20_c + nx1 * ang20_s),
        pts[-1][1] + hook_ret * (by * ang20_c + ny1 * ang20_s),
        0.0
    )
    out.append(tick_e)
    return out


def _draw_tkt_unknown_diagram(dxf, raw_cad_pts, cx_col, row_top_y, row_h=675.0):
    """Draw scaled rebar shape + suppressed-line segment DIMENSIONs inside TKTUnknown cell."""
    if not raw_cad_pts or len(raw_cad_pts) < 2:
        return
    xs = [p[0] for p in raw_cad_pts]
    ys = [p[1] for p in raw_cad_pts]
    w_raw = max(1.0, max(xs) - min(xs))
    h_raw = max(1.0, max(ys) - min(ys))
    cell_x0 = cx_col + 1450.0
    cell_x1 = cx_col + 3550.0
    cell_y0 = row_top_y - row_h + 150.0
    cell_y1 = row_top_y - 240.0
    sc_x = (cell_x1 - cell_x0) / w_raw
    sc_y = (cell_y1 - cell_y0) / max(h_raw, 120.0)
    sc = min(sc_x, sc_y)
    # Keep horizontal compression readable for multi-span beams while bounding height
    sc_hx = min(sc_x, max(sc * 1.4, sc_x))
    cx_raw = (min(xs) + max(xs)) / 2.0
    cy_raw = (min(ys) + max(ys)) / 2.0
    cx_dst = (cell_x0 + cell_x1) / 2.0
    cy_dst = row_top_y - row_h * 0.62

    mapped = []
    for p in raw_cad_pts:
        mx = cx_dst + (p[0] - cx_raw) * sc_hx
        my = cy_dst + (p[1] - cy_raw) * sc
        mapped.append((mx, my))

    dxf.pline(mapped, 'DCE_ThepChu', False, 256)
    for i in range(len(mapped) - 1):
        p1, p2 = mapped[i], mapped[i + 1]
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        seg_d = math.hypot(dx, dy)
        if seg_d < 8.0:
            continue
        raw_len = int(round(math.hypot(raw_cad_pts[i + 1][0] - raw_cad_pts[i][0],
                                       raw_cad_pts[i + 1][1] - raw_cad_pts[i][1])))
        if raw_len < 5:
            continue
        ang_deg = math.degrees(math.atan2(dy, dx)) % 360.0
        nx, ny = -dy / seg_d, dx / seg_d
        if ny < -0.5 or (abs(ny) < 0.2 and nx < 0):
            nx, ny = -nx, -ny
        dim_x = (p1[0] + p2[0]) / 2.0 + nx * 87.5
        dim_y = (p1[1] + p2[1]) / 2.0 + ny * 87.5
        dxf.dim(p1[0], p1[1], p2[0], p2[1], dim_x, dim_y, 'DCE_Dim', 50.0,
                text_override=str(raw_len), dimstyle='Dce_50MV', rot_deg=ang_deg,
                suppress_lines=True)



def read_excel_beam_names(xlsx_path):
    wb = read_xlsx_rows(xlsx_path)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        return []
    names = []
    seen = set()
    for r in nhip[1:]:
        if not r or not sstr(r[0]):
            continue
        nm = sstr(r[0])
        if nm not in seen:
            seen.add(nm)
            names.append(nm)
    return names


def read_excel_beam_summaries(xlsx_path):
    wb = read_xlsx_rows(xlsx_path)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        return []
    hdr = [sstr(h) for h in nhip[0]]
    col = {h: i for i, h in enumerate(hdr)}
    c_b = col.get('b (mm)', 14)
    c_h = col.get('h (mm)', 15)
    c_sl = col.get('SL', 1)
    c_st = col.get(u'Đai (Ø-a gối/a nhịp)', 34)
    grouped = {}
    order = []
    for r in nhip[1:]:
        if not r or not sstr(r[0]):
            continue
        nm = sstr(r[0])
        if nm not in grouped:
            grouped[nm] = {'spans': 0, 'b': 0, 'h': 0, 'sl': 1, 'stir': ''}
            order.append(nm)
        g = grouped[nm]
        g['spans'] += 1
        g['b'] = int(round(num(r[c_b] if c_b < len(r) else 220, 220)))
        g['h'] = int(round(num(r[c_h] if c_h < len(r) else 500, 500)))
        g['sl'] = max(1, int(round(num(r[c_sl] if c_sl < len(r) else 1, 1))))
        if c_st < len(r) and sstr(r[c_st]):
            g['stir'] = sstr(r[c_st])
    out = []
    for nm in order:
        g = grouped[nm]
        note = u'SL: %d' % g['sl']
        if g['stir']:
            note += u' | Đai Ø%s' % g['stir']
        out.append((nm, g['spans'], u'%d×%d' % (g['b'], g['h']), note))
    return out


def _write_cad_drop_lisp(dxf_path):
    lsp_path = os.path.splitext(dxf_path)[0] + '_drop.lsp'
    dxf_posix = dxf_path.replace('\\', '/')
    bname_tmp = os.path.splitext(os.path.basename(dxf_path))[0]
    lsp_lines = [
        u'(defun _bc-drop (/ pt doc spc blk)',
        u'  (vl-load-com)',
        u'  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))',
        u'  (setq spc (vla-get-ModelSpace doc))',
        u'  (setq pt (getpoint "\\n[BeamCAD] Pick diem chen ban ve dam trong AutoCAD: "))',
        u'  (if pt',
        u'    (progn',
        u'      (setq blk (vl-catch-all-apply (quote vla-InsertBlock) (list spc (vlax-3d-point pt) "%s" 1.0 1.0 1.0 0.0)))' % dxf_posix,
        u'      (if (not (vl-catch-all-error-p blk))',
        u'        (progn',
        u'          (vl-catch-all-apply (quote vla-Explode) (list blk))',
        u'          (vl-catch-all-apply (quote vla-Delete) (list blk))',
        u'          (vl-catch-all-apply (quote (lambda () (vla-Delete (vla-Item (vla-get-Blocks doc) "%s")))))' % bname_tmp,
        u'        )',
        u'        (command "._-INSERT" "*%s" "_non" pt 1 0)' % dxf_posix,
        u'      )',
        u'      (vla-Regen doc acAllViewports)',
        u'      (princ "\\n[BeamCAD] Da tha ban ve dam & bang thong ke tai diem da pick!")',
        u'    )',
        u'  )',
        u'  (princ)',
        u')',
        u'(_bc-drop)',
    ]
    with io.open(lsp_path, 'w', encoding='utf-8') as f:
        f.write(u'\r\n'.join(lsp_lines) + u'\r\n')
    return lsp_path.replace('\\', '/')


def parse_beam_selection(sel_text, all_names):
    if sel_text is None:
        return list(all_names)
    raw = sstr(sel_text).strip()
    up = raw.upper()
    if not up or up in ('ALL', '*'):
        return list(all_names)
    picked = []
    seen = set()
    for tok in re.split(r'[,;\s]+', raw):
        tok = tok.strip()
        if not tok:
            continue
        m_rng = re.match(r'^(\d+)-(\d+)$', tok)
        if m_rng:
            a, b = int(m_rng.group(1)), int(m_rng.group(2))
            lo, hi = min(a, b), max(a, b)
            for idx in range(lo, hi + 1):
                if 1 <= idx <= len(all_names):
                    nm = all_names[idx - 1]
                    if nm not in seen:
                        seen.add(nm)
                        picked.append(nm)
            continue
        if tok.isdigit():
            idx = int(tok)
            if 1 <= idx <= len(all_names):
                nm = all_names[idx - 1]
                if nm not in seen:
                    seen.add(nm)
                    picked.append(nm)
            continue
        for nm in all_names:
            if nm.upper() == tok.upper() and nm not in seen:
                seen.add(nm)
                picked.append(nm)
    return picked


def build_dxf_from_excel(xlsx_path, out_dxf, split_limit=30, elev_scale=50, sec_scale=25, selected_beams=None):
    s_elev = max(5, int(round(elev_scale or 50)))
    s_sec = max(5, int(round(sec_scale or 25)))
    k_elev = s_elev / 50.0
    k_sec = s_sec / 25.0
    wb = read_xlsx_rows(xlsx_path)
    nhip = wb.get('Nhip', [])
    if len(nhip) < 2:
        raise ValueError('File Excel khong co sheet Nhip hop le.')
    hdr = [sstr(h) for h in nhip[0]]
    col = {h: i for i, h in enumerate(hdr)}

    def gc(row, key, fallback):
        idx = col.get(key, fallback)
        return row[idx] if idx < len(row) else None

    opt = {'cover': 25.0, 'straight': 0.0, 'short': 1500.0, 'neo': '30d', 'gap': u'xuống', 'ext': 'L/3',
           'thr': 100.0, 'slope': 6.0, 'stir': 8.0, 'pitch': 25.0}
    for r in wb.get('CaiDat', [])[1:]:
        if not r or len(r) < 2:
            continue
        k = sstr(r[0])
        if k == u'Lớp bảo vệ (mm)' and num(r[1]) > 0:
            opt['cover'] = num(r[1])
        elif u'chạy thẳng liền' in k:
            opt['straight'] = num(r[1], 0.0)
        elif u'Nhịp < x mm' in k and num(r[1]) > 0:
            opt['short'] = num(r[1])
        elif k == u'Chiều dài neo mặc định' and sstr(r[1]):
            opt['neo'] = sstr(r[1])
        elif k == u'Chiều dài gập mặc định' and sstr(r[1]):
            opt['gap'] = sstr(r[1])
        elif k == u'Kéo dài ra nhịp mặc định' and sstr(r[1]):
            opt['ext'] = sstr(r[1])
        elif u'Ngưỡng lệch tiết diện' in k and num(r[1]) > 0:
            opt['thr'] = num(r[1])
        elif u'Độ dốc uốn' in k and num(r[1]) > 0:
            opt['slope'] = num(r[1])
        elif u'giữa các lớp thép' in k and num(r[1]) > 0:
            opt['pitch'] = num(r[1])

    level_z = 0.0
    for r in wb.get('Info', []):
        if r and len(r) >= 2 and sstr(r[0]) == u'Cao độ tầng theo Project Base Point (mm)':
            level_z = num(r[1], 0.0)

    groups_map = {}
    for tr in wb.get('Thep', [])[1:]:
        if not tr or not sstr(tr[0]) or len(tr) < 10:
            continue
        bn = sstr(tr[0])
        groups_map.setdefault(bn, []).append({
            'pos': norm_pos(tr[2]),
            'layer': max(1, int(round(num(tr[3], 1)))),
            'n': max(1, int(round(num(tr[4], 2)))),
            'd': max(6, int(round(num(tr[5], 16)))),
            'a': max(0, int(round(num(tr[6], 0)))),
            'lk': norm_end(tr[7]),
            'lv': sstr(tr[8]),
            'b': max(1, int(round(num(tr[9], 1)))),
            'rk': norm_end(tr[10]) if len(tr) > 10 else 'Neo vào gối',
            'rv': sstr(tr[11]) if len(tr) > 11 else '',
            'cross': norm_cross(tr[12]) if len(tr) > 12 else 'Tự động',
        })

    beams_raw = {}
    order = []
    for r in nhip[1:]:
        if not r or not sstr(r[0]):
            continue
        nm = sstr(r[0])
        if nm not in beams_raw:
            beams_raw[nm] = []
            order.append(nm)
        beams_raw[nm].append(r)

    if selected_beams is not None:
        sel_set = set(sstr(x) for x in selected_beams)
        filtered = [nm for nm in order if nm in sel_set]
        if filtered:
            order = filtered

    dxf = DxfOut()

    def _emit_dimstyle(name, dimscale, txth=2.0, blk1_h=None, blk2_h=None):
        b1 = blk1_h if blk1_h is not None else dxf.arch_tick_br_h
        b2 = blk2_h if blk2_h is not None else dxf.arch_tick_br_h
        dxf.p(0, 'DIMSTYLE'); dxf.p(105, dxf.next_h()); dxf.p(330, 'A')
        dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbDimStyleTableRecord')
        dxf.p(2, name); dxf.p(70, 0)
        dxf.p(3, ''); dxf.p(4, '')
        dxf.p(40, '%.1f' % dimscale)
        dxf.p(41, '1.5'); dxf.p(42, '2.0'); dxf.p(43, '3.75'); dxf.p(44, '1.0')
        dxf.p(45, '5.0'); dxf.p(49, '4.0'); dxf.p(140, '%.1f' % txth); dxf.p(141, '2.5')
        dxf.p(147, '1.0'); dxf.p(171, 3); dxf.p(172, 1); dxf.p(173, 1); dxf.p(174, 1)
        dxf.p(176, 8); dxf.p(177, 8); dxf.p(178, 3); dxf.p(271, 0); dxf.p(274, 3)
        dxf.p(278, 44); dxf.p(279, 2); dxf.p(283, 0); dxf.p(289, 3); dxf.p(290, 1)
        dxf.p(340, dxf.style_dce_h); dxf.p(341, b1); dxf.p(342, b2)

    # HEADER SECTION (beam.dxf compatible)
    dxf.p(0, 'SECTION'); dxf.p(2, 'HEADER')
    dxf.p(9, '$ACADVER'); dxf.p(1, 'AC1015')
    dxf.p(9, '$LTSCALE'); dxf.p(40, '20.0')
    dxf.p(9, '$TEXTSTYLE'); dxf.p(7, 'Dce_Text')
    dxf.p(9, '$DIMSCALE'); dxf.p(40, '20.0')
    dxf.p(9, '$DIMASZ'); dxf.p(40, '1.5')
    dxf.p(9, '$DIMEXO'); dxf.p(40, '2.0')
    dxf.p(9, '$DIMEXE'); dxf.p(40, '1.0')
    dxf.p(9, '$DIMTXT'); dxf.p(40, '2.0')
    dxf.p(9, '$DIMGAP'); dxf.p(40, '1.0')
    dxf.p(9, '$DIMSTYLE'); dxf.p(2, 'Dce_50MV')
    dxf.p(9, '$MEASUREMENT'); dxf.p(70, 1)
    dxf.p(9, '$INSUNITS'); dxf.p(70, 4)
    dxf.p(9, '$DIMASSOC'); dxf.p(280, 1)
    dxf.p(0, 'ENDSEC')

    # TABLES SECTION
    dxf.p(0, 'SECTION'); dxf.p(2, 'TABLES')
    dxf.p(0, 'TABLE'); dxf.p(2, 'LTYPE'); dxf.p(5, '5'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 5)
    for lt_name, lt_h in (('ByBlock', '14'), ('ByLayer', '15')):
        dxf.p(0, 'LTYPE'); dxf.p(5, lt_h); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
        dxf.p(2, lt_name); dxf.p(70, 0); dxf.p(3, ''); dxf.p(72, 65); dxf.p(73, 0); dxf.p(40, '0.0')
    dxf.p(0, 'LTYPE'); dxf.p(5, '16'); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
    dxf.p(2, 'CONTINUOUS'); dxf.p(70, 0); dxf.p(3, 'Solid line'); dxf.p(72, 65); dxf.p(73, 0); dxf.p(40, '0.0')
    dxf.p(0, 'LTYPE'); dxf.p(5, dxf.next_h()); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
    dxf.p(2, 'DASHDOT2_DBIM'); dxf.p(70, 0); dxf.p(3, 'Dash dot _._._.'); dxf.p(72, 65); dxf.p(73, 4); dxf.p(40, '18.5')
    dxf.p(49, '12.0'); dxf.p(74, 0); dxf.p(49, '-3.0'); dxf.p(74, 0); dxf.p(49, '0.5'); dxf.p(74, 0); dxf.p(49, '-3.0'); dxf.p(74, 0)
    dxf.p(0, 'LTYPE'); dxf.p(5, dxf.next_h()); dxf.p(330, '5'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLinetypeTableRecord')
    dxf.p(2, 'HIDDEN2'); dxf.p(70, 0); dxf.p(3, 'Hidden (.5x) __ __ __'); dxf.p(72, 65); dxf.p(73, 2); dxf.p(40, '4.7625')
    dxf.p(49, '3.175'); dxf.p(74, 0); dxf.p(49, '-1.5875'); dxf.p(74, 0)
    dxf.p(0, 'ENDTAB')

    layers_def = [
        ('0', 7, 'CONTINUOUS', 1),
        ('DCE_BaoBeTong', 4, 'CONTINUOUS', 1),
        ('DCE_ThepChu', 1, 'CONTINUOUS', 1),
        ('DCE_ThepDai', 220, 'CONTINUOUS', 1),
        ('DCE_Dim', 254, 'CONTINUOUS', 1),
        ('DCE_Truc', 8, 'DASHDOT2_DBIM', 1),
        ('DCE_MCZiCZac', 144, 'CONTINUOUS', 1),
        ('Dce_text', 7, 'CONTINUOUS', 1),
        ('DCE_Lanh_To', 3, 'CONTINUOUS', 1),
        ('DCE_Block', 8, 'CONTINUOUS', 1),
        ('3', 3, 'HIDDEN2', 1),
        ('Dce_ViTriThep', 7, 'CONTINUOUS', 1),
        ('Defpoints', 7, 'CONTINUOUS', 0),
    ]
    dxf.p(0, 'TABLE'); dxf.p(2, 'LAYER'); dxf.p(5, '20'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, len(layers_def))
    for lname, lcol, ltp, lplot in layers_def:
        dxf.p(0, 'LAYER'); dxf.p(5, '10' if lname == '0' else dxf.next_h()); dxf.p(330, '20')
        dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbLayerTableRecord')
        dxf.p(2, lname); dxf.p(70, 0); dxf.p(62, lcol); dxf.p(6, ltp); dxf.p(290, lplot); dxf.p(370, -3)
    dxf.p(0, 'ENDTAB')

    dxf.p(0, 'TABLE'); dxf.p(2, 'STYLE'); dxf.p(5, '3'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 3)
    for st, sh_h, wf in (('Standard', '11', 1.0), ('Dce_Text', dxf.style_dce_h, 0.8), ('Dce_Text2', dxf.style_dce2_h, 1.0)):
        dxf.p(0, 'STYLE'); dxf.p(5, sh_h); dxf.p(330, '3'); dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbTextStyleTableRecord')
        dxf.p(2, st); dxf.p(70, 0); dxf.p(40, '0.0'); dxf.p(41, '%.2f' % wf)
        dxf.p(50, '0.0'); dxf.p(71, 0); dxf.p(42, '2.5'); dxf.p(3, 'arial.ttf'); dxf.p(4, '')
    dxf.p(0, 'ENDTAB')

    dxf.p(0, 'TABLE'); dxf.p(2, 'VIEW'); dxf.p(5, '6'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 0); dxf.p(0, 'ENDTAB')
    dxf.p(0, 'TABLE'); dxf.p(2, 'UCS'); dxf.p(5, '7'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 0); dxf.p(0, 'ENDTAB')
    dxf.p(0, 'TABLE'); dxf.p(2, 'APPID'); dxf.p(5, '9'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 5)
    for app in ('ACAD', 'DCEThongKeThep', 'DcePro', 'BeamCAD_SUM', 'BeamCAD_SKC'):
        dxf.p(0, 'APPID'); dxf.p(5, '12' if app == 'ACAD' else dxf.next_h()); dxf.p(330, '9')
        dxf.p(100, 'AcDbSymbolTableRecord'); dxf.p(100, 'AcDbRegAppTableRecord'); dxf.p(2, app); dxf.p(70, 0)
    dxf.p(0, 'ENDTAB')

    dxf.p(0, 'TABLE'); dxf.p(2, 'DIMSTYLE'); dxf.p(5, 'A'); dxf.p(330, '0'); dxf.p(100, 'AcDbSymbolTable'); dxf.p(70, 5)
    dxf.p(100, 'AcDbDimStyleTable'); dxf.p(71, 1)
    _emit_dimstyle('Standard', 20.0, 2.0)
    _emit_dimstyle('Dce_20MV', 20.0, 2.0)
    _emit_dimstyle('Dce_25MV', 25.0, 2.0)
    _emit_dimstyle('Dce_50MV', 50.0, 2.0)
    _emit_dimstyle('Dce_207MV', 25.0, 2.5, dxf.dot_blank_br_h, dxf.arch_tick_br_h)
    dxf.p(0, 'ENDTAB')

    # Build BLOCKS into dxf.blocks_buf first, then collect BLOCK_RECORD handles
    dxf.set_target('blocks')

    def start_blk(bname, br_handle=None):
        br_h = br_handle or dxf.next_h()
        dxf.register_block_record(bname, br_h)
        dxf._cur_owner = br_h
        dxf.p(0, 'BLOCK'); dxf.p(5, dxf.next_h()); dxf.p(330, br_h); dxf.p(100, 'AcDbEntity'); dxf.p(8, '0')
        dxf.p(100, 'AcDbBlockBegin'); dxf.p(2, bname); dxf.p(70, 2)
        dxf.p(10, '0.0'); dxf.p(20, '0.0'); dxf.p(30, '0.0'); dxf.p(3, bname); dxf.p(1, '')

    def end_blk():
        dxf.p(0, 'ENDBLK'); dxf.p(5, dxf.next_h()); dxf.p(330, dxf._cur_owner); dxf.p(100, 'AcDbEntity'); dxf.p(8, '0'); dxf.p(100, 'AcDbBlockEnd')
        dxf._cur_owner = dxf.ms_br_h

    # *Model_Space & *Paper_Space
    start_blk('*Model_Space', dxf.ms_br_h); end_blk()
    start_blk('*Paper_Space', dxf.ps_br_h); end_blk()

    # Arrowhead blocks matching beam.dxf
    start_blk('_ArchTick', dxf.arch_tick_br_h)
    dxf.pline([(-0.5, -0.5), (0.5, 0.5)], '0', False, 0, cw=0.15)
    end_blk()

    start_blk('_DotBlank', dxf.dot_blank_br_h)
    dxf.circle(0.0, 0.0, 0.5, '0', 0)
    dxf.line(-0.5, 0.0, -1.0, 0.0, '0', 0)
    end_blk()

    start_blk('Dce_KhTenTruc')
    dxf.circle(0.0, -3.5, 2.5, 'DCE_Block', 3)
    dxf.circle(0.0, -3.5, 2.7, 'DCE_Block', 256)
    dxf.line(0.0, 0.0, 0.0, -1.0, 'DCE_Truc', 256)
    dxf.line(0.0, -6.0, 0.0, -7.0, 'DCE_Truc', 256)
    dxf.line(-3.5, -3.5, -2.5, -3.5, 'DCE_Truc', 256)
    dxf.line(2.5, -3.5, 3.5, -3.5, 'DCE_Truc', 256)
    dxf.attdef('TRUC', 'Ten truc', '1', 0.0, -3.5, 2.0, 2, 1, 2, 'Dce_text')
    end_blk()

    start_blk('Dce_CaoTrinh')
    dxf.pline([(-11.56, 6.69), (-11.56, 0.0)], '0', False, 8)
    dxf.pline([(-11.56, 0.0), (-9.95, 1.6), (-11.56, 1.6)], '0', True, 8)
    dxf.pline([(-11.56, 0.0), (-13.17, 1.6), (-11.56, 1.6)], '0', True, 8)
    dxf.hatch_poly([(-11.56, 0.0), (-9.95, 1.6), (-11.56, 1.6)], '0', 256, solid=True)
    dxf.line(-13.15, 3.14, -0.09, 3.14, '0', 8)
    dxf.line(0.0, 0.0, -13.2, 0.0, '0', 8)
    dxf.attdef('CT', 'Cao trinh', '%%p0.000', -6.6, 4.1, 2.0, 3, 1, 0, '0')
    end_blk()

    start_blk('DCE_MatCatA')
    dxf.hatch_poly([(0.0, 5.5), (1.18, 2.75), (0.0, 0.0)], '0', 3, solid=True)
    dxf.line(0.0, 5.5, 0.0, 0.0, '0', 3)
    dxf.line(0.0, 5.5, 1.18, 2.75, '0', 3)
    dxf.line(1.18, 2.75, 0.0, 0.0, '0', 3)
    dxf.attdef('1', 'Ten MC', '1', -2.33, 2.75, 2.0, 11, 1, 2, '0')
    end_blk()

    start_blk('Dce_KhTenDam')
    dxf.attdef('TENDAM', 'Ten dam', '%%UDAM', 0.0, 0.74, 2.0, 255, 1, 2, '0')
    dxf.attdef('TL', 'Ti le', 'TL: 1/50', 0.0, -2.0, 1.0, 11, 1, 2, '0')
    end_blk()

    start_blk('Dce_KhMatCat')
    dxf.attdef('TENMATCAT', 'Ten MC', '%%UMC 1-1', 0.0, 0.74, 2.0, 255, 1, 2, '0')
    dxf.attdef('TL', 'Ti le', 'TL: 1/25', 0.0, -2.0, 1.0, 11, 1, 2, '0')
    end_blk()

    start_blk('Dce_McThepChu')
    dxf.line(-0.35, 0.35, 0.35, -0.35, '0', 0)
    dxf.line(0.35, 0.35, -0.35, -0.35, '0', 0)
    dxf.line(-0.5, 0.0, 0.5, 0.0, '0', 0)
    dxf.line(0.0, 0.5, 0.0, -0.5, '0', 0)
    dxf.pline([(-0.5, 0.0, 1.0), (0.5, 0.0, 1.0)], '0', True, 0, cw=0.0833)
    dxf.circle(0.0, 0.0, 0.5, '0', 0)
    end_blk()

    start_blk('Dce_KhtMcThepChu')
    dxf.circle(2.5, 0.0, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '1', 2.5, 0.0, 2.0, 11, 1, 2, '0')
    dxf.attdef('DKVAKC', 'DK', '2%%c18', -0.25, 1.6, 2.0, 3, 2, 0, '0')
    dxf.attdef('DKVAKC2', 'Note', '', -0.25, -2.5, 2.0, 3, 2, 0, '0')
    end_blk()

    start_blk('Dce_KhtMcThepChu_L')
    dxf.circle(-2.5, 0.0, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '1', -2.5, 0.0, 2.0, 11, 1, 2, '0')
    dxf.attdef('DKVAKC', 'DK', '2%%c18', 0.4, 1.6, 2.0, 3, 0, 0, '0')
    dxf.attdef('DKVAKC2', 'Note', '', 0.4, -2.5, 2.0, 3, 0, 0, '0')
    end_blk()

    start_blk('Dce_KhtThepDai')
    dxf.circle(-5.6, -3.5, 2.5, '0', 256)
    dxf.attdef('SH', 'So hieu', '8', -5.6, -3.5, 2.0, 11, 1, 2, '0')
    dxf.attdef('DKVAKC', 'Dai', '%%c6a100', -2.56, -4.5, 2.0, 3, 0, 0, '0')
    dxf.attdef('VITRI', 'Vi tri', '', 15.57, -4.5, 2.0, 11, 1, 0, 'Dce_ViTriThep')
    end_blk()

    start_blk('TenCauKien')
    dxf.attdef('SOCAUKIEN', 'So cau kien', 'SoCauKien', 2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', rot=90.0)
    dxf.attdef('TENCAUKIEN', 'Ten cau kien', u'Tên cấu kiện', -2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', rot=90.0)
    end_blk()

    start_blk('TKTitle')
    dxf.pline([(0.0, 0.0), (0.0, -11.0), (0.0, -35.0), (15.0, -35.0), (25.0, -35.0),
               (75.0, -35.0), (90.0, -35.0), (122.5, -35.0), (135.0, -35.0),
               (147.5, -35.0), (167.5, -35.0), (192.5, -35.0), (192.5, -11.0), (192.5, 0.0)], 'DCE_BaoBeTong', True)
    dxf.pline([(0.0, -11.0), (15.0, -11.0), (25.0, -11.0), (75.0, -11.0), (90.0, -11.0),
               (122.5, -11.0), (147.5, -11.0), (167.5, -11.0), (192.5, -11.0)], 'DCE_BaoBeTong', False)
    for vx in (15.0, 25.0, 75.0, 90.0, 110.0, 122.5, 147.5, 167.5):
        dxf.line(vx, -11.0, vx, -35.0, 'DCE_BaoBeTong')
    dxf.line(122.5, -23.0, 147.5, -23.0, 'DCE_BaoBeTong')
    dxf.line(135.0, -23.0, 135.0, -35.0, 'DCE_BaoBeTong')
    dxf.text(92.5, -6.0, 4.5, u'BẢNG THỐNG KÊ CỐT THÉP', '0', 256, 1, 2)
    for tx, ty, th, lbl in [
        (7.5, -17.5, 2.5, u'TÊN'), (7.5, -23.0, 2.5, u'CẤU'), (7.5, -28.5, 2.5, u'KIỆN'),
        (20.0, -21.25, 2.5, u'SỐ'), (20.0, -26.75, 2.5, u'HIỆU'),
        (50.0, -23.0, 2.5, u'HÌNH DẠNG, KÍCH THƯỚC'),
        (82.5, -17.5, 2.5, u'ĐƯỜNG'), (82.5, -23.0, 2.5, u'KÍNH'), (82.5, -28.5, 2.5, '(mm)'),
        (100.0, -17.5, 2.5, u'CHIỀU DÀI'), (100.0, -23.0, 2.5, u'THANH'), (100.0, -28.5, 2.5, '(mm)'),
        (116.25, -17.5, 2.5, u'SỐ'), (116.25, -23.0, 2.5, u'CẤU'), (116.25, -28.5, 2.5, u'KIỆN'),
        (135.0, -17.0, 2.5, u'SỐ LƯỢNG'), (128.75, -29.0, 2.5, '1 CK'), (141.25, -29.0, 2.5, u'T. BỘ'),
        (157.5, -17.5, 2.5, u'TỔNG'), (157.5, -23.0, 2.5, u'CHIỀU DÀI'), (157.5, -28.5, 2.5, '(m)'),
        (180.0, -17.5, 2.5, u'TỔNG'), (180.0, -23.0, 2.5, u'KHỐI LƯỢNG'), (180.0, -28.5, 2.5, '(kg)'),
    ]:
        dxf.text(tx, ty, th, lbl, '0', 256, 1, 2)
    end_blk()

    for bcode in ('TK1', 'TK2', 'TK3', 'TK4', 'TK7', 'TK7R1', 'TK9', 'TKTUnknown'):
        start_blk(bcode)
        rh_blk = -13.5 if bcode == 'TKTUnknown' else -8.0
        yc_blk = rh_blk / 2.0
        dxf.pline([(15.0, rh_blk), (25.0, rh_blk), (75.0, rh_blk), (90.0, rh_blk),
                   (122.5, rh_blk), (135.0, rh_blk), (147.5, rh_blk), (167.5, rh_blk),
                   (192.5, rh_blk), (192.5, 0.0)], 'DCE_BaoBeTong', False)
        for vx in (0.0, 15.0, 25.0, 75.0, 90.0, 110.0, 122.5, 135.0, 147.5, 167.5):
            dxf.line(vx, 0.0, vx, rh_blk, 'DCE_BaoBeTong')
        if bcode == 'TK1':
            dxf.pline([(32.5, -6.5), (67.5, -6.5)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L', 'L', '4000', 50.0, -4.0, 2.5, 2, 1, 2)
        elif bcode == 'TK2':
            dxf.pline([(34.55, -6.5), (34.55, -2.0), (65.49, -2.0)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 33.18, -4.0, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 50.0, -4.26, 2.5, 2, 1, 2)
        elif bcode == 'TK3':
            dxf.pline([(65.52, -6.5), (65.52, -2.0), (33.99, -2.0)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 48.94, -4.19, 2.5, 2, 1, 2)
            dxf.attdef('L2', 'L2', 'L2', 67.26, -4.0, 2.5, 2, 0, 2)
        elif bcode == 'TK4':
            dxf.pline([(33.72, -6.5), (33.72, -2.0), (66.28, -2.0), (66.28, -6.5)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 32.68, -4.0, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 50.0, -4.0, 2.5, 2, 1, 2)
            dxf.attdef('L3', 'L3', 'L3', 67.53, -4.0, 2.5, 2, 0, 2)
        elif bcode == 'TK7':
            dxf.pline([(33.72, -2.0), (33.72, -6.5), (66.28, -6.5), (66.28, -2.0)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 32.68, -4.0, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 50.0, -4.0, 2.5, 2, 1, 2)
            dxf.attdef('L3', 'L3', 'L3', 67.53, -4.0, 2.5, 2, 0, 2)
        elif bcode == 'TK7R1':
            dxf.pline([(33.28, -2.8), (33.28, -7.3), (46.0, -7.3), (52.0, -4.8), (66.22, -4.8), (66.22, -0.8)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', 'L1', 31.93, -4.84, 2.5, 2, 2, 2)
            dxf.attdef('L2', 'L2', 'L2', 40.67, -4.84, 2.5, 2, 1, 2)
            dxf.attdef('L3', 'L3', 'L3', 47.45, -2.72, 2.5, 2, 0, 2)
            dxf.attdef('L4', 'L4', 'L4', 59.11, -2.72, 2.5, 2, 1, 2)
            dxf.attdef('L5', 'L5', 'L5', 67.48, -2.72, 2.5, 2, 0, 2)
        elif bcode == 'TK9':
            dxf.pline([(41.42, -7.37), (41.42, -1.7), (57.26, -1.7), (57.26, -5.81), (39.86, -5.81)], 'DCE_ThepChu', False, 256)
            dxf.attdef('L1', 'L1', '150', 49.34, -3.76, 2.5, 2, 1, 2)
            dxf.attdef('L2', 'L2', '350', 58.47, -3.76, 2.5, 2, 0, 2)
            dxf.attdef('M', 'M', '48', 38.78, -5.47, 2.5, 2, 2, 2)
        for tag, xatt, ha in [('SH', 20.0, 1), ('DK', 82.5, 1), ('sumL', 100.0, 1), ('SKC', 116.25, 1),
                              ('SL', 128.75, 1), ('TSL', 141.25, 1), ('Lall', 162.5, 2), ('KL', 185.5, 2)]:
            dxf.attdef(tag, tag, tag, xatt, yc_blk, 2.5, 2, ha, 2)
        end_blk()

    # ENTITIES SECTION (emit entities into dxf.buf so *D* anonymous dim blocks also accumulate before finalizing TABLES/BLOCKS)
    dxf.set_target('entities')
    base_y = 0.0
    last_beam_bottom_y = 0.0
    el_sec_gap = max(800.0, 500.0 * k_elev, 500.0 * k_sec)
    beam_gap = max(1200.0, 750.0 * k_elev, 750.0 * k_sec)
    sched = []
    stir_col = col.get(u'Đai (Ø-a gối/a nhịp)', 34)
    level_label = '%s%.3f' % ('+' if level_z >= 0 else '', level_z / 1000.0)

    def _emit_rebar_tag_leader(x_bar, y_bar, x_end, y_tag, sh_s, txt_main, txt_sub, sc_val,
                               dir_left, dimstyle_name='Dce_50MV', arrow_blk=''):
        dxf.leader([(x_bar, y_bar), (x_bar, y_tag), (x_end, y_tag)], 'DCE_Dim', dimstyle_name, 1 if arrow_blk else 0)
        if dir_left:
            dxf.insert('Dce_KhtMcThepChu_L', x_end, y_tag, sc_val, sc_val, 'DCE_Block', [
                ('SH', sh_s, -2.5, -1.0, 2.0, 11, 1, 0, '0'),
                ('DKVAKC', txt_main, 0.4, 1.0, 2.0, 3, 0, 0, '0'),
                ('DKVAKC2', txt_sub, 0.4, -3.0, 2.0, 3, 0, 0, '0'),
            ])
        else:
            dxf.insert('Dce_KhtMcThepChu', x_end, y_tag, sc_val, sc_val, 'DCE_Block', [
                ('SH', sh_s, 2.5, -1.0, 2.0, 11, 1, 0, '0'),
                ('DKVAKC', txt_main, -0.25, 1.0, 2.0, 3, 2, 0, '0'),
                ('DKVAKC2', txt_sub, -1.75, -3.0, 2.0, 3, 2, 0, '0'),
            ])

    for bname in order:
        rows = beams_raw[bname]
        sl_ck = max(1, int(round(num(gc(rows[0], 'SL', 1), 1))))
        sups, spans = [], []
        sx0, fl, fr = [], [], []
        cx = 0.0
        for k, r in enumerate(rows):
            if k == 0:
                gw = num(gc(r, u'Gối trái (mm)', 4), 220.0)
                sups.append({'w': gw, 'grid': sstr(gc(r, u'Trục T', 6), '1'), 'off': num(gc(r, u'Lệch trục T (mm)', 7), 0.0)})
                sx0.append(cx)
                cx += gw
            cl = max(200.0, num(gc(r, u'L thông thủy (mm)', 8), 3000.0))
            fl.append(cx)
            cx += cl
            fr.append(cx)
            bw = max(100.0, num(gc(r, 'b (mm)', 14), 200.0))
            bh = max(150.0, num(gc(r, 'h (mm)', 15), 400.0))
            topZ = num(gc(r, u'Cao đỉnh (mm)', 16), 0.0)
            hs = num(gc(r, u'h sàn (mm)', 17), 0.0)
            sbL = num(gc(r, u'Sàn T dày (mm)', 18), hs)
            sbL_top = num(gc(r, u'Sàn T đỉnh (mm)', 19), topZ)
            sbR = num(gc(r, u'Sàn P dày (mm)', 20), hs)
            stir_s = sstr(r[stir_col] if stir_col < len(r) else '6-100/200', '6-100/200') or '6-100/200'
            spans.append({'clear': cl, 'b': bw, 'h': bh, 'top': topZ, 'slabL': sbL, 'slabL_top': sbL_top, 'slabR': sbR, 'stir': stir_s})
            gw_r = num(gc(r, u'Gối phải (mm)', 10), 220.0)
            sups.append({'w': gw_r, 'grid': sstr(gc(r, u'Trục P', 12), str(k + 2)), 'off': num(gc(r, u'Lệch trục P (mm)', 13), 0.0)})
            sx0.append(cx)
            cx += gw_r

        maxtop = max([s['top'] for s in spans] or [0.0])
        lay = {'n': len(spans), 'sx0': sx0, 'fl': fl, 'fr': fr, 'L': cx, 'maxtop': maxtop}
        to_cad_y = lambda yd: base_y - yd
        beam_bot_y = base_y - max(maxtop - s['top'] + s['h'] for s in spans)

        # 1. Concrete spans + hidden slab soffit (layer 3 HIDDEN2)
        for i, sp in enumerate(spans):
            ty = to_cad_y(maxtop - sp['top'])
            by = to_cad_y(maxtop - sp['top'] + sp['h'])
            dxf.line(fl[i], ty, fr[i], ty, 'DCE_BaoBeTong')
            dxf.line(fl[i], by, fr[i], by, 'DCE_BaoBeTong')
            sb = sp['slabL']
            if sb > 0:
                sbot = to_cad_y(maxtop - sp['slabL_top']) - sb
                dxf.line(fl[i], sbot, fr[i], sbot, '3')

        sx_top = base_y + 550.0 * k_elev
        sx_bot = beam_bot_y - 650.0 * k_elev

        # 2. Open support columns with zigzag breaks + grid axes & double-circle bubbles (layer 3)
        axis_scale = 1.2 * s_elev
        for k, su in enumerate(sups):
            x0, x1 = sx0[k], sx0[k] + su['w']
            if su['w'] > 0.5:
                dxf.line(x0, sx_bot, x0, sx_top, 'DCE_BaoBeTong')
                dxf.line(x1, sx_bot, x1, sx_top, 'DCE_BaoBeTong')
                dxf.zigzag_h(x0, x1, sx_top)
                dxf.zigzag_h(x0, x1, sx_bot)
            gcx = (x0 + x1) / 2.0 + su['off']
            dxf.line(gcx, sx_top + 200.0 * k_elev, gcx, sx_bot - 600.0 * k_elev, 'DCE_Truc')
            dxf.insert('Dce_KhTenTruc', gcx, sx_bot - 600.0 * k_elev, axis_scale, axis_scale, '3', [
                ('TRUC', su['grid'] or str(k + 1), 0.0, -4.5, 2.0, 2, 1, 0, 'Dce_text')
            ])

        dxf.insert('Dce_CaoTrinh', -100.0 * k_elev, base_y, s_elev, s_elev, 'DCE_Block', [
            ('CT', level_label, -10.15, 4.07, 2.0, 3, 0, 0, '0')
        ])
        # Left beam height h dim (Dce_50MV)
        dxf.dim(0.0, base_y - spans[0]['h'], 0.0, base_y, -350.0 * k_elev, 0.0, 'DCE_Dim', float(s_elev), dimstyle='Dce_50MV', rot_deg=90.0)

        # 3. Longitudinal rebar with 90-deg fillets + 20-deg hooks + real LEADER + Kht tags
        grps = groups_map.get(bname) or [
            {'pos': 'Trên', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': 'Gập vào cột', 'lv': u'xuống', 'b': len(spans), 'rk': 'Gập vào cột', 'rv': u'xuống', 'cross': 'Tự động'},
            {'pos': 'Dưới', 'layer': 1, 'n': 2, 'd': 18, 'a': 0, 'lk': 'Gập vào cột', 'lv': u'xuống', 'b': len(spans), 'rk': 'Gập vào cột', 'rv': u'xuống', 'cross': 'Tự động'},
        ]
        sh_i = 1
        bars_built = []
        for g in grps:
            polys = build_group_polylines(g, spans, sups, lay, opt)
            for pts in polys:
                raw_cad_pts = [(px, to_cad_y(py)) for px, py in pts]
                bent_pts = _bend_cad_polyline(raw_cad_pts, g['pos'])
                dxf.pline(bent_pts, 'DCE_ThepChu', False)
                shp, l1, l2, l3, l4, l5, sumL = classify_poly(pts)
                sh_s = str(sh_i)
                bars_built.append({'sh': sh_s, 'pos': g['pos'], 'layer': g['layer'], 'n': g['n'], 'd': g['d'], 'pts': pts})
                mx = (raw_cad_pts[0][0] + raw_cad_pts[-1][0]) / 2.0
                my = raw_cad_pts[len(raw_cad_pts) // 2][1]
                tagY = (base_y + (280.0 + (g['layer'] - 1) * 260.0 + (sh_i % 2) * 150.0) * k_elev) if g['pos'] == 'Trên' else (
                    (beam_bot_y - (320.0 + (g['layer'] - 1) * 260.0 + (sh_i % 2) * 150.0) * k_elev) if g['pos'] == 'Dưới' else my + 180.0 * k_elev)
                dir_left = (sh_i % 2 == 1)
                tagX = (mx - 375.0 * k_elev) if dir_left else (mx + 375.0 * k_elev)
                _emit_rebar_tag_leader(mx, my, tagX, tagY, sh_s, '%d%%%%c%d' % (g['n'], g['d']), '', s_elev, dir_left, 'Dce_50MV', '')
                sched.append((bname, sh_s, shp, l1, l2, l3, l4, l5, 0, g['d'], sumL, sl_ck, g['n'],
                              raw_cad_pts if shp == 'TKTUnknown' else None))
                sh_i += 1

        # 4. Stirrup zones + TK9 + symbolic stirrup pairs + continuous top spacing dim chain
        zones = []
        for i, sp in enumerate(spans):
            sd, sa1, sa2 = parse_stir_spec(sp['stir'])
            if sp['clear'] < opt['short'] or sa1 == sa2:
                zones.append((fl[i], fr[i], sd, min(sa1, sa2)))
            else:
                zl = round(sp['clear'] / 4.0)
                zones.append((fl[i], fl[i] + zl, sd, sa1))
                zones.append((fl[i] + zl, fr[i] - zl, sd, sa2))
                zones.append((fr[i] - zl, fr[i], sd, sa1))

        stir_buckets = {}
        first_stir_sh = str(sh_i)
        for x0z, x1z, zd, za in zones:
            xm = (x0z + x1z) / 2.0
            sp_i = 0
            for idx_s in range(len(spans)):
                if fl[idx_s] - 10 <= xm <= fr[idx_s] + 10:
                    sp_i = idx_s
                    break
            sp = spans[sp_i]
            l1s = max(80, int(round(sp['b'] - 2 * opt['cover'] + 10)))
            l2s = max(120, int(round(sp['h'] - 2 * opt['cover'] + 10)))
            cnt_s = max(1, int((x1z - x0z) // max(50, za)) + 1)
            key = (zd, l1s, l2s)
            if key not in stir_buckets:
                stir_buckets[key] = [zd, l1s, l2s, 0]
            stir_buckets[key][3] += cnt_s
        for zd, l1s, l2s, cnt_s in stir_buckets.values():
            ms = max(48, 6 * zd)
            sched.append((bname, str(sh_i), 'TK9', l1s, l2s, 0, 0, 0, ms, zd, 2 * (l1s + l2s) + 2 * ms, sl_ck, cnt_s, None))
            sh_i += 1

        prev_dim_x = 0.0
        top_dim_y = sx_top + 450.0 * k_elev
        for x0z, x1z, zd, za in zones:
            if x1z - x0z > 150.0:
                for sx_pair in (x0z + 25.0, x0z + 175.0, x1z - 175.0, x1z - 25.0):
                    dxf.line(sx_pair, base_y - 25.0, sx_pair, beam_bot_y + 25.0, 'DCE_ThepDai')
            if x0z > prev_dim_x + 5.0:
                dxf.dim(prev_dim_x, sx_top, x0z, sx_top, 0.0, top_dim_y, 'DCE_Dim', float(s_elev), dimstyle='Dce_50MV', rot_deg=0.0)
            dxf.dim(x0z, sx_top, x1z, sx_top, 0.0, top_dim_y, 'DCE_Dim', float(s_elev), dimstyle='Dce_50MV', rot_deg=0.0)
            prev_dim_x = x1z
            dxf.insert('Dce_KhtThepDai', (x0z + x1z) / 2.0, top_dim_y, s_elev, s_elev, 'DCE_Block', [
                ('SH', first_stir_sh, -5.74, -4.5, 2.0, 11, 1, 0, '0'),
                ('DKVAKC', '%%%%c%da%d' % (zd, za), -2.56, -4.5, 2.0, 3, 0, 0, '0'),
                ('VITRI', '', 15.57, -4.5, 2.0, 11, 1, 0, 'Dce_ViTriThep'),
            ])
        if cx > prev_dim_x + 5.0:
            dxf.dim(prev_dim_x, sx_top, cx, sx_top, 0.0, top_dim_y, 'DCE_Dim', float(s_elev), dimstyle='Dce_50MV', rot_deg=0.0)

        # 5. Two bottom dim rows + Beam title
        for i in range(len(spans)):
            dxf.dim(fl[i], beam_bot_y, fr[i], beam_bot_y, 0.0, sx_bot - 250.0 * k_elev, 'DCE_Dim', float(s_elev), dimstyle='Dce_50MV', rot_deg=0.0)
        for k in range(len(sups) - 1):
            c0 = sx0[k] + sups[k]['w'] / 2.0
            c1 = sx0[k + 1] + sups[k + 1]['w'] / 2.0
            dxf.dim(c0, sx_bot, c1, sx_bot, 0.0, sx_bot - 600.0 * k_elev, 'DCE_Dim', float(s_elev), dimstyle='Dce_50MV', rot_deg=0.0)

        title_scale = 2.0 * s_elev
        dxf.insert('Dce_KhTenDam', cx / 2.0, sx_bot - 1700.0 * k_elev, title_scale, title_scale, 'DCE_Block', [
            ('TENDAM', u'%%%%UDẦM %s (SL=%d; L=%d)' % (bname, sl_ck, int(round(cx))), 0.0, 0.74, 2.0, 255, 1, 0, '0'),
            ('TL', 'TL: 1/%d' % s_elev, 0.0, -2.0, 1.0, 11, 1, 0, '0'),
        ])

        el_min_x = -1050.0 * k_elev
        el_max_x = cx + 750.0 * k_elev
        el_max_y = sx_top + 1150.0 * k_elev
        el_min_y = sx_bot - 2200.0 * k_elev
        dxf.pline([(el_min_x, el_max_y), (el_max_x, el_max_y), (el_max_x, el_min_y), (el_min_x, el_min_y)], 'Defpoints', True)

        # 6. Cross Sections MC 1-1..N-N matching beam.dxf exact layout
        cuts = []
        for i, sp in enumerate(spans):
            if len(cuts) >= 6:
                break
            if i == 0:
                cuts.append((fl[0] + min(350.0, sp['clear'] * 0.2), 0))
            if len(cuts) < 6:
                cuts.append((fl[i] + sp['clear'] / 2.0, i))
            if len(cuts) < 6 and i < len(spans) - 1:
                cuts.append((fr[i] - min(350.0, sp['clear'] * 0.2), i))

        max_top_off = 380.0 * k_sec
        max_bot_off = 760.0 * k_sec
        for xw, _ in cuts:
            top_idx = 0
            bot_idx = 0
            for bar in bars_built:
                minx = min(p[0] for p in bar['pts'])
                maxx = max(p[0] for p in bar['pts'])
                if minx - 10 <= xw <= maxx + 10 and bar['pos'] != 'Giữa':
                    if bar['pos'] == 'Trên':
                        ext_v = (90.0 + (bar['layer'] - 1) * 110.0 + top_idx * 90.0 + 180.0) * k_sec
                        if ext_v > max_top_off:
                            max_top_off = ext_v
                        top_idx += 1
                    else:
                        ext_v = (90.0 + (bar['layer'] - 1) * 110.0 + bot_idx * 90.0 + 180.0) * k_sec
                        if ext_v > max_bot_off:
                            max_bot_off = ext_v
                        bot_idx += 1

        sec_ytop = el_min_y - el_sec_gap - max_top_off
        max_b_beam = max(s['b'] for s in spans) if spans else 200.0
        sec_pitch_x = max(1600.0 * k_sec, max_b_beam + 1050.0 * k_sec)
        first_cx = 760.0 * k_sec
        mc_title_scale = 2.0 * s_sec

        for sec_idx, (xw, spi) in enumerate(cuts, 1):
            dxf.line(xw, sx_top + 650.0 * k_elev, xw, sx_bot - 750.0 * k_elev, 'DCE_MCZiCZac')
            dxf.insert('DCE_MatCatA', xw, sx_top + 700.0 * k_elev, s_elev, s_elev, 'DCE_Block', [('1', str(sec_idx), -2.33, 1.70, 2.0, 11, 1, 0, '0')])
            dxf.insert('DCE_MatCatA', xw, sx_bot - 850.0 * k_elev, s_elev, s_elev, 'DCE_Block', [('1', str(sec_idx), -2.33, 1.70, 2.0, 11, 1, 0, '0')])

            sp = spans[spi]
            scx = first_cx + (sec_idx - 1) * sec_pitch_x
            bw_s, bh_s = sp['b'], sp['h']
            stL = sp['slabL'] if sp['slabL'] > 0 else 120.0
            stR = sp['slabR'] if sp['slabR'] > 0 else stL
            sx_l, sx_r = scx - bw_s / 2.0, scx + bw_s / 2.0
            sy_t, sy_b = sec_ytop, sec_ytop - bh_s

            dxf.pline([(sx_l - 50.0, sy_t - stL), (sx_l, sy_t - stL), (sx_l, sy_b),
                       (sx_r, sy_b), (sx_r, sy_t - stR), (sx_r + 50.0, sy_t - stR)], 'DCE_BaoBeTong', False)
            dxf.line(sx_l - 50.0, sy_t, sx_r + 50.0, sy_t, 'DCE_BaoBeTong')
            dxf.zigzag_v(sx_l - 50.0, sy_t, sy_t - stL)
            dxf.zigzag_v(sx_r + 50.0, sy_t, sy_t - stR)

            # 14-point rounded stirrup with double 45-deg hooks & bulges matching beam.dxf
            cov_s = opt['cover']
            xL_s, xR_s = sx_l + cov_s, sx_r - cov_s
            yT_s, yB_s = sy_t - cov_s, sy_b + cov_s
            rr = min(20.0, (xR_s - xL_s) * 0.25, (yT_s - yB_s) * 0.25)
            dxf.pline([
                (xR_s - 2.6 * rr, yT_s - 1.7 * rr, 0.0),
                (xR_s - rr - 2.2, yT_s, 0.0),
                (xR_s - rr, yT_s, -_BULGE_90),
                (xR_s, yT_s - rr, 0.0),
                (xR_s, yB_s + rr, -_BULGE_90),
                (xR_s - rr, yB_s, 0.0),
                (xL_s + rr, yB_s, -_BULGE_90),
                (xL_s, yB_s + rr, 0.0),
                (xL_s, yT_s - rr, -_BULGE_90),
                (xL_s + rr, yT_s, 0.0),
                (xR_s - rr, yT_s, -_BULGE_90),
                (xR_s, yT_s - rr, 0.0),
                (xR_s, yT_s - rr - 2.2, 0.0),
                (xR_s - 1.7 * rr, yT_s - 2.8 * rr, 0.0),
            ], 'DCE_ThepDai', False)

            leader_x = sx_l - 300.0 * k_sec
            top_idx = 0
            bot_idx = 0
            for bar in bars_built:
                minx = min(p[0] for p in bar['pts'])
                maxx = max(p[0] for p in bar['pts'])
                if minx - 10 <= xw <= maxx + 10 and bar['pos'] != 'Giữa':
                    yoff = cov_s + 20.0 + (bar['layer'] - 1) * 45.0
                    dy_bar = (sy_t - yoff) if bar['pos'] == 'Trên' else (sy_b + yoff)
                    if bar['pos'] == 'Trên':
                        tag_y = sy_t + (75.0 + (bar['layer'] - 1) * 110.0 + top_idx * 90.0) * k_sec
                        top_idx += 1
                    else:
                        tag_y = sy_b - (75.0 + (bar['layer'] - 1) * 110.0 + bot_idx * 90.0) * k_sec
                        bot_idx += 1
                    cnt = max(1, bar['n'])
                    dot_sc = bar['d'] * k_sec
                    for bi in range(cnt):
                        bx = scx if cnt == 1 else (sx_l + cov_s + 20.0 + ((bw_s - 2 * cov_s - 40.0) * bi) / (cnt - 1))
                        dxf.leader([(bx, dy_bar), (bx, tag_y), (leader_x, tag_y)], 'DCE_Dim', 'Dce_207MV', 1)
                        dxf.insert('Dce_McThepChu', bx, dy_bar, dot_sc, dot_sc, 'DCE_ThepChu', [])
                    dxf.insert('Dce_KhtMcThepChu_L', leader_x, tag_y, s_sec, s_sec, 'DCE_Block', [
                        ('SH', bar['sh'], -2.5, -1.0, 2.0, 11, 1, 0, '0'),
                        ('DKVAKC', '%d%%%%c%d' % (bar['n'], bar['d']), 0.4, 1.0, 2.0, 3, 0, 0, '0'),
                        ('DKVAKC2', '', 0.4, -3.0, 2.0, 3, 0, 0, '0'),
                    ])

            sd_s, sa1_s, _ = parse_stir_spec(sp['stir'])
            y_stir_mid = (sy_t + sy_b) / 2.0
            dxf.leader([(xL_s, y_stir_mid), (leader_x, y_stir_mid)], 'DCE_Dim', 'Dce_25MV', 0)
            dxf.insert('Dce_KhtMcThepChu_L', leader_x, y_stir_mid, s_sec, s_sec, 'DCE_Block', [
                ('SH', first_stir_sh, -2.5, -1.0, 2.0, 11, 1, 0, '0'),
                ('DKVAKC', '%%%%c%da%d' % (sd_s, sa1_s), 0.4, 1.0, 2.0, 3, 0, 0, '0'),
                ('DKVAKC2', '', 0.4, -3.0, 2.0, 3, 0, 0, '0'),
            ])
            dxf.insert('Dce_CaoTrinh', sx_r + 339.0 * k_sec, sy_t, s_sec, s_sec, 'DCE_Block', [
                ('CT', level_label, -10.15, 4.07, 2.0, 3, 0, 0, '0'),
            ])
            # Height h on LEFT + width b on BOTTOM matching beam.dxf
            dxf.dim(sx_l - 300.0 * k_sec, sy_t, sx_l - 300.0 * k_sec, sy_b, sx_l - 500.0 * k_sec, 0.0, 'DCE_Dim', float(s_sec), dimstyle='Dce_25MV', rot_deg=90.0)
            dxf.dim(sx_l, sy_b - 75.0 * k_sec, sx_r, sy_b - 75.0 * k_sec, 0.0, sy_b - 250.0 * k_sec, 'DCE_Dim', float(s_sec), dimstyle='Dce_25MV', rot_deg=0.0)
            dxf.insert('Dce_KhMatCat', scx, sy_b - 475.0 * k_sec, mc_title_scale, mc_title_scale, 'DCE_Block', [
                ('TENMATCAT', '%%%%UMC %d-%d' % (sec_idx, sec_idx), 0.0, 0.74, 2.0, 255, 1, 0, '0'),
                ('TL', '%s (TL: 1/%d)' % (bname, s_sec), 0.0, -2.0, 1.0, 11, 1, 0, '0'),
            ])

        max_h_beam = max(s['h'] for s in spans)
        beam_bottom_y = el_min_y
        if cuts:
            sec_min_x = first_cx - spans[cuts[0][1]]['b'] / 2.0 - 720.0 * k_sec
            sec_max_x = first_cx + (len(cuts) - 1) * sec_pitch_x + spans[cuts[-1][1]]['b'] / 2.0 + 650.0 * k_sec
            sec_max_y = sec_ytop + max_top_off
            sec_min_y = sec_ytop - max_h_beam - max_bot_off
            dxf.pline([(sec_min_x, sec_max_y), (sec_max_x, sec_max_y), (sec_max_x, sec_min_y), (sec_min_x, sec_min_y)], 'Defpoints', True)
            beam_bottom_y = sec_min_y
        last_beam_bottom_y = beam_bottom_y
        base_y = beam_bottom_y - beam_gap - 1700.0 * k_elev

    # Split Schedule Tables + TenCauKien (rot=90) + TKTUnknown inner diagrams
    col_w, col_gap, title_h = 9625.0, 1200.0, 1750.0
    sched_origin_y = (last_beam_bottom_y - beam_gap - 250.0) if order else 0.0
    max_bot = sched_origin_y - title_h
    col0_bot = max_bot
    diam_totals = {}
    lim = max(1, int(split_limit or 30))

    for col_idx in range(0, max(1, (len(sched) + lim - 1) // lim)):
        chunk = sched[col_idx * lim: (col_idx + 1) * lim]
        cx_col = col_idx * (col_w + col_gap)
        dxf.insert('TKTitle', cx_col, sched_origin_y, 50, 50, 'DCE_Lanh_To', [])
        cur_y = sched_origin_y - title_h

        member_spans = []  # [bname, skc, y_top, y_bot]
        for row in chunk:
            bname, sh, bcode, l1, l2, l3, l4, l5, m, dk, sumL, skc, sl, raw_cad_pts = row
            row_h = 675.0 if bcode == 'TKTUnknown' else 400.0
            yc_off = -(row_h / 100.0)  # -6.75 for TKTUnknown, -4.0 for TK*

            if member_spans and member_spans[-1][0] == bname and member_spans[-1][1] == skc:
                member_spans[-1][3] = cur_y - row_h
            else:
                member_spans.append([bname, skc, cur_y, cur_y - row_h])

            tsl = skc * sl
            lall = round((sumL / 1000.0) * tsl, 2)
            kl = round(lall * unit_w(dk), 2)
            atts = [
                ('SH', sh, 20.0, yc_off, 2.5, 2, 1),
                ('DK', str(int(dk)), 82.5, yc_off, 2.5, 2, 1),
                ('sumL', str(int(round(sumL))), 100.0, yc_off, 2.5, 2, 1),
                ('SKC', str(skc), 116.25, yc_off, 2.5, 2, 1),
                ('SL', str(sl), 128.75, yc_off, 2.5, 2, 1),
                ('TSL', str(tsl), 141.25, yc_off, 2.5, 2, 1),
                ('Lall', '%.2f' % lall, 162.5, yc_off, 2.5, 2, 2),
                ('KL', '%.2f' % kl, 185.5, yc_off, 2.5, 2, 2),
            ]
            if bcode == 'TK1':
                atts += [('L', str(l1), 50.0, -4.0, 2.5, 2, 1)]
            elif bcode == 'TK2':
                atts += [('L1', str(l1), 33.18, -4.0, 2.5, 2, 2), ('L2', str(l2), 50.0, -4.26, 2.5, 2, 1)]
            elif bcode == 'TK3':
                atts += [('L1', str(l1), 48.94, -4.19, 2.5, 2, 1), ('L2', str(l2), 67.26, -4.0, 2.5, 2, 0)]
            elif bcode == 'TK4':
                atts += [('L1', str(l1), 32.68, -4.0, 2.5, 2, 2), ('L2', str(l2), 50.0, -4.0, 2.5, 2, 1), ('L3', str(l3), 67.53, -4.0, 2.5, 2, 0)]
            elif bcode == 'TK7':
                atts += [('L1', str(l1), 32.68, -4.0, 2.5, 2, 2), ('L2', str(l2), 50.0, -4.0, 2.5, 2, 1), ('L3', str(l3), 67.53, -4.0, 2.5, 2, 0)]
            elif bcode == 'TK7R1':
                atts += [('L1', str(l1), 31.93, -4.84, 2.5, 2, 2), ('L2', str(l2), 40.67, -4.84, 2.5, 2, 1),
                         ('L3', str(l3), 47.45, -2.72, 2.5, 2, 0), ('L4', str(l4), 59.11, -2.72, 2.5, 2, 1), ('L5', str(l5), 67.48, -2.72, 2.5, 2, 0)]
            elif bcode == 'TK9':
                atts += [('L1', str(l1), 49.34, -3.76, 2.5, 2, 1), ('L2', str(l2), 58.47, -3.76, 2.5, 2, 0), ('M', str(m), 38.78, -5.47, 2.5, 2, 2)]

            dxf.insert(bcode, cx_col, cur_y, 50, 50, 'DCE_Lanh_To', atts,
                       ('DCEThongKeThep', ['(0)_%s(1)_%s(2)_%s(3)_%d(4)_%d(5)_%d(6)_0(7)_0(8)_0' % (bname, sh, bcode, dk, skc, sl)]))
            if bcode == 'TKTUnknown' and raw_cad_pts:
                _draw_tkt_unknown_diagram(dxf, raw_cad_pts, cx_col, cur_y, row_h)

            prev = diam_totals.get(dk, [0.0, 0.0])
            diam_totals[dk] = [prev[0] + lall, prev[1] + kl]
            cur_y -= row_h
            max_bot = min(max_bot, cur_y)
            if col_idx == 0:
                col0_bot = cur_y

        for ms_bname, ms_skc, top_m, bot_m in member_spans:
            mid_m = (top_m + bot_m) / 2.0
            dxf.pline([(cx_col, bot_m), (cx_col + 750.0, bot_m)], 'DCE_Lanh_To', False, 256, 'BeamCAD_SUM')
            dxf.insert('TenCauKien', cx_col + 375.0, mid_m, 50, 50, 'DCE_Lanh_To', [
                ('SOCAUKIEN', 'SL: %d' % ms_skc, 2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', 90.0),
                ('TENCAUKIEN', ms_bname, -2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', 90.0),
            ], ('BeamCAD_SKC', [str(ms_skc)]))

    # Summary Table matching beam.dxf (Dce_Text2, bylayer color=256, directly under column 0)
    sy = col0_bot
    dks = sorted(diam_totals.keys())
    totw = 1900.0 + max(2, len(dks)) * 1100.0
    dxf.pline([(0.0, sy), (totw, sy), (totw, sy - 600.0), (0.0, sy - 600.0)], 'DCE_Lanh_To', True, 256, 'BeamCAD_SUM')
    dxf.text(totw / 2.0, sy - 300.0, 150.0, u'TỔNG HỢP CỐT THÉP', 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
    y0 = sy - 600.0
    for r in range(5):
        dxf.line(0.0, y0 - r * 400.0, totw, y0 - r * 400.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
    dxf.line(0.0, y0, 0.0, y0 - 1600.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
    dxf.line(1900.0, y0, 1900.0, y0 - 1600.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
    for idx, lbl in enumerate([u'- Đường kính (mm):', u'- Chiều dài (m):', u'- Khối lượng (kg):', u'- Chiều dài / 11.7']):
        dxf.text(100.0, y0 - idx * 400.0 - 200.0, 100.0, lbl, 'Dce_text', 256, 0, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
    w_le10 = w_mid = w_gt18 = 0.0
    for ci, dk in enumerate(dks):
        lx, k = diam_totals[dk]
        if dk <= 10:
            w_le10 += k
        elif dk <= 18:
            w_mid += k
        else:
            w_gt18 += k
        cx0 = 1900.0 + ci * 1100.0
        dxf.line(cx0 + 1100.0, y0, cx0 + 1100.0, y0 - 1600.0, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
        dxf.text(cx0 + 550.0, y0 - 200.0, 100.0, '%%%%c%d' % dk, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        dxf.text(cx0 + 550.0, y0 - 600.0, 100.0, '%.2f' % lx, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        dxf.text(cx0 + 550.0, y0 - 1000.0, 100.0, '%.2f' % k, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        dxf.text(cx0 + 550.0, y0 - 1400.0, 100.0, str(int(math.ceil(lx / 11.7))) if dk > 10 else '-', 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
    grand = w_le10 + w_mid + w_gt18
    row_top = y0 - 1650.0
    grp_rows = [
        (u'- Nhóm %%c <= 10:', w_le10, False),
        (u'- Nhóm 10 < %%c <= 18:', w_mid, False),
        (u'- Nhóm %%c > 18:', w_gt18, False),
        (u'- Tổng cộng:', grand, True),
    ]
    for glbl, gval, is_total in grp_rows:
        if glbl != u'- Nhóm %%c > 18:' or gval > 0.0:
            if is_total:
                row_top -= 400.0
            row_bot = row_top - 400.0
            dxf.pline([(0.0, row_top), (totw, row_top), (totw, row_bot), (0.0, row_bot)], 'DCE_Lanh_To', True, 256, 'BeamCAD_SUM')
            dxf.line(1900.0, row_top, 1900.0, row_bot, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
            if totw >= 3000.0:
                dxf.line(3000.0, row_top, 3000.0, row_bot, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
            ym = (row_top + row_bot) / 2.0
            dxf.text(100.0, ym, 100.0, glbl, 'Dce_text', 256, 0, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(2450.0, ym, 100.0, '%.2f' % gval, 'Dce_text', 256, 4, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(3550.0, ym, 100.0, 'kg', 'Dce_text', 256, 4, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            row_top = row_bot

    num_cols = max(1, (len(sched) + lim - 1) // lim)
    sched_total_w = max(num_cols * col_w + max(0, num_cols - 1) * col_gap, totw)
    sched_box = [(-125.0, sched_origin_y + 125.0), (sched_total_w + 125.0, sched_origin_y + 125.0),
                 (sched_total_w + 125.0, min(row_top, max_bot) - 470.0), (-125.0, min(row_top, max_bot) - 470.0)]
    dxf.pline(sched_box, 'Defpoints', True, 256, 'BeamCAD_SUM')

    # Assemble BLOCK_RECORD table + BLOCKS section (with anonymous *D* dim blocks) + ENTITIES
    pre_br = list(dxf.buf)
    dxf.buf = []
    dxf.set_target('buf')
    dxf.emit_block_records_table()
    dxf.p(0, 'ENDSEC')
    dxf.p(0, 'SECTION'); dxf.p(2, 'BLOCKS')
    dxf.buf.extend(dxf.blocks_buf)
    dxf.buf.extend(dxf.dim_blocks_buf)
    dxf.p(0, 'ENDSEC')
    dxf.p(0, 'SECTION'); dxf.p(2, 'ENTITIES')
    dxf.buf.extend(dxf.entities_buf)
    dxf.p(0, 'ENDSEC')
    dxf.p(0, 'EOF')
    full_lines = pre_br + dxf.buf
    with io.open(out_dxf, 'w', encoding='utf-8') as f:
        f.write(u'\r\n'.join(full_lines) + u'\r\n')
    return len(sched), grand


def _read_dxf_pairs(in_dxf):
    raw_lines = None
    for enc in ('utf-8-sig', 'utf-8', 'cp1252', 'latin-1'):
        try:
            with io.open(in_dxf, 'r', encoding=enc) as f:
                raw_lines = f.read().splitlines()
            break
        except Exception:
            raw_lines = None
    if raw_lines is None:
        raise ValueError(u'Không đọc được nội dung file DXF.')
    pairs = []
    i = 0
    n = len(raw_lines)
    while i + 1 < n:
        try:
            code = int(raw_lines[i].strip())
        except Exception:
            i += 1
            continue
        pairs.append((code, raw_lines[i + 1]))
        i += 2
    return pairs


def _num_dxf_attr(val, default=0.0):
    s = sstr(val)
    if not s:
        return default
    s = s.replace('%%c', '').replace('%%C', '').replace('SL:', '').replace('sl:', '')
    s = s.replace(u'Ø', '').replace(u'ø', '').replace('PHI', '').replace('phi', '')
    s = s.strip().lstrip(':').strip()
    if len(s) >= 2 and s[0] in ('D', 'd') and s[1].isdigit():
        s = s[1:]
    s = s.replace(',', '.')
    m = re.search(r'-?\d+(?:\.\d+)?', s)
    if not m:
        return default
    try:
        return float(m.group(0))
    except Exception:
        return default


def _parse_insert_info(pairs):
    bname = ''
    ix = 0.0
    iy = 0.0
    in_header = True
    atts = {}
    xdata_skc = 0
    cur_tag = None
    cur_val = ''
    cur_app = ''
    idx = 0
    while idx < len(pairs):
        c, v = pairs[idx]
        if c == 0 and v.strip() == 'ATTRIB':
            in_header = False
            cur_tag = None
            cur_val = ''
        elif c == 0 and v.strip() == 'SEQEND':
            in_header = False
        elif in_header:
            if c == 2 and not bname:
                bname = v.strip()
            elif c == 10:
                try:
                    ix = float(v)
                except Exception:
                    pass
            elif c == 20:
                try:
                    iy = float(v)
                except Exception:
                    pass
            elif c == 1001:
                cur_app = v.strip()
            elif c == 1000 and cur_app == 'BeamCAD_SKC':
                try:
                    xdata_skc = int(round(float(v.strip())))
                except Exception:
                    pass
        else:
            if c == 2:
                cur_tag = v.strip()
            elif c == 1:
                cur_val = v.strip()
                if cur_tag is not None:
                    atts[cur_tag] = cur_val
            if cur_tag and (c == 1 or c == 2):
                if cur_tag in atts or c == 1:
                    atts[cur_tag] = cur_val
        idx += 1
    # Re-scan ATTRIB blocks cleanly in case (1) appeared before (2)
    atts2 = {}
    i2 = 0
    while i2 < len(pairs):
        if pairs[i2] == (0, 'ATTRIB'):
            j = i2 + 1
            t_name = None
            t_val = ''
            while j < len(pairs) and pairs[j][0] != 0:
                if pairs[j][0] == 2:
                    t_name = pairs[j][1].strip()
                elif pairs[j][0] == 1:
                    t_val = pairs[j][1].strip()
                j += 1
            if t_name:
                atts2[t_name] = t_val
            i2 = j
        else:
            i2 += 1
    atts.update(atts2)
    return bname, ix, iy, atts, xdata_skc


def _offset_chunk_pairs(pairs, dx, dy):
    """Translate a non-INSERT entity chunk (LWPOLYLINE or DIMENSION) by (dx, dy)."""
    out = []
    for pc, pv in pairs:
        if pc in (10, 11, 13, 14):
            try:
                out.append((pc, '%.4f' % (float(pv) + dx)))
                continue
            except Exception:
                pass
        elif pc in (20, 21, 23, 24):
            try:
                out.append((pc, '%.4f' % (float(pv) + dy)))
                continue
            except Exception:
                pass
        out.append((pc, pv))
    return out


def _translate_dim_block_in_prefix(prefix_pairs, block_deltas):
    """If DIMENSION entities linked to *D* blocks were moved, shift their anonymous *D* block geometry too."""
    if not block_deltas:
        return prefix_pairs
    out = list(prefix_pairs)
    i = 0
    n = len(out)
    while i < n:
        if out[i][0] == 0 and out[i][1].strip() == 'BLOCK':
            j = i + 1
            bname = ''
            while j < n and out[j][0] != 0:
                if out[j][0] == 2 and not bname:
                    bname = out[j][1].strip()
                j += 1
            k = j
            while k < n and out[k][0] != 0 or (k < n and out[k][1].strip() != 'ENDBLK'):
                k += 1
            if bname in block_deltas:
                dx, dy = block_deltas[bname]
                if abs(dx) > 1e-4 or abs(dy) > 1e-4:
                    m = j
                    while m < k:
                        c, v = out[m]
                        if c in (10, 11, 13, 14):
                            try:
                                out[m] = (c, '%.4f' % (float(v) + dx))
                            except Exception:
                                pass
                        elif c in (20, 21, 23, 24):
                            try:
                                out[m] = (c, '%.4f' % (float(v) + dy))
                            except Exception:
                                pass
                        m += 1
            i = k + 1
        else:
            i += 1
    return out


def _transform_insert_pairs(pairs, old_x, old_y, new_x, new_y, updates):
    dx = new_x - old_x
    dy = new_y - old_y
    out = []
    i = 0
    n = len(pairs)
    in_header = True
    while i < n:
        c, v = pairs[i]
        if c == 0 and v.strip() == 'ATTRIB':
            in_header = False
            sub = [pairs[i]]
            i += 1
            tag_name = None
            while i < n and pairs[i][0] != 0:
                if pairs[i][0] == 2:
                    tag_name = pairs[i][1].strip()
                sub.append(pairs[i])
                i += 1
            for sc, sv in sub:
                if sc in (10, 11):
                    try:
                        out.append((sc, '%.4f' % (float(sv) + dx)))
                    except Exception:
                        out.append((sc, sv))
                elif sc in (20, 21):
                    try:
                        out.append((sc, '%.4f' % (float(sv) + dy)))
                    except Exception:
                        out.append((sc, sv))
                elif sc == 1 and tag_name in updates:
                    out.append((sc, sstr(updates[tag_name])))
                else:
                    out.append((sc, sv))
            continue
        elif c == 0 and v.strip() == 'SEQEND':
            in_header = False
            out.append((c, v))
        elif in_header:
            if c == 10:
                out.append((c, '%.4f' % new_x))
            elif c == 20:
                out.append((c, '%.4f' % new_y))
            else:
                out.append((c, v))
        else:
            out.append((c, v))
        i += 1
    return out


def rescan_dxf_file(in_dxf, out_dxf, split_limit=30):
    lim = max(1, int(split_limit or 30))
    pairs = _read_dxf_pairs(in_dxf)

    ent_start = -1
    ent_end = -1
    i = 0
    while i + 1 < len(pairs):
        if pairs[i][0] == 0 and pairs[i][1].strip() == 'SECTION' and pairs[i + 1][0] == 2 and pairs[i + 1][1].strip() == 'ENTITIES':
            ent_start = i + 2
            j = ent_start
            while j < len(pairs):
                if pairs[j][0] == 0 and pairs[j][1].strip() == 'ENDSEC':
                    ent_end = j
                    break
                j += 1
            break
        i += 1

    if ent_start < 0 or ent_end < 0:
        raise ValueError(u'File DXF không hợp lệ (thiếu SECTION ENTITIES).')

    prefix_pairs = pairs[:ent_start]
    ent_pairs = pairs[ent_start:ent_end]
    suffix_pairs = pairs[ent_end:]

    # Group ENTITIES pairs into logical chunks (INSERT..SEQEND as 1 chunk)
    chunks = []
    idx = 0
    while idx < len(ent_pairs):
        c, v = ent_pairs[idx]
        if c != 0:
            idx += 1
            continue
        etype = v.strip()
        j = idx + 1
        has_seq = False
        if etype == 'INSERT':
            while j < len(ent_pairs) and ent_pairs[j][0] != 0:
                if ent_pairs[j][0] == 66:
                    try:
                        has_seq = int(ent_pairs[j][1]) != 0
                    except Exception:
                        pass
                j += 1
            if has_seq:
                while j < len(ent_pairs):
                    if ent_pairs[j][0] == 0 and ent_pairs[j][1].strip() == 'SEQEND':
                        j += 1
                        while j < len(ent_pairs) and ent_pairs[j][0] != 0:
                            j += 1
                        break
                    j += 1
        else:
            while j < len(ent_pairs) and ent_pairs[j][0] != 0:
                j += 1
        chunks.append((etype, ent_pairs[idx:j]))
        idx = j

    tk_names = set(['TK1', 'TK2', 'TK3', 'TK4', 'TK7', 'TK7R1', 'TK9', 'TKTUnknown'])
    tk_items = []
    tc_items = []
    title_items = []
    sum_title_y = None
    has_xdata_sum = False

    for et, c_pairs in chunks:
        for pc, pv in c_pairs:
            if pc == 1001 and pv.strip() == 'BeamCAD_SUM':
                has_xdata_sum = True
        if et == 'INSERT':
            bn, ix, iy, atts, x_skc = _parse_insert_info(c_pairs)
            if bn == 'TKTitle':
                title_items.append((ix, iy))
            elif bn == 'TenCauKien':
                tc_items.append((ix, iy, atts, x_skc))
            elif bn in tk_names:
                tk_items.append((bn, ix, iy, atts, c_pairs))
        elif et == 'TEXT':
            txt = ''
            ty = 0.0
            for pc, pv in c_pairs:
                if pc == 1:
                    txt = pv.strip()
                elif pc == 20:
                    try:
                        ty = float(pv)
                    except Exception:
                        pass
            if u'TỔNG HỢP CỐT THÉP' in txt or u'TONG HOP COT THEP' in txt.upper():
                sum_title_y = ty

    if not tk_items:
        raise ValueError(u'Không tìm thấy block thống kê TK1..TK9 nào trong file DXF.')

    # Sort columns left-to-right, rows top-to-bottom
    tk_items.sort(key=lambda item: (round(item[1] / 3000.0), -item[2]))
    min_x = min(it[1] for it in tk_items)
    max_y = max(t[1] for t in title_items) if title_items else (max(it[2] for it in tk_items) + 1750.0)
    min_tk_y = min(it[2] - (675.0 if it[0] == 'TKTUnknown' else 400.0) for it in tk_items)

    # Identify inner diagram polylines & dims belonging to TKTUnknown rows so they travel when rows reflow/split
    tkt_boxes = [
        (idx_t, it[1], it[2], it[1] + 9625.0, it[2] - 675.0)
        for idx_t, it in enumerate(tk_items) if it[0] == 'TKTUnknown'
    ]
    tkt_inner_map = {idx_t: [] for idx_t, _, _, _, _ in tkt_boxes}
    consumed_inner_ids = set()

    for cidx_chunk, (et, c_pairs) in enumerate(chunks):
        if et not in ('LWPOLYLINE', 'DIMENSION') or not tkt_boxes:
            continue
        layer = ''
        xs_c = []
        ys_c = []
        for pc, pv in c_pairs:
            if pc == 8:
                layer = pv.strip().upper()
            elif pc in (10, 13, 14):
                try:
                    xs_c.append(float(pv))
                except Exception:
                    pass
            elif pc in (20, 23, 24):
                try:
                    ys_c.append(float(pv))
                except Exception:
                    pass
        if not xs_c or not ys_c:
            continue
        if (et == 'LWPOLYLINE' and layer == 'DCE_THEPCHU') or (et == 'DIMENSION' and layer == 'DCE_DIM'):
            mx_c = sum(xs_c) / float(len(xs_c))
            my_c = sum(ys_c) / float(len(ys_c))
            for idx_t, bx0, by0, bx1, by1 in tkt_boxes:
                if (bx0 + 1200.0) <= mx_c <= (bx0 + 3800.0) and (by1 - 20.0) <= my_c <= (by0 + 20.0):
                    tkt_inner_map[idx_t].append((et, c_pairs))
                    consumed_inner_ids.add(cidx_chunk)
                    break

    # Filter out old schedule & summary chunks while preserving ALL beam elevations/sections/dims
    kept_chunks = []
    for cidx_chunk, (et, c_pairs) in enumerate(chunks):
        if cidx_chunk in consumed_inner_ids:
            continue
        if any(pc == 1001 and pv.strip() == 'BeamCAD_SUM' for pc, pv in c_pairs):
            continue
        if et == 'INSERT':
            bn, _, _, _, _ = _parse_insert_info(c_pairs)
            if bn in tk_names or bn in ('TKTitle', 'TenCauKien'):
                continue
        if not has_xdata_sum:
            layer = ''
            pts_c = []
            x1 = y1 = x2 = y2 = 0.0
            got_10 = got_20 = False
            for pc, pv in c_pairs:
                if pc == 8:
                    layer = pv.strip().upper()
                elif pc == 10:
                    try:
                        xv = float(pv)
                        pts_c.append([xv, None])
                        if not got_10:
                            got_10 = True; x1 = xv
                    except Exception:
                        pass
                elif pc == 20:
                    try:
                        yv = float(pv)
                        if pts_c and pts_c[-1][1] is None:
                            pts_c[-1][1] = yv
                        if not got_20:
                            got_20 = True; y1 = yv
                    except Exception:
                        pass
                elif pc == 11:
                    try:
                        x2 = float(pv)
                    except Exception:
                        pass
                elif pc == 21:
                    try:
                        y2 = float(pv)
                    except Exception:
                        pass
            # Old member divider lines (both DCE_BaoBeTong and DCE_Lanh_To 750mm lines)
            if et == 'LINE' and layer in ('DCE_BAOBETONG', 'DCE_LANH_TO') and x1 >= min_x - 10.0 and y1 <= max_y and abs(y1 - y2) < 5.0 and abs(x2 - x1) < 850.0:
                continue
            if et == 'LWPOLYLINE' and layer in ('DCE_BAOBETONG', 'DCE_LANH_TO') and len(pts_c) == 2 and pts_c[0][0] >= min_x - 10.0 and pts_c[0][1] <= max_y and abs(pts_c[0][1] - pts_c[1][1]) < 5.0 and abs(pts_c[1][0] - pts_c[0][0]) < 850.0:
                continue
            if et == 'LWPOLYLINE' and layer == 'DEFPOINTS' and abs(x1 - (min_x - 150.0)) < 300.0 and abs(y1 - (max_y + 150.0)) < 300.0:
                continue
            if sum_title_y is not None and layer in ('DCE_LANH_TO', 'DCE_TEXT') and x1 >= min_x - 50.0 and (sum_title_y - 5000.0) <= y1 <= (min_tk_y + 50.0):
                continue
        kept_chunks.append((et, c_pairs))

    # Recalculate each TK block row & track export rows
    diam_totals = {}
    recalc_rows = []
    export_rows = []
    for idx_tk, (bn, ix, iy, atts, c_pairs) in enumerate(tk_items):
        best_tc = None
        best_dy = 1e12
        for tc in tc_items:
            if abs(tc[0] - (ix + 375.0)) < 1500.0:
                dy = abs(tc[1] - iy)
                if dy < best_dy:
                    best_dy = dy
                    best_tc = tc
        ten_name = (best_tc[2].get('TENCAUKIEN') or 'DAM') if best_tc else 'DAM'
        skc_tc = int(round(_num_dxf_attr(best_tc[2].get('SOCAUKIEN', '0'), 0.0))) if best_tc else 0
        prev_tc_skc = best_tc[3] if best_tc else 0
        skc = int(round(_num_dxf_attr(atts.get('SKC', '0'), 0.0)))
        if skc_tc > 0 and prev_tc_skc > 0 and skc_tc != prev_tc_skc and skc == prev_tc_skc:
            skc = skc_tc
        elif skc <= 0:
            skc = max(1, skc_tc)
        if skc <= 0:
            skc = 1

        dk = int(round(_num_dxf_attr(atts.get('DK', '0'), 0.0)))
        sl = max(0, int(round(_num_dxf_attr(atts.get('SL', '0'), 0.0))))
        sh = sstr(atts.get('SH', '1'))
        l1 = int(round(_num_dxf_attr(atts.get('L' if bn == 'TK1' else 'L1', '0'), 0.0)))
        l2 = int(round(_num_dxf_attr(atts.get('L2', '0'), 0.0)))
        l3 = int(round(_num_dxf_attr(atts.get('L3', '0'), 0.0)))
        l4 = int(round(_num_dxf_attr(atts.get('L4', '0'), 0.0)))
        l5 = int(round(_num_dxf_attr(atts.get('L5', '0'), 0.0)))
        m_val = int(round(_num_dxf_attr(atts.get('M', '0'), 0.0)))
        sum_l = int(round(_num_dxf_attr(atts.get('sumL', '0'), 0.0)))

        if bn == 'TK1' and l1 > 0:
            sum_l = l1
        elif bn in ('TK2', 'TK3') and (l1 + l2) > 0:
            sum_l = l1 + l2
        elif bn in ('TK4', 'TK7') and (l1 + l2 + l3) > 0:
            sum_l = l1 + l2 + l3
        elif bn == 'TK7R1' and (l1 + l2 + l3 + l4 + l5) > 0:
            sum_l = l1 + l2 + l3 + l4 + l5
        elif bn == 'TK9':
            mm = m_val if m_val > 0 else 48
            if (l1 + l2) > 0:
                sum_l = 2 * (l1 + l2) + 2 * mm

        tsl = skc * sl
        lall = (sum_l / 1000.0) * tsl
        kl = lall * ((math.pi * dk * dk / 4.0) * 0.00785) if dk > 0 else 0.0

        updates = {
            'sumL': str(sum_l),
            'SKC': str(skc),
            'TSL': str(tsl),
            'Lall': '%.2f' % lall,
            'KL': '%.2f' % kl,
        }
        recalc_rows.append((bn, ix, iy, c_pairs, ten_name, skc, updates, tkt_inner_map.get(idx_tk, [])))
        export_rows.append([ten_name, sh, bn, dk, l1, l2, l3, l4, l5, m_val, sum_l, skc, sl, tsl, round(lall, 2), round(kl, 2)])
        if dk > 0:
            prev = diam_totals.get(dk, [0.0, 0.0])
            diam_totals[dk] = [prev[0] + lall, prev[1] + kl]

    # Allocate fresh handles starting safely past max existing handle
    max_h = 0x5000
    for _, cp in kept_chunks:
        for pc, pv in cp:
            if pc == 5:
                try:
                    max_h = max(max_h, int(pv.strip(), 16) + 1)
                except Exception:
                    pass
    dxf = DxfOut()
    dxf.h = max_h

    col_w = 192.5 * 50.0
    col_gap = 1200.0
    title_h = 35.0 * 50.0
    max_bot = max_y - title_h
    col0_bot = max_bot
    total_rows = len(recalc_rows)
    num_cols = max(1, (total_rows + lim - 1) // lim)

    rebuilt_insert_pairs = []
    block_deltas = {}
    for cidx in range(num_cols):
        cx_col = min_x + cidx * (col_w + col_gap)
        dxf.insert('TKTitle', cx_col, max_y, 50, 50, 'DCE_Lanh_To', [])
        cur_y = max_y - title_h
        chunk = recalc_rows[cidx * lim:(cidx + 1) * lim]
        member_spans = []
        for bn, ox, oy, cp, ten_name, skc, updates, inner_chunks in chunk:
            row_h = 675.0 if bn == 'TKTUnknown' else 400.0
            if not member_spans or member_spans[-1][0] != ten_name or member_spans[-1][1] != skc:
                member_spans.append([ten_name, skc, cur_y, cur_y - row_h])
            else:
                member_spans[-1][3] = cur_y - row_h
            tp = _transform_insert_pairs(cp, ox, oy, cx_col, cur_y, updates)
            rebuilt_insert_pairs.extend(tp)
            dx_r, dy_r = cx_col - ox, cur_y - oy
            for et_in, cp_in in inner_chunks:
                rebuilt_insert_pairs.extend(_offset_chunk_pairs(cp_in, dx_r, dy_r))
                if et_in == 'DIMENSION' and (abs(dx_r) > 1e-4 or abs(dy_r) > 1e-4):
                    for pc, pv in cp_in:
                        if pc == 2 and pv.strip().startswith('*D'):
                            block_deltas[pv.strip()] = (dx_r, dy_r)
            cur_y -= row_h
            max_bot = min(max_bot, cur_y)
            if cidx == 0:
                col0_bot = cur_y

        for ms_bname, ms_skc, top_m, bot_m in member_spans:
            mid_m = (top_m + bot_m) / 2.0
            dxf.pline([(cx_col, bot_m), (cx_col + 750.0, bot_m)], 'DCE_Lanh_To', False, 256, 'BeamCAD_SUM')
            dxf.insert('TenCauKien', cx_col + 375.0, mid_m, 50, 50, 'DCE_Lanh_To', [
                ('SOCAUKIEN', 'SL: %d' % ms_skc, 2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', 90.0),
                ('TENCAUKIEN', ms_bname, -2.0, 0.0, 2.5, 256, 1, 2, 'Dce_text', 90.0),
            ], ('BeamCAD_SKC', [str(ms_skc)]))

    # Summary Table matching beam.dxf (Dce_Text2, bylayer color=256, directly under col 0)
    sy = col0_bot
    dks = sorted(diam_totals.keys())
    totw = 1900.0 + max(2, len(dks)) * 1100.0
    dxf.pline([(min_x, sy), (min_x + totw, sy), (min_x + totw, sy - 600), (min_x, sy - 600)], 'DCE_Lanh_To', True, 256, 'BeamCAD_SUM')
    dxf.text(min_x + totw / 2.0, sy - 300.0, 150, u'TỔNG HỢP CỐT THÉP', 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
    y0 = sy - 600.0
    for r in range(5):
        dxf.line(min_x, y0 - r * 400, min_x + totw, y0 - r * 400, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
    dxf.line(min_x, y0, min_x, y0 - 1600, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
    dxf.line(min_x + 1900, y0, min_x + 1900, y0 - 1600, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
    for idx_lbl, lbl in enumerate([u'- Đường kính (mm):', u'- Chiều dài (m):', u'- Khối lượng (kg):', u'- Chiều dài / 11.7']):
        dxf.text(min_x + 100, y0 - idx_lbl * 400 - 200, 100, lbl, 'Dce_text', 256, 0, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
    w_le10 = w_mid = w_gt18 = 0.0
    for ci, dk in enumerate(dks):
        lx, k = diam_totals[dk]
        if dk <= 10:
            w_le10 += k
        elif dk <= 18:
            w_mid += k
        else:
            w_gt18 += k
        cx0 = min_x + 1900.0 + ci * 1100.0
        dxf.line(cx0 + 1100.0, y0, cx0 + 1100.0, y0 - 1600, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
        dxf.text(cx0 + 550.0, y0 - 200, 100, '%%%%c%d' % dk, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        dxf.text(cx0 + 550.0, y0 - 600, 100, '%.2f' % lx, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        dxf.text(cx0 + 550.0, y0 - 1000, 100, '%.2f' % k, 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
        dxf.text(cx0 + 550.0, y0 - 1400, 100, str(int(math.ceil(lx / 11.7))) if dk > 10 else '-', 'Dce_text', 256, 1, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
    grand = w_le10 + w_mid + w_gt18
    row_top = y0 - 1650.0
    for glbl, gval, is_total in [
        (u'- Nhóm %%c <= 10:', w_le10, False),
        (u'- Nhóm 10 < %%c <= 18:', w_mid, False),
        (u'- Nhóm %%c > 18:', w_gt18, False),
        (u'- Tổng cộng:', grand, True),
    ]:
        if glbl != u'- Nhóm %%c > 18:' or gval > 0.0:
            if is_total:
                row_top -= 400.0
            row_bot = row_top - 400.0
            dxf.pline([(min_x, row_top), (min_x + totw, row_top), (min_x + totw, row_bot), (min_x, row_bot)], 'DCE_Lanh_To', True, 256, 'BeamCAD_SUM')
            dxf.line(min_x + 1900.0, row_top, min_x + 1900.0, row_bot, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
            if totw >= 3000.0:
                dxf.line(min_x + 3000.0, row_top, min_x + 3000.0, row_bot, 'DCE_Lanh_To', 256, 'BeamCAD_SUM')
            ym = (row_top + row_bot) / 2.0
            dxf.text(min_x + 100.0, ym, 100.0, glbl, 'Dce_text', 256, 0, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(min_x + 2450.0, ym, 100.0, '%.2f' % gval, 'Dce_text', 256, 4, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            dxf.text(min_x + 3550.0, ym, 100.0, 'kg', 'Dce_text', 256, 4, 2, 'BeamCAD_SUM', style='Dce_Text2', wf=1.0)
            row_top = row_bot

    sched_total_w = max(num_cols * col_w + max(0, num_cols - 1) * col_gap, totw)
    sched_box = [(min_x - 125.0, max_y + 125.0), (min_x + sched_total_w + 125.0, max_y + 125.0),
                 (min_x + sched_total_w + 125.0, min(row_top, max_bot) - 470.0), (min_x - 125.0, min(row_top, max_bot) - 470.0)]
    dxf.pline(sched_box, 'Defpoints', True, 256, 'BeamCAD_SUM')

    prefix_pairs = _translate_dim_block_in_prefix(prefix_pairs, block_deltas)
    out_lines = []
    for pc, pv in prefix_pairs:
        out_lines.append(str(pc))
        out_lines.append(sstr(pv) if not isinstance(pv, (int, float)) else str(pv))
    for _, cp in kept_chunks:
        for pc, pv in cp:
            out_lines.append(str(pc))
            out_lines.append(sstr(pv) if not isinstance(pv, (int, float)) else str(pv))
    for pc, pv in rebuilt_insert_pairs:
        out_lines.append(str(pc))
        out_lines.append(sstr(pv) if not isinstance(pv, (int, float)) else str(pv))
    out_lines.extend(dxf.buf)
    for pc, pv in suffix_pairs:
        out_lines.append(str(pc))
        out_lines.append(sstr(pv) if not isinstance(pv, (int, float)) else str(pv))

    with io.open(out_dxf, 'w', encoding='utf-8') as f:
        f.write(u'\r\n'.join(out_lines) + u'\r\n')
    return len(recalc_rows), grand, export_rows




def _xml_esc(val):
    s = sstr(val)
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def _col_letter(idx):
    out = ''
    n = idx + 1
    while n > 0:
        n, rem = divmod(n - 1, 26)
        out = chr(65 + rem) + out
    return out


def write_simple_xlsx(xlsx_path, sheets_ordered):
    ct_parts = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    ]
    wb_sheets = []
    wb_rels = []
    for i, (sh_name, _) in enumerate(sheets_ordered, 1):
        ct_parts.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % i)
        wb_sheets.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_xml_esc(sh_name), i, i))
        wb_rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i, i))
    ct_parts.append('</Types>')

    root_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    wb_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + ''.join(wb_sheets) + '</sheets></workbook>'
    wb_rels_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(wb_rels) + '</Relationships>'

    with zipfile.ZipFile(xlsx_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', ''.join(ct_parts).encode('utf-8'))
        zf.writestr('_rels/.rels', root_rels.encode('utf-8'))
        zf.writestr('xl/workbook.xml', wb_xml.encode('utf-8'))
        zf.writestr('xl/_rels/workbook.xml.rels', wb_rels_xml.encode('utf-8'))
        for i, (_, rows) in enumerate(sheets_ordered, 1):
            rxml = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
            for r_idx, row in enumerate(rows, 1):
                cells = []
                for c_idx, val in enumerate(row):
                    if val is None or val == '':
                        continue
                    ref = '%s%d' % (_col_letter(c_idx), r_idx)
                    if isinstance(val, (int, float)) and not isinstance(val, bool):
                        cells.append('<c r="%s"><v>%s</v></c>' % (ref, str(val)))
                    else:
                        cells.append('<c r="%s" t="inlineStr"><is><t>%s</t></is></c>' % (ref, _xml_esc(val)))
                rxml.append('<row r="%d">%s</row>' % (r_idx, ''.join(cells)))
            rxml.append('</sheetData></worksheet>')
            zf.writestr('xl/worksheets/sheet%d.xml' % i, ''.join(rxml).encode('utf-8'))


def _get_revit_param_mm(el, names, default_mm=0.0):
    if DB is None or el is None:
        return default_mm
    for nm in names:
        try:
            p = el.LookupParameter(nm)
            if p and p.HasValue and p.StorageType == DB.StorageType.Double:
                return round(p.AsDouble() * 304.8, 1)
        except Exception:
            pass
    return default_mm


def _collect_revit_model_data():
    if DB is None:
        return [], {}, [], 0.0, 'Dam_Revit', os.path.expanduser('~\\Desktop')
    try:
        uidoc = __revit__.ActiveUIDocument
        doc = uidoc.Document
    except Exception:
        doc = None
    if doc is None:
        return [], {}, [], 0.0, 'Dam_Revit', os.path.expanduser('~\\Desktop')

    doc_title = re.sub(r'[\\/:*?"<>|]+', '_', sstr(doc.Title) or 'Dam_Revit')
    doc_dir = os.path.dirname(doc.PathName) if doc.PathName else os.path.expanduser('~\\Desktop')

    frames = list(
        DB.FilteredElementCollector(doc)
        .OfCategory(DB.BuiltInCategory.OST_StructuralFraming)
        .WhereElementIsNotElementType()
        .ToElements()
    )
    rebar_by_host = {}
    try:
        rebars = (
            DB.FilteredElementCollector(doc)
            .OfCategory(DB.BuiltInCategory.OST_Rebar)
            .WhereElementIsNotElementType()
            .ToElements()
        )
        for rb in rebars:
            try:
                hid = _eid_int(rb.GetHostId())
                if hid >= 0:
                    rebar_by_host.setdefault(hid, []).append(rb)
            except Exception:
                pass
    except Exception:
        pass

    grouped = {}
    group_order = []
    level_z_mm = 0.0
    for idx_f, el in enumerate(frames, 1):
        loc = el.Location
        length_mm = 0.0
        if hasattr(loc, 'Curve') and loc.Curve is not None:
            length_mm = round(loc.Curve.Length * 304.8, 0)
        if length_mm < 200.0:
            length_mm = _get_revit_param_mm(el, ['Length', 'Cut Length'], 4000.0)
        if length_mm < 200.0:
            length_mm = 4000.0

        sym = doc.GetElement(el.GetTypeId())
        bw = _get_revit_param_mm(sym, ['b', 'Width', 'Beam Width'], 0.0) or _get_revit_param_mm(el, ['b', 'Width'], 220.0)
        bh = _get_revit_param_mm(sym, ['h', 'Height', 'Depth', 'Beam Depth'], 0.0) or _get_revit_param_mm(el, ['h', 'Height', 'Depth'], 500.0)

        mark = ''
        try:
            pm = el.get_Parameter(DB.BuiltInParameter.ALL_MODEL_MARK)
            if pm and pm.HasValue:
                mark = sstr(pm.AsString())
        except Exception:
            pass
        if not mark:
            mark = sstr(sym.Name if sym else '') or ('DAM-%d' % idx_f)

        try:
            p_lvl = el.get_Parameter(DB.BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
            if p_lvl and p_lvl.HasValue:
                lvl = doc.GetElement(p_lvl.AsElementId())
                if lvl is not None:
                    level_z_mm = round(lvl.Elevation * 304.8, 1)
        except Exception:
            pass

        top_z = 0.0
        try:
            p_zo = el.get_Parameter(DB.BuiltInParameter.Z_OFFSET_VALUE)
            if p_zo and p_zo.HasValue:
                top_z = round(p_zo.AsDouble() * 304.8, 1)
        except Exception:
            pass

        if mark not in grouped:
            grouped[mark] = []
            group_order.append(mark)
        grouped[mark].append((el, bw, bh, length_mm, top_z))

    summaries = []
    for nm in group_order:
        spans_el = grouped[nm]
        first = spans_el[0]
        hosted = []
        for el, _, _, _, _ in spans_el:
            hosted.extend(rebar_by_host.get(_eid_int(el.Id), []))
        diams = []
        top_cnt, bot_cnt = 2, 2
        for rb in hosted:
            try:
                rt = doc.GetElement(rb.GetTypeId())
                d_mm = int(round(_get_revit_param_mm(rt, ['Bar Diameter'], 18.0)))
                if d_mm >= 12:
                    diams.append(d_mm)
                    q = int(getattr(rb, 'Quantity', 2) or 2)
                    if q >= 1:
                        top_cnt = max(top_cnt, q) if d_mm == max(diams) else top_cnt
            except Exception:
                pass
        top_d = max(diams) if diams else 18
        bot_d = min(diams) if diams else 18
        note = u'Trên %dØ%d · Dưới %dØ%d · Đai Ø8-150/200' % (top_cnt, top_d, bot_cnt, bot_d)
        summaries.append((nm, len(spans_el), u'%d×%d' % (int(round(first[1])), int(round(first[2]))), note, (top_cnt, top_d, bot_cnt, bot_d)))
    return group_order, grouped, summaries, level_z_mm, doc_title, doc_dir


def _write_revit_cache_to_xlsx(group_order, grouped, summaries_map, level_z_mm, out_xlsx):
    if not group_order:
        raise ValueError(u'Không tìm thấy cấu kiện Dầm (Structural Framing) nào trong mô hình Revit.')
    nhip_hdr = [
        'Tên dầm', 'SL', 'Nhịp', 'Vật liệu',
        'Gối trái (mm)', 'Loại GT', 'Trục T', 'Lệch trục T (mm)', 'L thông thủy (mm)', 'Cấu hình nhịp',
        'Gối phải (mm)', 'Loại GP', 'Trục P', 'Lệch trục P (mm)',
        'b (mm)', 'h (mm)', 'Cao đỉnh (mm)', 'h sàn (mm)', 'Sàn T dày (mm)', 'Sàn T đỉnh (mm)', 'Sàn P dày (mm)', 'Sàn P đỉnh (mm)',
        'Đai (Ø-a gối/a nhịp)'
    ]
    while len(nhip_hdr) < 35:
        nhip_hdr.append('Đai (Ø-a gối/a nhịp)' if len(nhip_hdr) == 34 else '')
    nhip_rows = [nhip_hdr]
    thep_hdr = [
        'Tên dầm', 'Ghi chú', 'Vị trí', 'Lớp', 'SL', 'Phi', 'Gối A', 'Kiểu trái', 'Giá trị trái',
        'Gối B', 'Kiểu phải', 'Giá trị phải', 'Vượt gối'
    ]
    thep_rows = [thep_hdr]
    for bname in group_order:
        spans_el = grouped[bname]
        for sp_i, (_, bw, bh, clear_mm, top_z) in enumerate(spans_el, 1):
            row = [''] * 35
            row[0] = bname; row[1] = 1; row[2] = sp_i
            row[4] = 300.0; row[5] = 'C'; row[6] = str(sp_i); row[7] = 0.0; row[8] = clear_mm
            row[10] = 300.0; row[11] = 'C'; row[12] = str(sp_i + 1); row[13] = 0.0
            row[14] = bw; row[15] = bh; row[16] = top_z
            row[17] = 120.0; row[18] = 120.0; row[19] = top_z; row[20] = 120.0; row[21] = top_z
            row[34] = '8-150/200'
            nhip_rows.append(row)
        top_n, top_d, bot_n, bot_d = summaries_map.get(bname, (2, 18, 2, 18))
        n_sp = len(spans_el)
        thep_rows.append([bname, '', 'Trên', 1, top_n, top_d, 0, 'Neo vào gối', '30d', n_sp, 'Neo vào gối', '30d', 'Tự động'])
        thep_rows.append([bname, '', 'Dưới', 1, bot_n, bot_d, 0, 'Neo vào gối', '30d', n_sp, 'Neo vào gối', '30d', 'Tự động'])
    info_rows = [['Cao độ tầng theo Project Base Point (mm)', level_z_mm]]
    write_simple_xlsx(out_xlsx, [('Nhip', nhip_rows), ('Thep', thep_rows), ('Info', info_rows)])
    return len(group_order)


def _extract_revit_beams_to_xlsx(out_xlsx):
    group_order, grouped, summaries, level_z_mm, _, _ = _collect_revit_model_data()
    smap = {s[0]: s[4] for s in summaries}
    return _write_revit_cache_to_xlsx(group_order, grouped, smap, level_z_mm, out_xlsx)


def _send_dxf_to_open_autocad_dotnet(dxf_path):
    if Marshal is None:
        return False, u'Không có Marshal .NET.'
    acad = None
    for prog in ('AutoCAD.Application', 'ZWCAD.Application', 'GstarCAD.Application', 'BricscadApp.AcadApplication'):
        try:
            acad = Marshal.GetActiveObject(prog)
            if acad is not None:
                break
        except Exception:
            acad = None
    if acad is None:
        return False, u'Không tìm thấy AutoCAD đang mở.'
    lsp_posix = _write_cad_drop_lisp(dxf_path)
    try:
        acad.Visible = True
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.SetForegroundWindow(int(acad.HWND))
    except Exception:
        pass
    cmd = u'\x03\x03(load "%s") \n' % lsp_posix
    acad.ActiveDocument.SendCommand(cmd)
    return True, 'OK'


def run_revit_export():
    if WinForms is None:
        return
    try:
        WinForms.Application.EnableVisualStyles()
    except Exception:
        pass

    rv_order, rv_grouped, rv_summaries, rv_lvl, doc_title, doc_dir = _collect_revit_model_data()
    rv_smap = {s[0]: s[4] for s in rv_summaries}

    # Build clean standalone WinForms window (no pyRevit forms styling)
    form = WinForms.Form()
    form.Text = u'BeamCAD — Triển khai Thép Dầm & Thống Kê AutoCAD'
    form.ClientSize = Drawing.Size(820, 620)
    form.StartPosition = WinForms.FormStartPosition.CenterScreen
    form.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog
    form.MaximizeBox = False
    form.MinimizeBox = True
    form.BackColor = Drawing.Color.White
    form.Font = Drawing.Font('Segoe UI', 9.25)

    c_slate900 = Drawing.Color.FromArgb(15, 23, 42)
    c_slate600 = Drawing.Color.FromArgb(71, 85, 105)
    c_slate100 = Drawing.Color.FromArgb(248, 250, 252)
    c_border = Drawing.Color.FromArgb(226, 232, 240)
    c_blue = Drawing.Color.FromArgb(29, 78, 216)

    # Header
    pnl_hdr = WinForms.Panel()
    pnl_hdr.Location = Drawing.Point(0, 0)
    pnl_hdr.Size = Drawing.Size(820, 58)
    pnl_hdr.BackColor = c_slate100
    lbl_title = WinForms.Label()
    lbl_title.Text = u'BeamCAD — Chọn dầm & Thả thẳng vào AutoCAD hoặc Xuất DXF'
    lbl_title.Font = Drawing.Font('Segoe UI', 11.5, Drawing.FontStyle.Bold)
    lbl_title.ForeColor = c_slate900
    lbl_title.Location = Drawing.Point(18, 9)
    lbl_title.AutoSize = True
    lbl_sub = WinForms.Label()
    lbl_sub.Text = u'Chuẩn block beam.dxf · Tiêu đề %%U · Khung Defpoints chống trùng · Sửa nhanh trong CAD bằng lệnh ST / SSL / SDK / SSH / QTK'
    lbl_sub.Font = Drawing.Font('Segoe UI', 8.25)
    lbl_sub.ForeColor = c_slate600
    lbl_sub.Location = Drawing.Point(18, 33)
    lbl_sub.AutoSize = True
    pnl_hdr.Controls.Add(lbl_title)
    pnl_hdr.Controls.Add(lbl_sub)
    form.Controls.Add(pnl_hdr)

    # Source panel
    grp_src = WinForms.GroupBox()
    grp_src.Text = u'1. Nguồn dữ liệu đầu vào'
    grp_src.Font = Drawing.Font('Segoe UI', 9.0, Drawing.FontStyle.Bold)
    grp_src.ForeColor = c_slate900
    grp_src.Location = Drawing.Point(16, 68)
    grp_src.Size = Drawing.Size(788, 88)

    rb_revit = WinForms.RadioButton()
    rb_revit.Text = u'Mô hình Revit đang mở (%d dầm)' % len(rv_summaries)
    rb_revit.Font = Drawing.Font('Segoe UI', 9.0)
    rb_revit.Location = Drawing.Point(14, 24)
    rb_revit.Size = Drawing.Size(245, 22)

    rb_excel = WinForms.RadioButton()
    rb_excel.Text = u'File Excel BeamRebar (.xlsx)'
    rb_excel.Font = Drawing.Font('Segoe UI', 9.0)
    rb_excel.Location = Drawing.Point(268, 24)
    rb_excel.Size = Drawing.Size(235, 22)

    rb_dxf = WinForms.RadioButton()
    rb_dxf.Text = u'Quét lại file .DXF đã sửa trong CAD'
    rb_dxf.Font = Drawing.Font('Segoe UI', 9.0)
    rb_dxf.Location = Drawing.Point(515, 24)
    rb_dxf.Size = Drawing.Size(260, 22)

    txt_path = WinForms.TextBox()
    txt_path.Location = Drawing.Point(14, 52)
    txt_path.Size = Drawing.Size(640, 24)
    txt_path.Font = Drawing.Font('Segoe UI', 9.0)
    txt_path.ReadOnly = True
    txt_path.BackColor = c_slate100

    btn_browse = WinForms.Button()
    btn_browse.Text = u'Chọn file...'
    btn_browse.Font = Drawing.Font('Segoe UI', 9.0)
    btn_browse.Location = Drawing.Point(664, 51)
    btn_browse.Size = Drawing.Size(110, 26)
    btn_browse.FlatStyle = WinForms.FlatStyle.Flat
    btn_browse.BackColor = Drawing.Color.White
    btn_browse.FlatAppearance.BorderColor = c_border

    for _c in (rb_revit, rb_excel, rb_dxf, txt_path, btn_browse):
        grp_src.Controls.Add(_c)
    form.Controls.Add(grp_src)

    # Beam list panel
    pnl_list_hdr = WinForms.Panel()
    pnl_list_hdr.Location = Drawing.Point(16, 166)
    pnl_list_hdr.Size = Drawing.Size(788, 30)

    lbl_list = WinForms.Label()
    lbl_list.Text = u'2. Chọn dầm cần triển khai:'
    lbl_list.Font = Drawing.Font('Segoe UI', 9.0, Drawing.FontStyle.Bold)
    lbl_list.ForeColor = c_slate900
    lbl_list.Location = Drawing.Point(0, 6)
    lbl_list.AutoSize = True

    txt_search = WinForms.TextBox()
    txt_search.Location = Drawing.Point(180, 3)
    txt_search.Size = Drawing.Size(220, 24)
    txt_search.Font = Drawing.Font('Segoe UI', 9.0)

    btn_all = WinForms.Button()
    btn_all.Text = u'Chọn tất cả (ALL)'
    btn_all.Location = Drawing.Point(412, 2)
    btn_all.Size = Drawing.Size(128, 25)
    btn_all.FlatStyle = WinForms.FlatStyle.Flat
    btn_all.BackColor = Drawing.Color.FromArgb(239, 246, 255)
    btn_all.ForeColor = c_blue
    btn_all.Font = Drawing.Font('Segoe UI', 8.5, Drawing.FontStyle.Bold)

    btn_none = WinForms.Button()
    btn_none.Text = u'Bỏ chọn'
    btn_none.Location = Drawing.Point(546, 2)
    btn_none.Size = Drawing.Size(80, 25)
    btn_none.FlatStyle = WinForms.FlatStyle.Flat
    btn_none.BackColor = Drawing.Color.White
    btn_none.Font = Drawing.Font('Segoe UI', 8.5)

    lbl_count = WinForms.Label()
    lbl_count.Text = u'Đã chọn: 0/0'
    lbl_count.Location = Drawing.Point(636, 6)
    lbl_count.Size = Drawing.Size(150, 20)
    lbl_count.TextAlign = Drawing.ContentAlignment.MiddleRight
    lbl_count.ForeColor = c_blue
    lbl_count.Font = Drawing.Font('Segoe UI', 8.5, Drawing.FontStyle.Bold)

    for _c in (lbl_list, txt_search, btn_all, btn_none, lbl_count):
        pnl_list_hdr.Controls.Add(_c)
    form.Controls.Add(pnl_list_hdr)

    lv = WinForms.ListView()
    lv.Location = Drawing.Point(16, 200)
    lv.Size = Drawing.Size(788, 286)
    lv.View = WinForms.View.Details
    lv.CheckBoxes = True
    lv.FullRowSelect = True
    lv.GridLines = True
    lv.Font = Drawing.Font('Segoe UI', 9.25)
    lv.Columns.Add(u'Tên dầm', 190)
    lv.Columns.Add(u'Số nhịp', 80)
    lv.Columns.Add(u'Tiết diện (b×h)', 140)
    lv.Columns.Add(u'Chi tiết thép / Ghi chú', 350)
    form.Controls.Add(lv)

    # Options strip
    grp_opt = WinForms.GroupBox()
    grp_opt.Text = u'3. Cấu hình Cắt bảng & Tỉ lệ xuất (Khung layer Defpoints tự động)'
    grp_opt.Font = Drawing.Font('Segoe UI', 9.0, Drawing.FontStyle.Bold)
    grp_opt.ForeColor = c_slate900
    grp_opt.Location = Drawing.Point(16, 494)
    grp_opt.Size = Drawing.Size(788, 56)

    def _mk_lbl(txt, x):
        l = WinForms.Label(); l.Text = txt; l.Font = Drawing.Font('Segoe UI', 9.0); l.Location = Drawing.Point(x, 25); l.AutoSize = True; return l

    def _mk_tb(val, x):
        t = WinForms.TextBox(); t.Text = str(val); t.Font = Drawing.Font('Consolas', 10.0, Drawing.FontStyle.Bold); t.TextAlign = WinForms.HorizontalAlignment.Center; t.Location = Drawing.Point(x, 22); t.Size = Drawing.Size(58, 24); return t

    tb_lim = _mk_tb(30, 152)
    tb_elev = _mk_tb(50, 360)
    tb_sec = _mk_tb(25, 575)
    lbl_dp = WinForms.Label()
    lbl_dp.Text = u'Đặt cách nhau · Tiêu đề %%U'
    lbl_dp.Font = Drawing.Font('Segoe UI', 8.25)
    lbl_dp.ForeColor = c_slate600
    lbl_dp.Location = Drawing.Point(642, 25)
    lbl_dp.AutoSize = True

    for _c in (
        _mk_lbl(u'Cắt bảng TK (số ô):', 14), tb_lim,
        _mk_lbl(u'Tỉ lệ MC dọc (1/):', 238), tb_elev,
        _mk_lbl(u'Tỉ lệ MC ngang (1/):', 442), tb_sec,
        lbl_dp
    ):
        grp_opt.Controls.Add(_c)
    form.Controls.Add(grp_opt)

    # Footer buttons
    pnl_ftr = WinForms.Panel()
    pnl_ftr.Location = Drawing.Point(0, 558)
    pnl_ftr.Size = Drawing.Size(820, 62)
    pnl_ftr.BackColor = c_slate100

    btn_cad = WinForms.Button()
    btn_cad.Text = u'Vẽ vào AutoCAD đang mở (Pick điểm)'
    btn_cad.Location = Drawing.Point(16, 12)
    btn_cad.Size = Drawing.Size(270, 38)
    btn_cad.FlatStyle = WinForms.FlatStyle.Flat
    btn_cad.BackColor = c_blue
    btn_cad.ForeColor = Drawing.Color.White
    btn_cad.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)

    btn_dxf = WinForms.Button()
    btn_dxf.Text = u'Xuất ra file .DXF...'
    btn_dxf.Location = Drawing.Point(296, 12)
    btn_dxf.Size = Drawing.Size(175, 38)
    btn_dxf.FlatStyle = WinForms.FlatStyle.Flat
    btn_dxf.BackColor = c_slate900
    btn_dxf.ForeColor = Drawing.Color.White
    btn_dxf.Font = Drawing.Font('Segoe UI', 9.5, Drawing.FontStyle.Bold)

    btn_close = WinForms.Button()
    btn_close.Text = u'Đóng'
    btn_close.Location = Drawing.Point(714, 12)
    btn_close.Size = Drawing.Size(90, 38)
    btn_close.FlatStyle = WinForms.FlatStyle.Flat
    btn_close.BackColor = Drawing.Color.White
    btn_close.Font = Drawing.Font('Segoe UI', 9.25)

    for _c in (btn_cad, btn_dxf, btn_close):
        pnl_ftr.Controls.Add(_c)
    form.Controls.Add(pnl_ftr)

    state = {'mode': 'revit' if rv_summaries else 'excel', 'rows': [], 'checked': set([s[0] for s in rv_summaries]), 'xlsx': '', 'dxf': ''}

    def update_count():
        lbl_count.Text = u'Đã chọn: %d / %d dầm' % (len(state['checked']), len(state['rows']))

    def populate_list():
        q = sstr(txt_search.Text).lower()
        lv.BeginUpdate()
        lv.Items.Clear()
        for row in state['rows']:
            nm = row[0]
            if q and q not in nm.lower():
                continue
            it = WinForms.ListViewItem(nm)
            it.SubItems.Add(str(row[1]))
            it.SubItems.Add(row[2])
            it.SubItems.Add(row[3])
            it.Checked = (nm in state['checked'])
            lv.Items.Add(it)
        lv.EndUpdate()
        update_count()

    def on_item_checked(sender, args):
        nm = args.Item.Text
        if args.Item.Checked:
            state['checked'].add(nm)
        else:
            state['checked'].discard(nm)
        update_count()

    def load_revit_rows():
        state['rows'] = [(s[0], s[1], s[2], s[3]) for s in rv_summaries]
        state['checked'] = set([s[0] for s in rv_summaries])
        txt_path.Text = u'Đang đọc trực tiếp từ mô hình Revit: %s' % doc_title
        btn_browse.Enabled = False
        tb_elev.Enabled = True
        tb_sec.Enabled = True
        populate_list()

    def pick_excel_and_load():
        dlg = WinForms.OpenFileDialog()
        dlg.Filter = 'Excel BeamRebar (*.xlsx)|*.xlsx'
        dlg.Title = u'Chọn file Excel Dam_*.xlsx'
        def_dir = os.path.join(os.path.expanduser('~'), 'Documents', 'BeamRebar')
        if os.path.isdir(def_dir):
            dlg.InitialDirectory = def_dir
        elif os.path.isdir(doc_dir):
            dlg.InitialDirectory = doc_dir
        if dlg.ShowDialog() == WinForms.DialogResult.OK:
            state['xlsx'] = dlg.FileName
            txt_path.Text = dlg.FileName
            sums = read_excel_beam_summaries(dlg.FileName)
            state['rows'] = sums
            state['checked'] = set([s[0] for s in sums])
            populate_list()

    def pick_dxf_and_load():
        dlg = WinForms.OpenFileDialog()
        dlg.Filter = 'AutoCAD DXF (*.dxf)|*.dxf'
        dlg.Title = u'Chọn file .DXF đã sửa để quét lại thống kê'
        if os.path.isdir(doc_dir):
            dlg.InitialDirectory = doc_dir
        if dlg.ShowDialog() == WinForms.DialogResult.OK:
            state['dxf'] = dlg.FileName
            txt_path.Text = dlg.FileName
            state['rows'] = [(u'(Quét lại từ DXF)', '-', '-', os.path.basename(dlg.FileName))]
            state['checked'] = set([u'(Quét lại từ DXF)'])
            populate_list()

    def on_source_changed(sender, args):
        if rb_revit.Checked:
            state['mode'] = 'revit'
            load_revit_rows()
        elif rb_excel.Checked:
            state['mode'] = 'excel'
            btn_browse.Enabled = True
            tb_elev.Enabled = True
            tb_sec.Enabled = True
            txt_path.Text = state['xlsx'] or u'(Bấm "Chọn file..." để nạp Dam_*.xlsx)'
            state['rows'] = read_excel_beam_summaries(state['xlsx']) if state['xlsx'] else []
            state['checked'] = set([r[0] for r in state['rows']])
            populate_list()
        elif rb_dxf.Checked:
            state['mode'] = 'dxf'
            btn_browse.Enabled = True
            tb_elev.Enabled = False
            tb_sec.Enabled = False
            txt_path.Text = state['dxf'] or u'(Bấm "Chọn file..." để chọn file .DXF cần quét lại)'
            state['rows'] = [(u'(Quét lại từ DXF)', '-', '-', os.path.basename(state['dxf']))] if state['dxf'] else []
            state['checked'] = set([r[0] for r in state['rows']])
            populate_list()

    def on_browse(sender, args):
        if state['mode'] == 'excel':
            pick_excel_and_load()
        elif state['mode'] == 'dxf':
            pick_dxf_and_load()

    def on_all(sender, args):
        state['checked'] = set([r[0] for r in state['rows']])
        populate_list()

    def on_none(sender, args):
        state['checked'] = set()
        populate_list()

    def parse_cfg():
        try:
            lim = max(1, int(sstr(tb_lim.Text) or 30))
            s_elev = max(5, int(sstr(tb_elev.Text) or 50))
            s_sec = max(5, int(sstr(tb_sec.Text) or 25))
            return lim, s_elev, s_sec
        except Exception:
            WinForms.MessageBox.Show(u'Vui lòng nhập số nguyên hợp lệ cho cắt bảng và tỉ lệ.', u'Lỗi nhập liệu', WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Warning)
            return None

    def generate_to_dxf(target_dxf):
        cfg = parse_cfg()
        if cfg is None:
            return None
        lim, s_elev, s_sec = cfg
        sel = [r[0] for r in state['rows'] if r[0] in state['checked']]
        if state['mode'] == 'dxf':
            if not state['dxf']:
                WinForms.MessageBox.Show(u'Vui lòng chọn file .DXF trước.', u'Thiếu dữ liệu')
                return None
            cnt, grand, export_rows = rescan_dxf_file(state['dxf'], target_dxf, lim)
            out_xlsx = os.path.splitext(target_dxf)[0] + '_ThongKe.xlsx'
            tk_hdr = [u'Tên cấu kiện', u'Số hiệu', u'Dạng', u'Đường kính', 'L1', 'L2', 'L3', 'L4', 'L5', 'M', u'Tổng L (mm)', 'SKC', 'SL/CK', u'Tổng SL', u'Tổng dài (m)', u'Khối lượng (kg)']
            write_simple_xlsx(out_xlsx, [('ThongKeThep', [tk_hdr] + export_rows)])
            return cnt, grand, lim, s_elev, s_sec, out_xlsx
        if not sel:
            WinForms.MessageBox.Show(u'Vui lòng chọn ít nhất 1 dầm để vẽ.', u'Chưa chọn dầm')
            return None
        if state['mode'] == 'revit':
            cache_xlsx = os.path.join(doc_dir, '%s_BeamRebar.xlsx' % doc_title)
            _write_revit_cache_to_xlsx(rv_order, rv_grouped, rv_smap, rv_lvl, cache_xlsx)
            cnt, grand = build_dxf_from_excel(cache_xlsx, target_dxf, lim, s_elev, s_sec, sel)
            return cnt, grand, lim, s_elev, s_sec, cache_xlsx
        else:
            if not state['xlsx']:
                WinForms.MessageBox.Show(u'Vui lòng chọn file Excel Dam_*.xlsx trước.', u'Thiếu file Excel')
                return None
            cnt, grand = build_dxf_from_excel(state['xlsx'], target_dxf, lim, s_elev, s_sec, sel)
            return cnt, grand, lim, s_elev, s_sec, state['xlsx']

    def on_send_cad(sender, args):
        try:
            tmp_dxf = os.path.join(tempfile.gettempdir(), 'BeamCAD_Drop_%d.dxf' % int(time.time()))
            info = generate_to_dxf(tmp_dxf)
            if not info:
                return
            form.Hide()
            ok, err = _send_dxf_to_open_autocad_dotnet(tmp_dxf)
            if ok:
                form.Close()
            else:
                form.Show()
                ans = WinForms.MessageBox.Show(
                    u'%s\nBạn có muốn xuất thành file .DXF để mở bằng tay không?' % err,
                    u'Chưa thấy AutoCAD đang mở',
                    WinForms.MessageBoxButtons.YesNo,
                    WinForms.MessageBoxIcon.Question
                )
                if ans == WinForms.DialogResult.Yes:
                    on_export_dxf(sender, args)
        except Exception as ex:
            form.Show()
            WinForms.MessageBox.Show(u'Lỗi:\n%s\n\n%s' % (sstr(ex), sstr(traceback.format_exc())), u'Lỗi BeamCAD')

    def on_export_dxf(sender, args):
        try:
            cfg = parse_cfg()
            if cfg is None:
                return
            lim = cfg[0]
            dlg = WinForms.SaveFileDialog()
            dlg.Filter = 'AutoCAD DXF (*.dxf)|*.dxf'
            dlg.InitialDirectory = doc_dir
            dlg.FileName = '%s_CAD_split%d.dxf' % (doc_title, lim)
            if dlg.ShowDialog() != WinForms.DialogResult.OK:
                return
            info = generate_to_dxf(dlg.FileName)
            if not info:
                return
            cnt, grand, lim, s_elev, s_sec, ref_xlsx = info
            ans = WinForms.MessageBox.Show(
                u'Đã xuất DXF thành công:\n%s\n\nSố dòng thép: %d | Cắt bảng mỗi %d ô\nTỉ lệ dọc 1/%d — ngang 1/%d | Tổng KL: %.2f kg\nExcel dữ liệu: %s\n\nBấm YES để mở thư mục chứa file?' % (dlg.FileName, cnt, lim, s_elev, s_sec, grand, ref_xlsx),
                u'Xuất DXF thành công',
                WinForms.MessageBoxButtons.YesNo,
                WinForms.MessageBoxIcon.Information
            )
            if ans == WinForms.DialogResult.Yes:
                os.startfile(os.path.dirname(dlg.FileName))
        except Exception as ex:
            WinForms.MessageBox.Show(u'Lỗi xuất DXF:\n%s\n\n%s' % (sstr(ex), sstr(traceback.format_exc())), u'Lỗi BeamCAD')

    lv.ItemChecked += on_item_checked
    txt_search.TextChanged += lambda s, e: populate_list()
    rb_revit.CheckedChanged += on_source_changed
    rb_excel.CheckedChanged += on_source_changed
    rb_dxf.CheckedChanged += on_source_changed
    btn_browse.Click += on_browse
    btn_all.Click += on_all
    btn_none.Click += on_none
    btn_cad.Click += on_send_cad
    btn_dxf.Click += on_export_dxf
    btn_close.Click += lambda s, e: form.Close()

    if rv_summaries:
        rb_revit.Checked = True
        load_revit_rows()
    else:
        rb_excel.Checked = True
        on_source_changed(None, None)

    WinForms.Application.Run(form)


if __name__ == '__main__':
    run_revit_export()
