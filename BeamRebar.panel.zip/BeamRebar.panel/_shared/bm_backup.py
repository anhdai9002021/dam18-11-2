# -*- coding: utf-8 -*-
"""Sao luu file Excel truoc khi ghi de: <thu muc file>/backup/<ten>_<nhan>_YYYYmmdd_HHMMSS.xlsx (giu `keep` ban moi nhat / file)."""
import os
import glob
import shutil
import datetime


def backup(path, tag='bak', keep=20):
    """Tra ve duong dan ban sao, hoac None neu file chua ton tai. Loi sao luu KHONG duoc nuot: de ben goi biet."""
    if not os.path.isfile(path):
        return None
    d = os.path.join(os.path.dirname(os.path.abspath(path)), 'backup')
    if not os.path.isdir(d):
        os.makedirs(d)
    stem = os.path.splitext(os.path.basename(path))[0]
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    dst = os.path.join(d, u'%s_%s_%s.xlsx' % (stem, tag, stamp))
    k = 1
    while os.path.exists(dst):                      # 2 lan trong cung 1 giay
        k += 1
        dst = os.path.join(d, u'%s_%s_%s_%d.xlsx' % (stem, tag, stamp, k))
    shutil.copy2(path, dst)
    olds = sorted(glob.glob(os.path.join(d, stem + u'_*.xlsx')), key=os.path.getmtime)
    for f in olds[:-keep]:
        try:
            os.remove(f)
        except OSError:
            pass
    return dst
