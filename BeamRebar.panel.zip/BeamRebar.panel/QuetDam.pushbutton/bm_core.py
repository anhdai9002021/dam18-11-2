# -*- coding: utf-8 -*-
"""Logic thuan Python (khong phu thuoc Revit): gom dam, tim goi, chia nhip, gan truc luoi.
Don vi: mm. Moi toa do la (x, y)."""
import math


VERT_TOP_DOWN = False     # dam dung (theo huong NHIN CUA VIEW): True = tu TREN xuong DUOI, False = tu DUOI len tren
VIEW_R = (1.0, 0.0)       # huong 'sang phai' cua view dang quet (RightDirection, toa do mat bang); mac dinh = truc X


def to_view(dx, dy):
    """Toa do (phai, len) theo huong nhin cua view."""
    rx, ry = VIEW_R
    return dx * rx + dy * ry, -dx * ry + dy * rx


def _norm_dir(dx, dy):
    """Huong tren mat bang: dam ngang di tu TRAI sang PHAI; dam dung (lech < 1 do) di tu tren xuong duoi (hoac nguoc lai)."""
    L = math.hypot(dx, dy)
    dx, dy = dx / L, dy / L
    vx, vy = to_view(dx, dy)                 # xet huong theo view, khong theo truc X/Y cua Revit
    if abs(vx) < 0.0175:
        if (vy > 0) if VERT_TOP_DOWN else (vy < 0):
            dx, dy = -dx, -dy
    elif vx < 0:
        dx, dy = -dx, -dy
    return dx, dy


def _cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def group_beams(beams, ang_tol=1.0, lat_tol=150.0, gap_tol=1000.0):
    """Gom cac dam thang hang (cung phuong, cung duong, hai dau gan nhau) thanh 1 dam nhieu nhip."""
    n = len(beams)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    sin_tol = math.sin(math.radians(ang_tol))
    dirs = [_norm_dir(b['p1'][0] - b['p0'][0], b['p1'][1] - b['p0'][1]) for b in beams]
    for i in range(n):
        di = dirs[i]
        ni = (-di[1], di[0])
        pi = beams[i]['p0']
        ai = sorted(_dot(_sub(p, pi), di) for p in (beams[i]['p0'], beams[i]['p1']))
        for j in range(i + 1, n):
            if find(i) == find(j):
                continue
            if abs(_cross(di, dirs[j])) > sin_tol:
                continue
            pj = (beams[j]['p0'], beams[j]['p1'])
            if any(abs(_dot(_sub(p, pi), ni)) > lat_tol for p in pj):
                continue
            bj = sorted(_dot(_sub(p, pi), di) for p in pj)
            gap = max(ai[0], bj[0]) - min(ai[1], bj[1])
            if gap <= gap_tol:
                parent[find(j)] = find(i)
    out = {}
    for i in range(n):
        out.setdefault(find(i), []).append(beams[i])
    return list(out.values())


def make_axis(members):
    """Truc dam: goc O (dau trai), huong d (dx>0), phap n, chieu dai L."""
    ref = max(members, key=lambda m: math.hypot(m['p1'][0] - m['p0'][0], m['p1'][1] - m['p0'][1]))
    d = _norm_dir(ref['p1'][0] - ref['p0'][0], ref['p1'][1] - ref['p0'][1])
    n = (-d[1], d[0])
    o = ref['p0']
    s = [_dot(_sub(p, o), d) for m in members for p in (m['p0'], m['p1'])]
    smin, smax = min(s), max(s)
    o = (o[0] + d[0] * smin, o[1] + d[1] * smin)
    return {'O': o, 'd': d, 'n': n, 'L': smax - smin,
            'angle': math.degrees(math.atan2(to_view(d[0], d[1])[1], to_view(d[0], d[1])[0]))}


def _span_of(m, ax):
    a = [_dot(_sub(p, ax['O']), ax['d']) for p in (m['p0'], m['p1'])]
    return min(a), max(a)


def _col_range(col, ax):
    s = [_dot(_sub(p, ax['O']), ax['d']) for p in col['pts']]
    l = [_dot(_sub(p, ax['O']), ax['n']) for p in col['pts']]
    return min(s), max(s), min(l), max(l)


def beam_z_at(ax, members, s0, s1):
    """Cao do tuyet doi (mm) cua DINH va DAY dam tai doan [s0, s1] doc truc (lay thanh dam gan nhat)."""
    best = None
    for m in members:
        a, b = _span_of(m, ax)
        d = max(a - s1, s0 - b, 0.0)
        if best is None or d < best[0]:
            best = (d, m)
    m = best[1]
    t0, t1 = m.get('t0', m.get('top', 0.0)), m.get('t1', m.get('top', 0.0))
    h = m.get('hz') or m.get('h') or 0.0
    lz = m.get('lz', 0.0)
    return lz + max(t0, t1), lz + min(t0, t1) - h, lz


def _role_z(c, zt, zb, tol):
    z0, z1 = c.get('z0'), c.get('z1')
    if z0 is None or z1 is None:
        return True, u'Không đọc được cao độ cột - coi là đỡ dầm'
    if z0 < zb - tol:
        if z1 > zt + tol:
            return True, u'Băng qua dầm'
        if z1 >= zb - tol:
            return True, u'Cột dưới - dầm gác lên đầu cột'
        return False, u'Cột dưới - đỉnh cột thấp hơn đáy dầm %d mm (không chạm)' % round(zb - z1)
    if z0 <= zt + tol:
        return False, u'Cột cấy lên dầm'
    return False, u'Cột trên - chân cột cao hơn đỉnh dầm %d mm (không chạm)' % round(z0 - zt)


def col_role(c, zt, zb, tol=100.0, lz=None, ltol=50.0):
    """Vai tro cua cot voi dam: tra ve (do_dam, nhan, do_dam_theo_z).
    XET THEO BASE LEVEL / TOP LEVEL cua cot so voi tang (Reference Level) cua dam:
      - Base Level = tang dam           -> CAY LEN DAM (khong do dam)
      - Base Level thap hon, Top Level cao hon tang dam -> BANG QUA dam (do dam)
      - Base Level thap hon, Top Level = tang dam       -> cot DUOI, dam gac len dau cot (do dam)
      - Base Level cao hon tang dam / Top Level thap hon tang dam -> khong cham dam
    Khong co Level (cot khong rang buoc) thi xet theo cao do z. Ket qua theo z luon duoc tinh de doi chieu."""
    sz, lbz = _role_z(c, zt, zb, tol)
    eb, et = c.get('eb'), c.get('et')
    if lz is None or eb is None or et is None:
        return sz, lbz, sz
    if eb >= lz - ltol:
        if eb > lz + ltol:
            return False, u'Cột trên - Base Level cao hơn tầng dầm (không chạm)', sz
        return False, u'Cột cấy lên dầm (Base Level = tầng dầm)', sz
    if et > lz + ltol:
        return True, u'Băng qua dầm (Base Level thấp hơn, Top Level cao hơn tầng dầm)', sz
    if et >= lz - ltol:
        return True, u'Cột dưới - dầm gác lên đầu cột (Top Level = tầng dầm)', sz
    return False, u'Cột dưới - Top Level thấp hơn tầng dầm (không chạm)', sz


def find_supports(ax, members, cols, other_axes, gap_tol=1000.0, lat_pad=50.0, bw=0.0, col_tol=100.0, rel=None):
    L = ax['L']
    sup = []
    for c in cols:
        s0, s1, l0, l1 = _col_range(c, ax)
        hit = (min(l1, bw / 2.0) - max(l0, -bw / 2.0) > 50.0) if bw > 0 else (l0 - lat_pad <= 0 <= l1 + lat_pad)
        if not (hit and s1 >= -gap_tol and s0 <= L + gap_tol):   # cot cham be rong dam (khong chi tim dam)
            continue
        zt, zb, blz = beam_z_at(ax, members, s0, s1)
        is_sup, label, by_z = col_role(c, zt, zb, col_tol, blz)
        if rel is not None and s1 >= 0 and s0 <= L:
            rel.append({'name': c.get('name', ''), 'id': c.get('id', 0), 'is_sup': is_sup, 'role': label,
                        'c': (s0 + s1) / 2.0, 'w': s1 - s0, 'dep': l1 - l0, 'z0': c.get('z0'), 'z1': c.get('z1'), 'zt': zt, 'zb': zb,
                        'base_lv': c.get('base_lv', ''), 'top_lv': c.get('top_lv', ''), 'type': c.get('type', ''),
                        'zcheck': u'khớp' if by_z == is_sup else (u'LỆCH: theo z là %s' % (u'đỡ dầm' if by_z else u'không đỡ'))})
        if is_sup:
            sup.append({'kind': u'Cột', 'ref': c.get('name', ''), 's0': s0, 's1': s1,
                        'c': (s0 + s1) / 2.0, 'ecc': -(l0 + l1) / 2.0, 'w': s1 - s0, 'dep': l1 - l0, 'role': label})
    sup.sort(key=lambda s: s['c'])                 # 2 cot chong nhau cung vi tri (vd cot dau + cot qua): giu cot to hon
    ded = []
    for s in sup:
        if ded and abs(s['c'] - ded[-1]['c']) < 100.0:
            if s['w'] > ded[-1]['w']:
                ded[-1] = s
            continue
        ded.append(s)
    sup = ded
    for ob in other_axes:
        a2 = ob['axis']
        cr = _cross(ax['d'], a2['d'])
        if abs(cr) < math.sin(math.radians(10)):
            continue
        w = _sub(a2['O'], ax['O'])
        sa = _cross(w, a2['d']) / cr
        sb = _cross(w, ax['d']) / cr
        if not (-gap_tol <= sb <= a2['L'] + gap_tol and -300 <= sa <= L + 300):
            continue
        wid = ob['b'] / abs(cr)
        c = sa
        if any(s['kind'] == u'Cột' and s['s0'] - 100 <= c <= s['s1'] + 100 for s in sup):
            continue
        # dam phu: dau dam giao NAM TREN dam nay (cach dau <= 400 mm) va giao o phan giua dam nay (khong sat dau dam nay)
        sb_end = min(abs(sb), abs(a2['L'] - sb))
        phu = sb_end <= 400.0 and 400.0 < sa < L - 400.0
        sup.append({'kind': u'Dầm', 'ref': ob['name'], 's0': c - wid / 2.0, 's1': c + wid / 2.0,
                    'c': c, 'ecc': 0.0, 'role': u'Dầm phụ gác lên dầm' if phu else '',
                    'dh': max([m.get('h') or m.get('hz') or 0.0 for m in ob['members']] + [0.0])})     # cao dam do / dam phu (dai bo sung 10.4.12)
    sup.sort(key=lambda s: s['c'])
    # dau tu do / console
    if not sup or sup[0]['s0'] > 50:
        sup.insert(0, {'kind': u'Đầu tự do', 'ref': '', 's0': 0.0, 's1': 0.0, 'c': 0.0, 'ecc': 0.0})
    if sup[-1]['s1'] < L - 50:
        sup.append({'kind': u'Đầu tự do', 'ref': '', 's0': L, 's1': L, 'c': L, 'ecc': 0.0})
    return sup


def assign_grids(ax, sup, grids, max_dist=50.0):
    """Chi gan truc luoi Revit THAT SU DI QUA goi (duong luoi cat be rong cot / dam do, sai so max_dist = 50 mm).
    Khong 'bat' truc gan nhat: goi khong co truc di qua thi de trong. Moi truc chi gan cho 1 goi.
    off = vi tri truc luoi - tam goi doc theo dam (chi de tham khao)."""
    for s in sup:
        s['grid'] = ''
        s['off'] = 0.0
    cand = []
    for k, s in enumerate(sup):
        if s['kind'] == u'Đầu tự do':
            continue
        for g in grids:
            dg = _norm_dir(g['p1'][0] - g['p0'][0], g['p1'][1] - g['p0'][1])
            cr = _cross(ax['d'], dg)
            if abs(cr) < 0.5:
                continue
            sg = _cross(_sub(g['p0'], ax['O']), dg) / cr      # vi tri giao diem doc dam
            dist = 0.0 if s['s0'] <= sg <= s['s1'] else min(abs(sg - s['s0']), abs(sg - s['s1']))
            if dist <= max_dist:
                cand.append((dist, abs(sg - s['c']), k, g['name'], sg))
    cand.sort()
    used_s, used_g = set(), set()
    for dist, dc, k, name, sg in cand:
        if k in used_s or name in used_g:
            continue
        used_s.add(k)
        used_g.add(name)
        sup[k]['grid'] = name
        sup[k]['off'] = sg - sup[k]['c']
        sup[k]['gpos'] = sg                       # vi tri truc luoi Revit doc theo dam


def parallel_grid(ax, grids, max_dist=800.0):
    """Truc luoi song song gan nhat voi tim dam (vi du dam nam tren truc A)."""
    best = None
    for g in grids:
        dg = _norm_dir(g['p1'][0] - g['p0'][0], g['p1'][1] - g['p0'][1])
        if abs(_cross(dg, ax['d'])) > math.sin(math.radians(5)):
            continue
        dist = abs(_dot(_sub(ax['O'], g['p0']), (-dg[1], dg[0])))
        if dist <= max_dist and (best is None or dist < best[0]):
            best = (dist, g['name'])
    return best[1] if best else ''


def _pieces(ax, members, lo, hi):
    """Cac doan tiet dien (b, h, cao dinh) lien tiep phu kin [lo, hi] doc truc dam: [x0, x1, b, h, top, thanh_dam]."""
    raw = []
    for m in members:
        a, b = _span_of(m, ax)
        x0, x1 = max(a, lo), min(b, hi)
        if x1 - x0 > 1.0:
            raw.append([x0, x1, m['b'], m['h'], m['top'], m])
    raw.sort(key=lambda p: (p[0], p[1]))
    seq = []
    for p in raw:
        if seq:
            prev = seq[-1]
            if p[0] < prev[1] - 0.5:               # chong lan: phan chong thuoc ve doan truoc
                p[0] = prev[1]
                if p[1] - p[0] <= 1.0:
                    continue
            elif p[0] > prev[1] + 0.5:             # ho giua 2 thanh dam: chia doi
                mid = (p[0] + prev[1]) / 2.0
                prev[1], p[0] = mid, mid
        seq.append(p)
    if seq:
        seq[0][0], seq[-1][1] = lo, hi
    merged = []                                     # gop cac doan lien tiep cung tiet dien
    for p in seq:
        if (merged and abs(merged[-1][2] - p[2]) < 1 and abs(merged[-1][3] - p[3]) < 1
                and abs(merged[-1][4] - p[4]) < 2):
            merged[-1][1] = p[1]
        else:
            merged.append(p)
    out = []                                        # bo doan qua ngan (< 60 mm) do sai so mo hinh
    for p in merged:
        if p[1] - p[0] < 60.0 and len(merged) > 1:
            if out:
                out[-1][1] = p[1]
            else:
                merged[1][0] = p[0]
            continue
        out.append(p)
    return out or merged


def _virtual(x):
    return {'kind': u'Đổi tiết diện', 'ref': '', 's0': x, 's1': x, 'c': x, 'ecc': 0.0, 'grid': '', 'off': 0.0}


def build_spans(ax, sup, members, planted=None):
    """Tra ve (supports, spans). Nhip co nhieu tiet dien / cao do khac nhau duoc TACH THANH CAC DOAN:
    giua cac doan chen 'goi ao' (kind 'Doi tiet dien', be rong 0) de moi doan co dung b, h, cao do."""
    c_lo, c_hi = sup[0]['c'], sup[-1]['c']
    planted = [dict(q, c=min(max(q['c'], c_lo), c_hi), c0=q['c']) for q in (planted or [])]   # cot cay sat dau dam van thuoc nhip ngoai cung
    sup2, spans = [sup[0]], []
    for i in range(len(sup) - 1):
        a, b = sup[i], sup[i + 1]
        lo, hi = a['s1'], b['s0']
        pcs = _pieces(ax, members, lo, hi)
        if not pcs:   # khong co thanh dam nao phu nhip: lay thanh gan nhat
            mid = (lo + hi) / 2.0
            m = min(members, key=lambda m: min(abs(mid - _span_of(m, ax)[0]), abs(mid - _span_of(m, ax)[1])))
            pcs = [[lo, hi, m['b'], m['h'], m['top'], m]]
        bounds = [a] + [_virtual(pcs[k][1]) for k in range(len(pcs) - 1)] + [b]
        last_sp = (i == len(sup) - 2)
        for k, p in enumerate(pcs):
            L, R = bounds[k], bounds[k + 1]
            ref = p[5]
            hsL, ztL, hsR, ztR = ref.get('hsL', 0.0), ref.get('ztL', 0.0), ref.get('hsR', 0.0), ref.get('ztR', 0.0)
            dm = (ref['p1'][0] - ref['p0'][0], ref['p1'][1] - ref['p0'][1])
            if dm[0] * ax['d'][0] + dm[1] * ax['d'][1] < 0:          # thanh dam nguoc huong truc -> doi trai/phai
                hsL, ztL, hsR, ztR = hsR, ztR, hsL, ztL
            console = L['kind'] == u'Đầu tự do' or R['kind'] == u'Đầu tự do'
            last_pc = last_sp and k == len(pcs) - 1
            pl = [q for q in (planted or []) if L['c'] <= q['c'] and (q['c'] < R['c'] or (last_pc and q['c'] <= R['c']))]
            pl.sort(key=lambda q: q['c'])
            spans.append({'idx': len(spans) + 1, 'left': L, 'right': R, 'clear': max(0.0, p[1] - p[0]),
                          'cc': (R['gpos'] - L['gpos']) if ('gpos' in L and 'gpos' in R) else (R['c'] - L['c']), 'console': console, 'b': p[2], 'h': p[3], 'top': p[4],
                          'hs': ref.get('hs', 0.0), 'dz': ref.get('dz', 0.0), 'pieces': [p[:5]], 'sec': u'',
                          'slabL': (hsL, ztL) if hsL > 0 else None, 'slabR': (hsR, ztR) if hsR > 0 else None,
                          'segment': k > 0 or k < len(pcs) - 1, 'planted': [q['name'] for q in pl],
                          'planted_tok': u';'.join((u'%s@%d@%d@%d' % (q['name'], round(q['c0'] - p[0]), round(q.get('w', 0)), round(q['dep'])))
                                                   if q.get('dep') else (u'%s@%d@%d' % (q['name'], round(q['c0'] - p[0]), round(q.get('w', 0)))) for q in pl)})
            sup2.append(R)
    return sup2, spans


def process_level(beams, cols, grids, ang_tol=1.0, lat_tol=150.0, gap_tol=1000.0, col_tol=100.0):
    """Cac dam cung 1 tang -> danh sach 'dam vat ly' (chuoi doan dam thang hang cung Mark)."""
    by = {}
    for b in beams:
        by.setdefault(b.get('mark', ''), []).append(b)
    insts = []
    for mark, bl in by.items():
        for mem in group_beams(bl, ang_tol, lat_tol, gap_tol):
            ax = make_axis(mem)
            insts.append({'mark': mark, 'members': mem, 'axis': ax, 'b': max(m['b'] for m in mem),
                          'name': mark or '?', 'level': mem[0].get('level', '')})
    for it in insts:
        ax = it['axis']
        it['col_rel'] = []
        it['supports'] = find_supports(ax, it['members'], cols, [o for o in insts if o is not it], gap_tol,
                                       bw=it['b'], col_tol=col_tol, rel=it['col_rel'])
        colsup = [s for s in it['supports'] if s['kind'] == u'Cột']
        it['planted'] = []
        for r in it['col_rel']:
            if r['is_sup']:
                continue
            if any(s['s0'] - 50 <= r['c'] <= s['s1'] + 50 for s in colsup):      # cot tren nam ngay tren cot do dam
                r['role0'] = r['role']
                r['role'] = u'Cột trên - nằm trên cột đỡ dầm (cột liên tục)'
                r['on_support'] = True
                continue
            it['planted'].append(r)
        # cot DUOI co cot TREN tiep tuc (cot lien tuc): khong phai 'cot duoi dung lai o dam' -> doi nhan, van la goi do dam
        ups = [r for r in it['col_rel'] if r.get('on_support') and (r.get('role0') or u'').startswith(u'Cột cấy lên dầm')]
        for r in it['col_rel']:
            if not r['is_sup'] or not r['role'].startswith(u'Cột dưới'):
                continue
            h = r['w'] / 2.0
            if any(r['c'] - h - 50 <= u_['c'] <= r['c'] + h + 50 for u_ in ups):
                old_role = r['role']
                r['role'] = u'Cột dưới - có cột trên tiếp tục (cột liên tục qua dầm, đỡ dầm)'
                for s_ in it['supports']:
                    if s_['kind'] == u'Cột' and s_.get('ref') == r['name'] and s_.get('role') == old_role:
                        s_['role'] = r['role']
        assign_grids(ax, it['supports'], grids)
        ax['grid'] = parallel_grid(ax, grids)
        it['supports'], it['spans'] = build_spans(ax, it['supports'], it['members'], it['planted'])
    return insts


def _plant_sig(x, step=50.0):
    """Chu ky VI TRI cot cay tren 1 nhip: (vi tri tam cot so voi mep nhip, be rong cot), lam tron `step` mm.
    Truoc day chi so SO LUONG cot cay -> cac dam cung Mark nhung cot cay o cho khac nhau bi gop nham thanh 1 dam,
    cot hien thi theo dam dau tien => sai vi tri."""
    out = []
    for tok in (x.get('planted_tok') or u'').split(u';'):
        a = tok.rsplit(u'@', 2)
        if len(a) == 3:
            try:
                out.append((int(round(float(a[1]) / step)), int(round(float(a[2]) / step))))
            except ValueError:
                pass
    return tuple(sorted(out))


def _sig(it):
    sup = tuple(int(round((s['s1'] - s['s0']) / 10.0)) for s in it['supports'])
    sp = tuple((int(round(x['clear'] / 10.0)),
                tuple((int(round((p[1] - p[0]) / 10.0)), int(round(p[2])), int(round(p[3])), int(round(p[4] / 10.0)))
                      for p in x['pieces']), _plant_sig(x)) for x in it['spans'])
    return (sup, sp)


def reverse_instance(it):
    ax = it['axis']
    L = ax['L']
    nax = dict(ax)
    nax['O'] = (ax['O'][0] + ax['d'][0] * L, ax['O'][1] + ax['d'][1] * L)
    nax['d'] = (-ax['d'][0], -ax['d'][1])
    nax['n'] = (-ax['n'][0], -ax['n'][1])
    sup = []
    for s in reversed(it['supports']):
        t = dict(s)
        t['s0'], t['s1'], t['c'] = L - s['s1'], L - s['s0'], L - s['c']
        t['ecc'] = -s['ecc']
        t['off'] = -s.get('off', 0.0)
        if 'gpos' in s:
            t['gpos'] = L - s['gpos']
        sup.append(t)
    r = dict(it)
    r['axis'], r['supports'] = nax, sup
    pl = [dict(q, c=L - q['c']) for q in it.get('planted', [])]
    r['supports'], r['spans'] = build_spans(nax, sup, it['members'], pl)
    return r


def _place(it):
    g = [s['grid'] for s in it['supports'] if s.get('grid')]
    par = it['axis'].get('grid', '')
    se = u'%s-%s' % (g[0], g[-1]) if len(g) >= 2 else (g[0] if g else u'')
    return u'%s(%s)' % (par, se) if par and se else (par or se or u'?')


def merge(insts):
    """Gop cac dam cung Mark va cung hinh dang (ke ca dam doi chieu nhau) -> 1 dam dien hinh + so luong (SL).
    Dam dien hinh luon giu huong nhin tren mat bang: ngang trai->phai, dung duoi->tren."""
    groups = {}
    for it in insts:
        a = _sig(it)
        b = _sig(reverse_instance(it))
        groups.setdefault(it['mark'], {}).setdefault(min(a, b), []).append(it)
    items = []
    nomark = 0
    for mark in sorted(groups):
        order = sorted(groups[mark].items(), key=lambda kv: -len(kv[1]))
        for k, (sg, lst) in enumerate(order):
            lst.sort(key=lambda i: (i['axis']['O'][1], i['axis']['O'][0]))
            typ = dict(lst[0])
            if mark:
                typ['name'] = mark if k == 0 else u'%s~%d' % (mark, k + 1)
            else:
                nomark += 1
                typ['name'] = u'NOMARK-%d' % nomark
            typ['count'] = len(lst)
            typ['levels'] = sorted(set(i['level'] for i in lst))
            typ['ids'] = [m['id'] for i in lst for m in i['members']]
            typ['places'] = u'; '.join(sorted(set(_place(i) for i in lst)))
            typ['variant'] = (len(order) > 1 and mark) and k + 1 or 0
            typ['nvariants'] = len(order)
            typ['nomark'] = not mark
            items.append(typ)

    def key(it):
        return (it['name'].split('~')[0], it['variant'])
    items.sort(key=key)
    return items


def beam_tops(so, eo, zo, zj, h, tb=None, tol=5.0):
    """Cao do DINH dam (mm, so voi Reference Level) tai 2 dau, tinh tu tham so Revit:
        so = Start Level Offset, eo = End Level Offset (cao do dau 0 / dau 1 so voi Reference Level)
        zo = z Offset Value (dich them theo phuong dung)
        zj = Z Justification: 'top' | 'center' | 'bottom' | 'origin' (dac biet: origin xem nhu top)
    Duong tim (location line) nam o cao do (offset + zo); mat cat treo theo Z Justification:
        top    : dinh = tim            center : dinh = tim + h/2          bottom : dinh = tim + h
    tb (tuy chon) = dinh theo bounding box de doi chieu: neu lech > tol thi thu cac Z Justification khac,
    cai nao khop thi dung (nguon ghi ro). Tra ve (t0, t1, zj_dung, nguon)."""
    sh = {'top': 0.0, 'origin': 0.0, 'center': h / 2.0, 'bottom': h}
    zj = zj if zj in sh else 'top'
    src = u'tham số'
    if tb is not None and abs(max(so, eo) + zo + sh[zj] - tb) > tol:
        for k in ('top', 'center', 'bottom'):
            if abs(max(so, eo) + zo + sh[k] - tb) <= tol:
                zj, src = k, u'tham số (Z Justification suy từ bbox)'
                break
        else:
            src = u'tham số - KHÔNG khớp bbox'
    return so + zo + sh[zj], eo + zo + sh[zj], zj, src