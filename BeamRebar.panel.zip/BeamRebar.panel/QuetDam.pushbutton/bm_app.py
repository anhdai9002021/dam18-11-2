# -*- coding: utf-8 -*-
"""Toan bo logic nam trong MODULE that (sys.modules) de khong bi pyRevit don scope sau khi lenh ket thuc."""
import os, sys, re, math, datetime, traceback, builtins

import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
clr.AddReference("RevitAPI")
from System import Decimal
from System.Windows.Forms import (Form, Label, ComboBox, TextBox, Button, NumericUpDown, CheckBox,
                                  FolderBrowserDialog, MessageBox, Application, DialogResult, FormStartPosition,
                                  FormBorderStyle, ComboBoxStyle, MessageBoxButtons, MessageBoxIcon, Panel, DockStyle)
from System.Drawing import Point, Size
from Autodesk.Revit.DB import (FilteredElementCollector, BuiltInCategory, BuiltInParameter, Level, Grid,
                               Line, LocationCurve, Options, Solid, GeometryInstance, PlanarFace,
                               FamilyInstance, StorageType, ViewDetailLevel, ViewPlan, XYZ)
from Autodesk.Revit.DB.Structure import StructuralType
from pyrevit import revit

import bm_xlsxw, bm_xlsxr, bm_backup, bm_keep, bm_report, bm_core, bm_ui, bm_revit
import importlib
for _m in (bm_xlsxw, bm_xlsxr, bm_backup, bm_keep, bm_core, bm_report, bm_ui):
    importlib.reload(_m)
core, report = bm_core, bm_report

doc = revit.doc
FT = 304.8
B_NAMES = ["b", "B", "Width", u"Chiều rộng", u"Rộng", u"Bề rộng"]
H_NAMES = ["h", "H", "Height", "Depth", u"Chiều cao", u"Cao", u"Chiều sâu"]


# ------------------------------------------------------------------ tien ich
def _eid(e):
    i = e.Id
    try:
        return int(i.Value)
    except Exception:
        return int(i.IntegerValue)


_PROG = [None]


def _tick(msg, i, every=25):
    """Cap nhat trang thai + bom message de Revit khong bi 'Not responding' khi quet lau."""
    if i % every:
        return
    f = _PROG[0]
    if f is None:
        return
    try:
        f.status.Text = msg
        Application.DoEvents()
    except Exception:
        pass


def _cat(bic, view=None):
    fc = FilteredElementCollector(doc, view.Id) if view is not None else FilteredElementCollector(doc)
    return fc.OfCategory(bic).WhereElementIsNotElementType()


def _dbl(obj, names):
    for n in names:
        try:
            p = obj.LookupParameter(n)
        except Exception:
            p = None
        if p is not None and p.HasValue and p.StorageType == StorageType.Double:
            v = p.AsDouble() * FT
            if v > 0:
                return v
    return 0.0


def _p_mm(el, bip_name):
    """Gia tri chieu dai (mm) cua tham so BuiltIn (am van giu nguyen dau); None neu khong co."""
    bip = getattr(BuiltInParameter, bip_name, None)
    if bip is None:
        return None
    try:
        p = el.get_Parameter(bip)
        if p is not None and p.HasValue and p.StorageType == StorageType.Double:
            return p.AsDouble() * FT
    except Exception:
        pass
    return None


def _zjust(el):
    """Z Justification cua dam: 'top' | 'center' | 'bottom' | 'origin' | None."""
    bip = getattr(BuiltInParameter, 'Z_JUSTIFICATION', None)
    p = None
    try:
        p = el.get_Parameter(bip) if bip is not None else None
    except Exception:
        pass
    if p is None:
        return None
    try:
        t = (p.AsValueString() or u'').lower()
    except Exception:
        t = u''
    for key, val in ((u'top', 'top'), (u'trên', 'top'), (u'center', 'center'), (u'giữa', 'center'),
                     (u'bottom', 'bottom'), (u'dưới', 'bottom'), (u'origin', 'origin'), (u'gốc', 'origin')):
        if key in t:
            return val
    try:
        return {0: 'top', 1: 'center', 2: 'origin', 3: 'bottom'}.get(p.AsInteger())
    except Exception:
        return None


def _type_size(inst):
    """b, h (mm) cua dam: tham so type -> tham so instance -> doc tu ten type (300x600)."""
    sym = doc.GetElement(inst.GetTypeId())
    b = _dbl(sym, B_NAMES) or _dbl(inst, B_NAMES)
    h = _dbl(sym, H_NAMES) or _dbl(inst, H_NAMES)
    name = ''
    try:
        name = sym.Name or ''
    except Exception:
        pass
    src = u'tham số' if (b and h) else u''
    if not (b and h):
        m = re.search(r'(\d+(?:[.,]\d+)?)\s*[xX\u00d7*/]\s*(\d+(?:[.,]\d+)?)', name)
        if m:
            src = u'tên type'

            v1 = float(m.group(1).replace(',', '.'))
            v2 = float(m.group(2).replace(',', '.'))
            if v1 <= 150 and v2 <= 150:   # ghi bang cm
                v1, v2 = v1 * 10, v2 * 10
            b, h = b or v1, h or v2
    if not (b and h):
        src = u'THIẾU'
    return b, h, name, src


def _hull(pts):
    pts = sorted(set(pts))
    if len(pts) < 3:
        return pts

    def cr(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def _geo_opts():
    o = Options()
    o.ComputeReferences = False
    o.DetailLevel = ViewDetailLevel.Coarse          # nhe hon Fine rat nhieu, du de lay chan cot / mat san
    return o


def _walk_solids(geo):
    for o in geo:
        if isinstance(o, GeometryInstance):
            for s in _walk_solids(o.GetInstanceGeometry()):
                yield s
        elif isinstance(o, Solid) and o.Volume > 0:
            yield o


def _footprint(el):
    pts = set()
    for s in _walk_solids(el.get_Geometry(_geo_opts())):
        for e in s.Edges:
            for q in e.Tessellate():
                pts.add((round(q.X * FT, 1), round(q.Y * FT, 1)))
    return _hull(list(pts))


def _top_outline(fl):
    """Duong bao mat tren cua san (polygon mm)."""
    best = None
    for s in _walk_solids(fl.get_Geometry(_geo_opts())):
        for f in s.Faces:
            if isinstance(f, PlanarFace) and f.FaceNormal.Z > 0.99:
                z = f.Origin.Z
                if best is None or z > best[0]:
                    best = (z, f)
    if best is None:
        return []
    poly, area = [], -1
    for loop in best[1].GetEdgesAsCurveLoops():
        pts = []
        for cv in loop:
            for q in cv.Tessellate():
                pts.append((q.X * FT, q.Y * FT))
        if len(pts) < 3:
            continue
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        a = (max(xs) - min(xs)) * (max(ys) - min(ys))
        if a > area:
            poly, area = pts, a
    return poly


def _in_poly(pt, poly):
    x, y = pt
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-12) + xi:
            inside = not inside
        j = i
    return inside


# ------------------------------------------------------------------ thu thap
def _mark(el):
    try:
        p = el.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)
        return (p.AsString() or '').strip() if p is not None else ''
    except Exception:
        return ''


def collect_beams(view):
    """view=None: toan cong trinh. Tra ve ({level_id: (Level, [dam])}, [dam bo qua kem ly do])."""
    out, skipped = {}, []
    for k, el in enumerate(_cat(BuiltInCategory.OST_StructuralFraming, view)):
        _tick(u"Dang quet dam... %d" % k, k, 50)
        eid, mk = -1, u''
        try:
            if not isinstance(el, FamilyInstance) or el.StructuralType != StructuralType.Beam:
                continue
            eid, mk = _eid(el), _mark(el)
            p = el.get_Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM)
            lv = doc.GetElement(p.AsElementId()) if p is not None else None
            if lv is None or not isinstance(lv, Level):
                skipped.append((eid, mk, u'Không có Reference Level', 0, 0))
                continue
            loc = el.Location
            if not isinstance(loc, LocationCurve) or not isinstance(loc.Curve, Line):
                skipped.append((eid, mk, u'Dầm cong / không có đường tim thẳng', 0, 0))
                continue
            a, b = loc.Curve.GetEndPoint(0), loc.Curve.GetEndPoint(1)
            ln = math.hypot((b.X - a.X) * FT, (b.Y - a.Y) * FT)
            dz = abs(b.Z - a.Z) * FT
            if ln < 100:
                skipped.append((eid, mk, u'Quá ngắn trên mặt bằng (< 100 mm)', round(ln), round(dz)))
                continue
            if dz > 0.3 * ln:
                skipped.append((eid, mk, u'Dốc quá 30%', round(ln), round(dz)))
                continue
            lz = lv.Elevation * FT
            bb = el.get_BoundingBox(None)
            bw, bh, tn, src = _type_size(el)
            hbb = ((bb.Max.Z - bb.Min.Z) * FT) if bb else 0.0
            hh = bh or max(0.0, hbb - dz)
            so = _p_mm(el, 'STRUCTURAL_BEAM_END0_ELEVATION')     # Start Level Offset
            eo = _p_mm(el, 'STRUCTURAL_BEAM_END1_ELEVATION')     # End Level Offset
            if so is None:
                so = a.Z * FT - lz                               # du phong: cao do dau tim so voi Reference Level
            if eo is None:
                eo = b.Z * FT - lz
            zo = _p_mm(el, 'Z_OFFSET_VALUE') or 0.0              # z Offset Value
            tb = (bb.Max.Z * FT - lz) if bb else None
            t0, t1, zj, zsrc = core.beam_tops(so, eo, zo, _zjust(el) or 'top', hh, tb)
            top, dz = max(t0, t1), abs(t1 - t0)
            lid = _eid(lv)
            out.setdefault(lid, (lv, []))[1].append(
                dict(id=eid, p0=(a.X * FT, a.Y * FT), p1=(b.X * FT, b.Y * FT), b=bw, h=bh,
                     top=top, type=tn, hs=0.0, mark=mk, level=lv.Name,
                     dz=dz, t0=t0, t1=t1, hbb=hbb, src=src, so=so, eo=eo, zo=zo, zj=zj,
                     tb=(tb if tb is not None else 0.0), zsrc=zsrc, lz=lz, hz=hh))
        except Exception as ex:
            skipped.append((eid, mk, u'Lỗi: %s' % ex, 0, 0))
    return out, skipped


def _first_param(el, names):
    for n in names:
        bip = getattr(BuiltInParameter, n, None)
        if bip is None:
            continue
        try:
            p = el.get_Parameter(bip)
        except Exception:
            p = None
        if p is not None:
            return p
    return None


def _col_z(el):
    """Cao do chan / dinh cot (mm tuyet doi) theo Base Level + Base Offset, Top Level + Top Offset.
    Tra ve (z0, z1, base_level_name, top_level_name, base_off, top_off); z = None neu khong doc duoc."""
    def lvl(names):
        p = _first_param(el, names)
        try:
            lv = doc.GetElement(p.AsElementId()) if p is not None else None
        except Exception:
            lv = None
        return lv if isinstance(lv, Level) else None

    def off(names):
        p = _first_param(el, names)
        try:
            if p is not None and p.HasValue and p.StorageType == StorageType.Double:
                return p.AsDouble() * FT
        except Exception:
            pass
        return 0.0
    bl = lvl(['FAMILY_BASE_LEVEL_PARAM', 'SCHEDULE_BASE_LEVEL_PARAM'])
    tl = lvl(['FAMILY_TOP_LEVEL_PARAM', 'SCHEDULE_TOP_LEVEL_PARAM'])
    bo = off(['FAMILY_BASE_LEVEL_OFFSET_PARAM', 'SCHEDULE_BASE_LEVEL_OFFSET_PARAM'])
    to = off(['FAMILY_TOP_LEVEL_OFFSET_PARAM', 'SCHEDULE_TOP_LEVEL_OFFSET_PARAM'])
    z0 = (bl.Elevation * FT + bo) if bl is not None else None
    z1 = (tl.Elevation * FT + to) if tl is not None else None
    eb = bl.Elevation * FT if bl is not None else None
    et = tl.Elevation * FT if tl is not None else None
    return z0, z1, (bl.Name if bl is not None else u''), (tl.Name if tl is not None else u''), bo, to, eb, et


def collect_columns(view, lzs=None):
    """Thu thap TAT CA cot gan cac tang dang quet (cot duoi, cot tren, cot di xuyen) - KHONG gop theo vi tri,
    vi cot duoi va cot tren cung tim nhung vai tro voi dam khac nhau."""
    out = []
    for k, el in enumerate(_cat(BuiltInCategory.OST_StructuralColumns, view)):
        _tick(u"Dang quet cot... %d" % k, k)
        try:
            bb = el.get_BoundingBox(None)
            if bb is None:
                continue
            if lzs and not any(bb.Min.Z * FT <= z + 1500 and bb.Max.Z * FT >= z - 1500 for z in lzs):
                continue                              # cot khong gan tang nao dang quet: bo qua, khong tinh hinh hoc
            pts = _footprint(el)
            if len(pts) < 3:
                continue
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            name = _mark(el) or 'C%d' % _eid(el)
            try:
                tn = doc.GetElement(el.GetTypeId()).Name
            except Exception:
                tn = ''
            zmin, zmax = bb.Min.Z * FT, bb.Max.Z * FT
            z0, z1, bl, tl, bo, to, eb, et = _col_z(el)
            if z0 is not None and z1 is not None and z1 > z0:
                zsrc = u'Base/Top Level'
                if abs(z0 - zmin) > 50 or abs(z1 - zmax) > 50:
                    zsrc += u' (lệch bbox: %d / %d mm)' % (round(z0 - zmin), round(z1 - zmax))
            else:
                z0, z1, zsrc = zmin, zmax, u'bbox (không đọc được Base/Top Level)'
            out.append(dict(id=_eid(el), name=name, pts=pts, cx=(min(xs) + max(xs)) / 2.0,
                            cy=(min(ys) + max(ys)) / 2.0, area=(max(xs) - min(xs)) * (max(ys) - min(ys)),
                            wx=max(xs) - min(xs), wy=max(ys) - min(ys), type=tn,
                            zmin=zmin, zmax=zmax, z0=z0, z1=z1, base_lv=bl, top_lv=tl, boff=bo, toff=to, eb=eb, et=et, zsrc=zsrc))
        except Exception:
            continue
    return out


def cols_for_level(allcols, lz):
    """Cot co the cham dam cua tang nay (chan/dinh cot trong khoang +-1500 mm quanh Level). Khong gop theo vi tri."""
    return [c for c in allcols if c['z0'] <= lz + 1500 and c['z1'] >= lz - 1500]


GRID_SKIP = []


def _san(name):
    return re.sub(r'[^\w\-]+', '_', name or u'') or u'Level'


def level_filenames():
    """{id level: 'Dam_<ten>.xlsx'}. Hai level co ten sau khi lam sach TRUNG nhau (khong phan biet hoa/thuong, vd 'L1 (+3)' va 'L1 [+3]')
    thi them ElementId vao ten. Xet TREN TOAN BO level cua model nen ten file cua 1 tang luon giong nhau du quet 1 mat bang hay ca cong trinh."""
    groups = {}
    for lv in FilteredElementCollector(doc).OfClass(Level):
        groups.setdefault(_san(lv.Name).lower(), []).append(lv)
    out = {}
    for g in groups.values():
        for lv in g:
            out[_eid(lv)] = u'Dam_%s.xlsx' % (_san(lv.Name) if len(g) == 1 else u'%s_%d' % (_san(lv.Name), _eid(lv)))
    return out


def collect_grids(view):
    out = []
    del GRID_SKIP[:]
    for g in _cat(BuiltInCategory.OST_Grids, view):
        try:
            c = g.Curve
            if isinstance(c, Line):
                a, b = c.GetEndPoint(0), c.GetEndPoint(1)
                out.append(dict(name=g.Name, p0=(a.X * FT, a.Y * FT), p1=(b.X * FT, b.Y * FT)))
            else:
                GRID_SKIP.append(u'%s (%s)' % (g.Name, type(c).__name__))
        except Exception as ex:
            GRID_SKIP.append(u'%s (lỗi: %s)' % (g.Name, ex))
    return out


def _floor_thickness(fl):
    t = doc.GetElement(fl.GetTypeId())
    for bip in (BuiltInParameter.FLOOR_ATTR_DEFAULT_THICKNESS_PARAM, BuiltInParameter.FLOOR_ATTR_THICKNESS_PARAM):
        try:
            p = t.get_Parameter(bip)
            if p is not None and p.HasValue and p.AsDouble() > 0:
                return p.AsDouble() * FT
        except Exception:
            pass
    try:
        return t.GetCompoundStructure().GetWidth() * FT
    except Exception:
        return 0.0


def collect_floors(view, lzs=None):
    out = []
    for k, fl in enumerate(_cat(BuiltInCategory.OST_Floors, view)):
        _tick(u"Dang quet san... %d" % k, k, 10)
        try:
            bb = fl.get_BoundingBox(None)
            if bb is None:
                continue
            if lzs and not any(z - 800 <= bb.Max.Z * FT <= z + 500 for z in lzs):
                continue                              # san khong thuoc tang nao dang quet
            poly = _top_outline(fl)
            if len(poly) < 3:
                continue
            try:
                tn = doc.GetElement(fl.GetTypeId()).Name
            except Exception:
                tn = ''
            out.append(dict(id=_eid(fl), type=tn, th=_floor_thickness(fl), poly=poly, ztop=bb.Max.Z * FT))
        except Exception:
            continue
    return out


def _slab_at(pt, floors):
    best = None
    for f in floors:
        if _in_poly(pt, f['poly']) and (best is None or f['ztop'] > best['ztop']):
            best = f
    return best


def assign_slab(beams, floors, lz):
    """San o hai ben thanh dam: day + cao do dinh (so voi Level). L = ben trai khi nhin theo huong p0 -> p1."""
    for b in beams:
        dx, dy = b['p1'][0] - b['p0'][0], b['p1'][1] - b['p0'][1]
        ln = math.hypot(dx, dy)
        nx, ny = -dy / ln, dx / ln
        mx, my = (b['p0'][0] + b['p1'][0]) / 2.0, (b['p0'][1] + b['p1'][1]) / 2.0
        off = (b['b'] or 300) / 2.0 + 100.0
        sl = _slab_at((mx + nx * off, my + ny * off), floors)
        sr = _slab_at((mx - nx * off, my - ny * off), floors)
        b['hsL'], b['ztL'] = (sl['th'], sl['ztop'] - lz) if sl else (0.0, 0.0)
        b['hsR'], b['ztR'] = (sr['th'], sr['ztop'] - lz) if sr else (0.0, 0.0)
        b['hs'] = max(b['hsL'], b['hsR'])


# ------------------------------------------------------------------ giao dien (cua so KHONG chan Revit)
class ScanForm(object):
    def __init__(self, runner):
        self.runner = runner
        pal = bm_ui.LIGHT
        f = self.f = Form()
        f.Text = u"Quét dầm → Excel"
        f.Size = Size(540, 520)
        f.StartPosition = FormStartPosition.CenterScreen
        f.FormBorderStyle = FormBorderStyle.FixedDialog
        f.MaximizeBox = False
        f.Font = bm_ui.font(9.0)

        head = Panel()
        head.Dock = DockStyle.Top
        head.Height = 62
        head.Tag = 'head'
        f.Controls.Add(head)
        t1 = Label()
        t1.Text = u"QUÉT DẦM  →  EXCEL"
        t1.Font = bm_ui.font(13.0, True)
        t1.Location, t1.Size = Point(18, 8), Size(420, 26)
        head.Controls.Add(t1)
        t2 = Label()
        t2.Text = u"Cửa sổ không chặn Revit: bạn vẫn đổi view, chọn đối tượng trong lúc mở."
        t2.Location, t2.Size = Point(18, 36), Size(500, 20)
        head.Controls.Add(t2)

        def lbl(t, y, w=250, tag=None):
            l = Label()
            l.Text = t
            l.Location, l.Size = Point(20, y + 3), Size(w, 20)
            if tag:
                l.Tag = tag
            f.Controls.Add(l)
            return l

        def nud(y, lo, hi, val, dec=0, inc=50):
            n = NumericUpDown()
            n.Location, n.Size = Point(300, y), Size(100, 24)
            n.DecimalPlaces = dec
            n.Minimum, n.Maximum, n.Increment = Decimal(lo), Decimal(hi), Decimal(inc)
            n.Value = Decimal(val)
            f.Controls.Add(n)
            return n

        lbl(u"Phạm vi quét", 78)
        self.cb = ComboBox()
        self.cb.Location, self.cb.Size = Point(300, 78), Size(210, 24)
        self.cb.DropDownStyle = ComboBoxStyle.DropDownList
        self.cb.Items.Add(u"1 - Mặt bằng hiện hành")
        self.cb.Items.Add(u"2 - Toàn bộ dầm công trình")
        self.cb.SelectedIndex = 0
        f.Controls.Add(self.cb)
        lbl(u"Khe hở tối đa nối dầm (mm)", 114)
        self.n_gap = nud(114, 0, 5000, 1000, 0, 100)
        lbl(u"Lệch tim tối đa cùng đường (mm)", 150)
        self.n_lat = nud(150, 0, 1000, 150, 0, 10)
        lbl(u"Sai số góc song song (độ)", 186)
        self.n_ang = nud(186, 0, 10, 1, 1, 0.5)
        lbl(u"Dung sai cột - dầm (mm)", 222)
        self.n_ctol = nud(222, 0, 500, 100, 0, 10)

        lbl(u"Thư mục lưu - mỗi tầng / level 1 file Dam_<tầng>.xlsx", 262, 480, 'muted')
        self.tx = TextBox()
        self.tx.Location, self.tx.Size = Point(20, 288), Size(430, 24)
        self.tx.Text = os.path.join(os.path.expanduser('~'), 'Documents', 'BeamRebar')
        f.Controls.Add(self.tx)
        bt = Button()
        bt.Text = "..."
        bt.Location, bt.Size = Point(458, 287), Size(50, 26)
        bt.Click += self.on_browse
        f.Controls.Add(bt)

        self.ck = CheckBox()
        self.ck.Text = u"Mở Excel sau khi xuất"
        self.ck.Checked = True
        self.ck.Location, self.ck.Size = Point(20, 326), Size(300, 24)
        f.Controls.Add(self.ck)
        self.ckv = CheckBox()
        self.ckv.Text = u"Đảo dầm/lưới ĐỨNG thành TRÊN → DƯỚI (mặc định: dưới → trên)"
        self.ckv.Checked = False
        self.ckv.Location, self.ckv.Size = Point(20, 354), Size(490, 24)
        f.Controls.Add(self.ckv)

        self.status = Label()
        self.status.Text = u"Sẵn sàng."
        self.status.Tag = 'muted'
        self.status.Location, self.status.Size = Point(20, 392), Size(490, 22)
        f.Controls.Add(self.status)
        self.btn = Button()
        self.btn.Text = u"Quét && xuất"
        self.btn.Tag = 'primary'
        self.btn.Location, self.btn.Size = Point(300, 426), Size(130, 36)
        self.btn.Click += self.on_scan
        f.Controls.Add(self.btn)
        cn = Button()
        cn.Text = u"Đóng"
        cn.Location, cn.Size = Point(440, 426), Size(70, 36)
        cn.Click += lambda s, e: f.Close()
        f.Controls.Add(cn)
        f.FormClosed += self.on_closed
        bm_ui.apply(f, pal)

    def on_browse(self, s, e):
        sd = FolderBrowserDialog()
        sd.SelectedPath = self.tx.Text
        if sd.ShowDialog() == DialogResult.OK:
            self.tx.Text = sd.SelectedPath

    def on_scan(self, s, e):
      try:
        opt = dict(mode=self.cb.SelectedIndex + 1, gap=float(str(self.n_gap.Value)), lat=float(str(self.n_lat.Value)),
                   ang=float(str(self.n_ang.Value)), path=self.tx.Text, open=bool(self.ck.Checked),
                   vtd=bool(self.ckv.Checked), ctol=float(str(self.n_ctol.Value)))
        self.status.Text = u"Đang quét..."
        self.btn.Enabled = False
        if self.runner:
            self.runner.run(_scan_job, self, opt)     # chay trong ngu canh Revit API, cua so van mo
        else:
            _scan_job(None, self, opt)
      except Exception:
        bm_revit.log(traceback.format_exc())
        self.status.Text = u"Lỗi - xem error.log"
        self.btn.Enabled = True

    def on_closed(self, s, e):
        if getattr(builtins, '_bm_scan', None) is self:
            builtins._bm_scan = None

    def show(self):
        builtins._bm_scan = self                      # giu tham chieu song sau khi lenh pyRevit ket thuc
        if self.runner:
            owner = bm_revit.owner_window()
            try:
                if owner is not None:
                    self.f.Show(owner)
                else:
                    self.f.Show()
            except Exception:
                self.f.Show()
        else:
            self.f.ShowDialog()                       # khong co ExternalEvent: dung hop thoai chan (du phong)


def _scan_job(uiapp, form, opt):
    _PROG[0] = form
    try:
        form.status.Text = run_scan(opt) or u"Xong."
    except Exception:
        form.status.Text = u"Lỗi khi quét - xem thông báo."
        MessageBox.Show(traceback.format_exc(), u"Quét dầm - lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
    finally:
        _PROG[0] = None
        form.btn.Enabled = True


# ------------------------------------------------------------------ chay
def run_scan(opt):
    global doc
    ed = getattr(builtins, '_bm_editor', None)           # cua so "Thep dam" dang mo: no giu ban cu trong bo nho va se ghi de ket qua quet khi Luu
    try:
        if ed is not None and not ed.f.IsDisposed:
            MessageBox.Show(u"Cửa sổ \"Thép dầm\" đang mở. Hãy LƯU và ĐÓNG nó trước khi quét lại, "
                            u"nếu không bấm Lưu sẽ ghi đè kết quả quét mới bằng dữ liệu cũ trong bộ nhớ.", u"Quét dầm")
            return u"Đóng cửa sổ Thép dầm rồi quét lại."
    except Exception:
        pass
    doc = revit.doc                                  # model / view dang mo tai thoi diem bam Quet
    view = doc.ActiveView
    if opt['mode'] == 1:
        if not isinstance(view, ViewPlan):
            MessageBox.Show(u"Hãy mở một mặt bằng (Floor/Structural Plan) trong Revit rồi bấm Quét lại, hoặc chọn phạm vi 2.", u"Quét dầm")
            return u"Cần mở một mặt bằng."
        scope, vscope = u"Mặt bằng: %s" % view.Name, view
    else:
        scope, vscope = u"Toàn bộ công trình", None

    buckets, skipped = collect_beams(vscope)
    if not buckets:
        MessageBox.Show(u"Không tìm thấy dầm nào.", u"Quét dầm")
        return u"Không tìm thấy dầm nào."
    lzs = [lv_.Elevation * FT for lv_, _b in buckets.values()]
    allcols = collect_columns(vscope, lzs)
    grids = collect_grids(None)                       # toan bo luoi (view co the an bot luoi)
    allfloors = collect_floors(vscope, lzs)

    pn, vw = u'', u''
    try:
        pn = round(math.degrees(doc.ActiveProjectLocation.GetProjectPosition(XYZ.Zero).Angle), 3)
    except Exception:
        pass
    try:
        rd = view.RightDirection
        vw = round(math.degrees(math.atan2(rd.Y, rd.X)), 2)
    except Exception:
        pass
    core.VERT_TOP_DOWN = bool(opt['vtd'])
    core.VIEW_R = (1.0, 0.0)                         # huong 'sang phai' theo view dang quet
    try:
        rd = view.RightDirection
        if math.hypot(rd.X, rd.Y) > 0.5:
            n_ = math.hypot(rd.X, rd.Y)
            core.VIEW_R = (rd.X / n_, rd.Y / n_)
    except Exception:
        pass
    folder = opt['path']
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    written, tot_items, tot_sp, tot_beam, nnm, nvar = [], 0, 0, 0, 0, 0
    fnames = level_filenames()
    failed, kept_lines = [], []
    log_lines = [u"Quét lúc %s - %s" % (stamp, scope),
                 u"Lưới Revit đọc được: %d (dạng đường thẳng, lấy toạ độ 2 đầu Grid.Curve)" % len(grids)]
    log_lines += [u"  lưới %s: (%d, %d) → (%d, %d)" % (g_['name'], round(g_['p0'][0]), round(g_['p0'][1]),
                                                       round(g_['p1'][0]), round(g_['p1'][1])) for g_ in grids]
    if GRID_SKIP:
        log_lines.append(u"Lưới BỊ BỎ QUA (không phải đường thẳng): " + u", ".join(GRID_SKIP))
    # ---- moi tang / level = 1 file Excel rieng (de quan ly, ten dam khong bi trung giua cac tang)
    for lid, (lv, beams) in sorted(buckets.items(), key=lambda kv: kv[1][0].Elevation):
        lz = lv.Elevation * FT
        cols = [dict(c) for c in cols_for_level(allcols, lz)]
        floors = [fl for fl in allfloors if lz - 800 <= fl['ztop'] <= lz + 500]
        assign_slab(beams, floors, lz)
        insts = core.process_level(beams, cols, grids, opt['ang'], opt['lat'], opt['gap'], opt['ctol'])
        items = core.merge(insts)
        # ---- vai tro cua tung cot voi dam tang nay
        sup_ids, pl_ids = set(), set()
        for it_ in insts:
            for r_ in it_['col_rel']:
                (sup_ids if r_['is_sup'] else pl_ids).add(r_['id'])
        for c in cols:
            c['zr0'], c['zr1'] = c['z0'] - lz, c['z1'] - lz
            if c['id'] in sup_ids:
                c['role'] = u'Đỡ dầm (băng qua / cột dưới)'
            elif c['id'] in pl_ids:
                c['role'] = u'Cấy lên dầm / không đỡ dầm'
            else:
                c['role'] = u'Không chạm dầm nào'
        n_sup, n_pl = len(sup_ids), len(pl_ids - sup_ids)
        n_var = sum(1 for it in items if it.get('variant', 0) > 1)
        n_nm = sum(1 for it in items if it.get('nomark'))
        try:
            pz = round(lv.ProjectElevation * FT)
        except Exception:
            pz = round(lz)
        info = [(u'Dự án', doc.Title), (u'Tầng / Level', lv.Name), (u'Cao độ tầng (mm)', round(lz)),
                (u'Cao độ tầng theo Project Base Point (mm)', pz),
                (u'Phạm vi quét', scope), (u'Ngày quét', stamp),
                (u'Góc Project North (độ)', pn), (u'Hướng view hiện hành so với trục X (độ)', vw),
                (u'Chiều dầm/lưới đứng theo view', u'trên → dưới' if opt['vtd'] else u'dưới → trên'),
                (u'Số dầm con Revit', len(beams)), (u'Số dầm vật lý (sau khi nối đoạn)', len(insts)),
                (u'Số dầm điển hình xuất ra (theo Mark)', len(items)),
                (u'Dầm cùng Mark nhưng khác hình dạng', n_var), (u'Dầm chưa có Mark', n_nm),
                (u'Số cột (cả cột dưới + cột trên)', len(cols)), (u'Số cột đỡ dầm', n_sup), (u'Số cột cấy lên dầm (không đỡ)', n_pl),
                (u'Dung sai cột - dầm (mm)', opt['ctol']), (u'Số lưới', len(grids)), (u'Số sàn', len(floors)),
                (u'Khe hở nối dầm (mm)', opt['gap']), (u'Lệch tim cùng đường (mm)', opt['lat']),
                (u'Sai số góc (độ)', opt['ang']), (u'Đơn vị / gốc toạ độ', u'mm, gốc trong của Revit')]
        floors_out = [dict(id=f['id'], type=f['type'], th=f['th'], top=f['ztop'] - lz, poly=f['poly']) for f in floors]
        path = os.path.join(folder, fnames.get(lid) or (u"Dam_%s_%d.xlsx" % (_san(lv.Name), lid)))
        raw = [[u'ElementId', u'Mark', u'Level', u'Type', u'b (mm)', u'h (mm)', u'Nguồn b,h', u'h theo bbox (mm)',
                u'Start Level Offset (mm)', u'End Level Offset (mm)', u'z Offset Value (mm)', u'Z Justification',
                u'Đỉnh đầu 0 (mm)', u'Đỉnh đầu 1 (mm)', u'Cao đỉnh dùng (mm)', u'Đỉnh theo bbox (mm)', u'Nguồn cốt',
                u'Cảnh báo']]
        for bm in beams:
            wn = []
            if bm['src'] == u'THIẾU':
                wn.append(u'Không đọc được b/h')
            elif bm['hbb'] > 0 and abs(bm['h'] - (bm['hbb'] - bm['dz'])) > 20:
                wn.append(u'h khác chiều cao hình học (kiểm tra tham số/tên type)')
            if bm['dz'] > 2:
                wn.append(u'Dầm dốc / lệch cốt 2 đầu')
            if u'KHÔNG' in bm['zsrc']:
                wn.append(u'Cốt tính từ tham số không khớp bbox')
            raw.append([bm['id'], bm['mark'], bm['level'], bm['type'], round(bm['b']), round(bm['h']), bm['src'],
                        round(bm['hbb']), round(bm['so']), round(bm['eo']), round(bm['zo']), bm['zj'],
                        round(bm['t0']), round(bm['t1']), round(bm['top']), round(bm['tb']), bm['zsrc'],
                        u'; '.join(wn)])
        extra = [dict(name='DamCon', rows=raw, widths=[12, 12, 12, 24, 8, 8, 12, 14, 14, 14, 14, 12, 14, 14, 14, 16, 30, 46])]
        extra.append(dict(name='BoQua', rows=[[u'ElementId', u'Mark', u'Lý do bỏ qua', u'Dài mặt bằng (mm)', u'dz (mm)']]
                          + [list(x) for x in skipped], widths=[12, 12, 42, 18, 10]))
        rel_rows = [[u'Dầm (Mark)', u'Mã cột', u'ElementId cột', u'Base Level', u'Top Level', u'Vai trò', u'Đỡ dầm?',
                     u'Vị trí dọc dầm (mm)', u'Chân cột so với Level (mm)', u'Đỉnh cột so với Level (mm)',
                     u'Đáy dầm so với Level (mm)', u'Đỉnh dầm so với Level (mm)', u'Đối chiếu theo cao độ z']]
        cay_rows = [[u'Dầm (Mark)', u'SL dầm', u'Mã cột', u'ElementId cột', u'Type cột', u'Base Level', u'Top Level',
                     u'Chân cột so với Level (mm)', u'Đỉnh cột so với Level (mm)', u'Vị trí dọc dầm từ đầu trái (mm)',
                     u'Bề rộng cột dọc dầm (mm)', u'Nhịp số', u'Vai trò / lý do']]
        for it_ in items:
            ax_ = it_['axis']
            for r_ in sorted(it_['col_rel'], key=lambda q: q['c']):
                z0_ = round(r_['z0'] - lz) if r_['z0'] is not None else None
                z1_ = round(r_['z1'] - lz) if r_['z1'] is not None else None
                rel_rows.append([it_['name'], r_['name'], r_['id'], r_['base_lv'], r_['top_lv'], r_['role'],
                                 u'CÓ' if r_['is_sup'] else u'KHÔNG', round(r_['c']), z0_, z1_,
                                 round(r_['zb'] - lz), round(r_['zt'] - lz), r_['zcheck']])
                if not r_['is_sup']:
                    cc_ = min(max(r_['c'], 0.0), ax_['L'])
                    k_ = [s_['idx'] for s_ in it_['spans'] if r_['name'] in s_.get('planted', [])]
                    cay_rows.append([it_['name'], it_['count'], r_['name'], r_['id'], r_['type'], r_['base_lv'], r_['top_lv'],
                                     z0_, z1_, round(r_['c']), round(r_['w']), k_[0] if k_ else None, r_['role']])
        extra.append(dict(name='CotDam', rows=rel_rows, widths=[14, 12, 12, 12, 12, 56, 10, 14, 16, 16, 16, 16, 28]))
        extra.append(dict(name='CotCay', rows=cay_rows, widths=[14, 8, 12, 12, 24, 12, 12, 16, 16, 18, 16, 8, 56]))
        # ---- kiem tra lưới: toa do tim goi / truc luoi Revit / khoang cach -> biet tool co dung tim cot hay khong
        gmap = dict((g_['name'], g_) for g_ in grids)
        gl_rows = [[u'Dầm (Mark)', u'Gối', u'Loại gối', u'Mã cột/dầm đỡ', u'Tim gối X (mm)', u'Tim gối Y (mm)',
                    u'Tim gối dọc dầm (mm)', u'Trục lưới Revit', u'Vị trí trục dọc dầm (mm)', u'Trục - tim gối (mm)',
                    u'Khoảng cách tim gối → đường lưới (mm)', u'Lưới đi qua đúng tim gối?',
                    u'Lưới X1', u'Lưới Y1', u'Lưới X2', u'Lưới Y2', u'Gối rộng dọc dầm (mm)']]
        n_on = n_gr = 0
        for it_ in items:
            ax_ = it_['axis']
            for k_, s_ in enumerate(it_['supports']):
                if s_['kind'] in (u'Đầu tự do', u'Đổi tiết diện'):
                    gl_rows.append([it_['name'], u'G%d' % k_, s_['kind']] + [None] * 14)
                    continue
                px = ax_['O'][0] + ax_['d'][0] * s_['c'] - ax_['n'][0] * s_['ecc']
                py = ax_['O'][1] + ax_['d'][1] * s_['c'] - ax_['n'][1] * s_['ecc']
                g_ = gmap.get(s_.get('grid'))
                if g_ is None:
                    gl_rows.append([it_['name'], u'G%d' % k_, s_['kind'], s_['ref'], round(px), round(py), round(s_['c']),
                                    u'(không có trục đi qua)'] + [None] * 8 + [round(s_['s1'] - s_['s0'])])
                    continue
                gx, gy = g_['p1'][0] - g_['p0'][0], g_['p1'][1] - g_['p0'][1]
                dist = abs((px - g_['p0'][0]) * gy - (py - g_['p0'][1]) * gx) / math.hypot(gx, gy)
                n_gr += 1
                n_on += 1 if dist < 5 else 0
                gl_rows.append([it_['name'], u'G%d' % k_, s_['kind'], s_['ref'], round(px), round(py), round(s_['c']),
                                s_['grid'], round(s_.get('gpos', s_['c'])), round(s_.get('off', 0.0)), round(dist),
                                u'CÓ (trục trùng tim)' if dist < 5 else u'KHÔNG (lệch %d mm)' % round(dist),
                                round(g_['p0'][0]), round(g_['p0'][1]), round(g_['p1'][0]), round(g_['p1'][1]),
                                round(s_['s1'] - s_['s0'])])
        extra.append(dict(name='GoiLuoi', rows=gl_rows, widths=[14, 6, 12, 12, 12, 12, 14, 14, 16, 14, 18, 22, 10, 10, 10, 10, 14]))
        log_lines.append(u"[%s] %d gối có trục lưới đi qua; %d gối có trục TRÙNG tim cột/dầm đỡ (dist < 5 mm); %d cột cấy lên dầm"
                         % (lv.Name, n_gr, n_on, n_pl))
        try:
            kinfo = report.write(path, items, cols, grids, floors_out, info, extra, stamp)
        except (IOError, OSError) as ex:                  # file dang mo / khong sao luu duoc: GIU NGUYEN file cu, bo qua tang nay
            failed.append(u'%s: %s' % (lv.Name, ex))
            log_lines.append(u'[%s] KHÔNG ghi: %s' % (lv.Name, ex))
            continue
        if kinfo is not None:
            kept_lines.append(bm_keep.summary(kinfo, lv.Name))
            log_lines.append(kept_lines[-1])
        written.append((lv.Name, path, len(items), sum(len(it['spans']) for it in items)))
        tot_items += len(items)
        tot_sp += sum(len(it['spans']) for it in items)
        tot_beam += len(beams)
        nnm += n_nm
        nvar += n_var
    try:
        open(os.path.join(folder, u"QuetDam_log.txt"), 'w', encoding='utf-8').write(u"\n".join(log_lines))
    except Exception:
        pass
    lines = u"\n".join(u"  %s: %d dầm điển hình, %d nhịp  →  %s" % (w[0], w[2], w[3], os.path.basename(w[1])) for w in written)
    msg = (u"Đã xuất %d file (mỗi tầng 1 file) vào:\n%s\n\n%s\n\nTổng: %d dầm điển hình (%d nhịp) từ %d dầm con Revit. Bỏ qua %d dầm (cong/dốc/lỗi) - xem sheet BoQua."
           % (len(written), folder, lines, tot_items, tot_sp, tot_beam, len(skipped)))
    if kept_lines:
        msg += u"\n\nQUÉT LẠI - dữ liệu được giữ (file cũ đã sao lưu vào thư mục backup):\n" + u"\n".join(kept_lines)
    if failed:
        msg += u"\n\nCHƯA ghi được (file cũ còn nguyên):\n" + u"\n".join(failed)
    if nnm:
        msg += u"\n\nCó %d dầm chưa đặt Mark (tên NOMARK-n)." % nnm
    if nvar:
        msg += u"\nCó %d dầm cùng Mark nhưng khác hình dạng (tên có ~2, ~3...)." % nvar
    MessageBox.Show(msg, u"Quét dầm", MessageBoxButtons.OK, MessageBoxIcon.Information)
    if opt['open'] and written:
        try:
            os.startfile(written[0][1])
        except Exception:
            pass
    return u"Đã xuất %d file: %d dầm điển hình, %d nhịp." % (len(written), tot_items, tot_sp)


def main():
    fm = getattr(builtins, '_bm_scan', None)
    if fm is not None:                                # da mo roi: dua len truoc
        try:
            if not fm.f.IsDisposed:
                fm.f.Activate()
                return
        except Exception:
            pass
        builtins._bm_scan = None
    ScanForm(bm_revit.get_runner()).show()
